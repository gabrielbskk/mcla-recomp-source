# FidelityFX API headers (FSR 3.1 upscaling and frame generation)

The ffx-api headers the GPU plugin compiles its FSR 3.1 calls against
(`ffx_api.h`, `ffx_api_types.h`, `ffx_upscale.h`, `ffx_framegeneration.h`,
`dx12/ffx_api_dx12.h`, `vk/ffx_api_vk.h`), unmodified, from the AMD FidelityFX SDK 1.1.4 as carried by
https://github.com/rexglue/FidelityFX-SDK at commit
eee08db1688ac3d1275a70b728f4a8ba22914213 (AMD's v1.1.4 plus portability fixes).
MIT licence: `LICENSE.txt`.

The runtime (`amd_fidelityfx_dx12.dll`, `amd_fidelityfx_vk.dll`) is built from
that commit's source by `cmake/rexglue_fsr.cmake` when `REXGLUE_ENABLE_FSR` is on,
and loaded at run time from the executable's folder (where `scripts/make_pc.ps1`
copies them, next to `mcla.exe` and the GPU plugin).
