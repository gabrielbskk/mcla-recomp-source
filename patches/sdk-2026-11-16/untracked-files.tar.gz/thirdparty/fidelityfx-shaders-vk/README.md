# FSR 3.1's upscaler and frame generation shaders for Vulkan, prebuilt

The SPIR-V of the permutations of AMD FSR 3.1's upscaler and frame generation
(FidelityFX SDK, commit `eee08db1688ac3d1275a70b728f4a8ba22914213` of the ReXGlue fork,
MIT: LICENSE.txt) that rexglue's native anti-aliasing and frame generation can ask for,
in the headers FidelityFX's shader compiler (FidelityFX_SC.exe, Windows only) generates,
for building FidelityFX's Vulkan runtime where that compiler can't run: Linux and the
PS5 (cmake/rexglue_fsr.cmake, `REXGLUE_FSR_PREBUILT_SHADERS`). Windows builds compile
them as FidelityFX does.

Made by `launcher/dev/fsr/fsr_vk_shaders.py` in mcla-recomp from a Windows build's
output, for the create flags `FFX_UPSCALE_ENABLE_AUTO_EXPOSURE`,
`FFX_UPSCALE_ENABLE_DEPTH_INVERTED`, `FFX_UPSCALE_ENABLE_HIGH_DYNAMIC_RANGE` (FSR) and
`FFX_FRAMEGENERATION_ENABLE_DEPTH_INVERTED` (frame generation). The 40 permutation
tables of FSR 3's ten passes keep the 40 blobs that four keys of 64 reach (20 files,
0.47 MB of SPIR-V); the 44 of frame interpolation's eleven passes and the 28 of optical
flow's seven keep the 26 and 14 blobs their one key reaches (18 files, 0.25 MB). All
unchanged, each distinct blob stored once (the wave64 and 16-bit variants are the same
SPIR-V on Vulkan; their tables point at the same arrays); every other key leads to an
empty entry, and the tables FidelityFX's code doesn't use (its runtime embeds none of
their blobs) are empty. So are FSR 2's, linked by ffx-api but not used.
`rexglue_fsr_shaders_vk.h` names the flags; the GPU plugin refuses to create a context
from this set with others.
