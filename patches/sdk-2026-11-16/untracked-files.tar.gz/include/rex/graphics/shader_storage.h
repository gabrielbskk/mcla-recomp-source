/**
 * @file        graphics/shader_storage.h
 * @brief       What a front end needs to know about the persistent shader storage
 *
 * The storage is <cache_root>/shaders/shareable/<title>.xsh (guest shaders, both backends) and
 * one pipeline description file per backend and render target path. A file whose header holds
 * another version is emptied at start, so a tool that adds to these files (mcla's
 * --mcla_prepare_shaders) checks its own data against these first. The pipeline caches check
 * that these equal their own versions.
 */

#pragma once

#include <cstdint>
#include <rex/platform.h>

namespace rex::graphics::shader_storage {

// <title>.xsh: 'XESH', then this version byte-swapped.
inline constexpr uint32_t kShaderStorageVersion = 0x20201219;
// <title>.rtv.d3d12.xpso and <title>.rov.d3d12.xpso: 'XEPS', 'DXRT' or 'DXRO', then this
// version byte-swapped.
inline constexpr uint32_t kD3D12PipelineStorageVersion = 0x20260226;
// <title>.fbo.vk.xpso and <title>.fsi.vk.xpso: 'XEPS', 0 or 1, then this version byte-swapped.
inline constexpr uint32_t kVulkanPipelineStorageVersion = 0x20260228;

// Packed pipeline bitfields are ABI-dependent. pipeline_cache.cpp checks this
// public stride against sizeof(PipelineStoredDescription) in the active build.
#if REX_PLATFORM_ANDROID
inline constexpr uint32_t kVulkanPipelineStorageRecordSize = 66;
#else
inline constexpr uint32_t kVulkanPipelineStorageRecordSize = 68;
#endif

}  // namespace rex::graphics::shader_storage
