#pragma once
// Versioned optional renderer bridge; no proprietary shaders are embedded.
#include <stddef.h>
#include <stdint.h>
#include <vulkan/vulkan_core.h>

#define MCLA_LSFG_ABI_VERSION 1u
#define MCLA_LSFG_REQUIRED_FEATURES 15u /* sync2, memory model, nullDescriptor, extended storage formats */

typedef struct MclaLsfgDevice {
    uint32_t abi_version;
    VkInstance instance;
    VkPhysicalDevice physical_device;
    VkDevice device;
    VkQueue queue;
    uint32_t queue_family;
    PFN_vkGetInstanceProcAddr get_instance_proc_addr;
    uint32_t enabled_features;
    uint32_t width, height;
    const char* dll_path;
} MclaLsfgDevice;

typedef struct MclaLsfgFrame {
    VkCommandBuffer command_buffer; /* recording, outside any render pass */
    VkImage source, destination; /* transfer source/destination usage required */
    VkImageLayout source_layout, destination_layout;
    VkFormat source_format, destination_format;
    uint64_t submission; /* monotonically nondecreasing host submission sequence */
    int reset_history;
} MclaLsfgFrame;

#ifdef __cplusplus
extern "C" {
#endif
__attribute__((visibility("default")))
void* mcla_lsfg_create(const MclaLsfgDevice*, char* error, size_t error_size);
/* Records only. Source layout restored; a ready destination ends in GENERAL. */
__attribute__((visibility("default")))
int mcla_lsfg_record(void*, const MclaLsfgFrame*, int* ready, char* error, size_t error_size);
/* 1 means GPU work is still pending; no waits and no destruction occur then. */
__attribute__((visibility("default")))
int mcla_lsfg_destroy(void*, uint64_t completed_submission);
#ifdef __cplusplus
}
#endif
