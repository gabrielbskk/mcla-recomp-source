#pragma once
/**
 * Low latency (rexglue-low-latency.patch): the GPU vendor's latency reducer for
 * the guest's frames: NVIDIA Reflex (Direct3D 12 through NVAPI, Vulkan through
 * VK_NV_low_latency2) and AMD Anti-Lag 2 (Direct3D 12's driver extension,
 * VK_AMD_anti_lag). The names are used as plain text, to say which one it is.
 *
 * A frame is the guest's: one pass through the engine timer (the update
 * thread, OnFrameStart) to one swap packet (written by VdSwap on the render
 * thread, OnGuestSwap, and executed by the GPU command thread). Its id is the
 * ordinal of the swap packet that ends it: the update thread knows it before
 * the swap is written (the swaps written so far plus the frames it started
 * that are not swapped yet, plus one), the render thread counts the packets
 * where it writes them and the GPU command thread where it executes them, in
 * the same order, so every marker of a frame carries the same id without any
 * queue between the threads, and a frame whose swap is late (the update ran
 * twice before the render thread swapped) keeps its own id. A swap with no
 * engine timer pass before it (the logos, loading screens) is not marked.
 *
 * The functions can be called from any thread, the game's, the GPU command
 * thread's or a presenter's; none does anything without a backend.
 */

#include <cstdint>
#include <memory>
#include <string>

namespace rex {
namespace ui {

// The points of a frame the driver is told about.
enum class LatencyMarker : uint32_t {
  kSimulationStart,
  kSimulationEnd,
  kRenderSubmitStart,
  kRenderSubmitEnd,
  kPresentStart,
  kPresentEnd,
  kInputSample,
  // For presents (and the work for them) made on a queue of their own, out of
  // the guest frame's cadence: the frame generation pacers.
  kOutOfBandRenderSubmitStart,
  kOutOfBandRenderSubmitEnd,
  kOutOfBandPresentStart,
  kOutOfBandPresentEnd,
  // The generated frames of frame generation are out of band too, but the vendors that count
  // the presents of a frame (Anti-Lag 2) take the real frame's only.
  kGeneratedPresentStart,
  kGeneratedPresentEnd,
};

// What a graphics API's presenter provides: one vendor's reducer on its device.
class LowLatencyBackend {
 public:
  virtual ~LowLatencyBackend() = default;
  // The feature's name in the settings' letters (A to Z, 0 to 9, space).
  virtual const char* Name() const = 0;
  // Whether it can boost the GPU clocks (Reflex's On + Boost).
  virtual bool SupportsBoost() const { return false; }
  // Never run: written from the vendor's documentation and headers.
  virtual bool Untested() const { return false; }
  // Whether low_latency = auto means on for this one (a tested one).
  virtual bool OnByDefault() const { return false; }
  // Whether the guest frame's present markers go out when the frame is handed to frame
  // generation's pacer (Reflex), or only with the pacer's own presents (Anti-Lag 2).
  virtual bool PresentMarkersAtHandOff() const { return true; }
  // Whether its driver call takes the frame-rate limit (minimum interval).
  virtual bool SupportsLimit() const { return true; }
  // The mode: on or off, boost, and the minimum frame interval (0: none). Whether the driver
  // took it (not while there is no swapchain to take it: the mode is told again when there is).
  virtual bool SetMode(bool on, bool boost, uint32_t minimum_interval_us) = 0;
  // Why SetMode failed (the settings' letters).
  virtual const char* FailureReason() const { return "NOT SUPPORTED"; }
  // Null while the backend can work; else why it can't any more (the settings' letters): a
  // swapchain the driver made without the latency mode. Read every frame. It is for good (the
  // core does not ask again; waits that take too long are the core's own and are tried again).
  virtual const char* Failed() const { return nullptr; }
  // Called once per frame, before the frame's input is read: the driver waits
  // here for the best moment to start (it is the latency reduction). Whether it did (and holds
  // the frame rate to the minimum interval): false where it could not (no swapchain yet, a call
  // that failed), when the game's own limiter has to hold the frame rate.
  virtual bool Sleep(uint64_t frame_id) = 0;
  virtual void Marker(LatencyMarker marker, uint64_t frame_id) = 0;
  // For the debug log: the driver's own report of the latest frames, or empty.
  virtual std::string TimingReport() { return std::string(); }
};

class LowLatency {
 public:
  enum class State { kUnknown, kAvailable, kUnavailable };
  struct Status {
    State state = State::kUnknown;
    // The vendor's feature, in plain text and the settings' letters: NVIDIA
    // REFLEX, AMD ANTI LAG 2; LOW LATENCY while there is none.
    std::string name = "LOW LATENCY";
    // Why not (the settings' letters), while it is unavailable.
    std::string why;
    // Working now: the mode asks for it and the driver has it set.
    bool active = false;
    // Forced on by frame generation (low_latency_frame_generation).
    bool forced_by_frame_generation = false;
    bool boost_available = false;
    bool untested = false;
    // What low_latency = auto stands for.
    bool on_by_default = false;
  };
  static Status GetStatus();

  // The game's threads.
  // The update thread, once per frame, first thing in the engine timer (before it reads the
  // time): the driver's wait, then the frame's SIMULATION_START and INPUT_SAMPLE.
  static void OnFrameStart();
  // The render thread, in VdSwap once the swap packet is written: SIMULATION_END, and the
  // packet's count.
  static void OnGuestSwap();
  // The game's frame-rate limit, 0 for none; handed to the driver only while
  // low_latency_limiter is driver (DriverLimits).
  static void SetFrameLimit(uint32_t fps);
  // The driver holds the frame rate to the limit now (the mode was taken and this frame's wait
  // was made): the game's own limiter waits for nothing. Never true on a hope: where the driver
  // could not, the game's limiter holds the frame rate.
  static bool DriverLimits();
  // Whether device creation should ask for the vendor's extensions (Vulkan): the GPU's vendor
  // has a reducer, low_latency_debug_backend allows it, and the device is one that takes them
  // (low_latency_device_extensions).
  static bool WantsVulkanExtensions(uint32_t vendor_id, bool* nvidia, bool* amd);

  // The GPU command thread.
  // A draw is about to be executed: the first of a frame starts RENDERSUBMIT.
  static void OnRenderDraw();
  // The swap packet, before the swap is issued and painted: RENDERSUBMIT_END
  // and the frame's id for the present code (CurrentFrameId).
  static void OnRenderSwap();
  // After the swap was issued and painted: the next frame's id.
  static void OnRenderSwapDone();
  // The marked frame the calling (GPU command) thread is swapping, or 0.
  static uint64_t CurrentFrameId();
  // The marked frame the GPU command thread is building now (the one the next swap packet ends),
  // or 0 while markers aren't sent (or explicit attribution is off): what a submission of its work
  // is attributed to.
  static uint64_t GpuFrameId();

  // For the presenters.
  static void Attach(std::shared_ptr<LowLatencyBackend> backend);
  static void Detach(const LowLatencyBackend* backend);
  static void SetUnavailable(const char* why);
  // A marker of a frame (not for id 0), also for the threads of the pacers.
  static void Marker(LatencyMarker marker, uint64_t frame_id);
};

}  // namespace ui
}  // namespace rex
