#pragma once
/**
 * Vulkan low latency (rexglue-low-latency.patch): NVIDIA Reflex through VK_NV_low_latency2 and AMD
 * Anti-Lag 2 through VK_AMD_anti_lag. See include/rex/ui/low_latency.h.
 */

#include <atomic>
#include <cstdint>
#include <memory>
#include <shared_mutex>
#include <string>

#include <rex/ui/low_latency.h>
#include <rex/ui/vulkan/device.h>

namespace rex {
namespace ui {
namespace vulkan {

class VulkanLowLatency final : public LowLatencyBackend {
 public:
  // Null where the device has neither extension, with the reason in *why (the settings' letters).
  static std::shared_ptr<VulkanLowLatency> Create(const VulkanDevice* device, const char** why);
  ~VulkanLowLatency() override;

  const char* Name() const override { return name_; }
  bool SupportsBoost() const override { return nvidia_; }
  bool Untested() const override { return untested_; }
  bool OnByDefault() const override { return nvidia_ && !untested_ && kOnByDefault; }
  // (Anti-Lag 2 is presented at the pacer's real presents.)
  bool PresentMarkersAtHandOff() const override { return nvidia_; }
  bool SetMode(bool on, bool boost, uint32_t minimum_interval_us) override;
  const char* FailureReason() const override { return failure_reason_; }
  // A swapchain made without the latency mode (the driver refused it): the reducer can't work.
  const char* Failed() const override {
    return swapchain_refused_.load(std::memory_order_acquire) ? "SWAPCHAIN REFUSED IT" : nullptr;
  }
  bool Sleep(uint64_t frame_id) override;
  void Marker(LatencyMarker marker, uint64_t frame_id) override;
  std::string TimingReport() override;

  // The presenter's swapchain (UI thread), which the driver calls are made on; null before it is
  // made and from when it is retired (waits for the calls in progress). `latency_mode`: it was
  // made with the latency mode (a driver that refused that gives one without, on which the
  // reducer can't work). The mode is told to a new one, if it has been told one before.
  void SetSwapchain(VkSwapchainKHR swapchain, bool latency_mode);
  // The presenter is going: no more driver calls, the semaphore destroyed (after the calls in
  // progress and the wait for the driver's signal).
  void Shutdown();
  // The frame generation pacer's queue presents out of the guest frame's cadence: its
  // submissions don't count (Reflex).
  void NotifyOutOfBandPresentQueue(VkQueue queue);
  // Whether explicit submission attribution (a frame id with each submission) is available.
  bool ExplicitSubmissionAttribution() const;

 private:
  explicit VulkanLowLatency(const VulkanDevice* device) : device_(device) {}

  // low_latency = auto: on for NVIDIA Reflex (patches/README.md has what it costs and gains).
  static constexpr bool kOnByDefault = true;

  const VulkanDevice* device_;
  bool nvidia_ = false;  // VK_NV_low_latency2 (else VK_AMD_anti_lag)
  bool untested_ = false;
  const char* name_ = "LOW LATENCY";
  const char* failure_reason_ = "NOT SUPPORTED";
  // The sleep's semaphore: used by the update thread (waited for outside the swapchain's lock),
  // destroyed by Shutdown once the wait is over.
  std::shared_mutex semaphore_mutex_;
  VkSemaphore sleep_semaphore_ = VK_NULL_HANDLE;
  std::atomic<uint64_t> sleep_value_{0};
  // Readers: the calls; the writer: the swapchain changing.
  std::shared_mutex swapchain_mutex_;
  VkSwapchainKHR swapchain_ = VK_NULL_HANDLE;
  bool swapchain_latency_mode_ = false;
  std::atomic<bool> swapchain_refused_{false};
  bool shut_down_ = false;
  // The mode, once the policy has told one (until then the driver is told nothing).
  bool mode_set_ = false;
  bool mode_on_ = false;
  bool mode_boost_ = false;
  uint32_t mode_interval_us_ = 0;
  uint32_t anti_lag_max_fps_ = 0;
  bool anti_lag_on_ = false;
  bool sleep_wait_failure_logged_ = false;
};

}  // namespace vulkan
}  // namespace ui
}  // namespace rex
