// VK_AMD_anti_lag function used for AMD Anti-Lag 2 (rexglue-low-latency.patch).
XE_UI_VULKAN_FUNCTION(vkAntiLagUpdateAMD)
