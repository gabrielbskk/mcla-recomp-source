// VK_NV_low_latency2 functions used for NVIDIA Reflex (rexglue-low-latency.patch).
XE_UI_VULKAN_FUNCTION(vkSetLatencySleepModeNV)
XE_UI_VULKAN_FUNCTION(vkLatencySleepNV)
XE_UI_VULKAN_FUNCTION(vkSetLatencyMarkerNV)
XE_UI_VULKAN_FUNCTION(vkGetLatencyTimingsNV)
XE_UI_VULKAN_FUNCTION(vkQueueNotifyOutOfBandNV)
