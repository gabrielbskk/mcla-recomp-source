// VK_EXT_hdr_metadata functions used in Xenia.
XE_UI_VULKAN_FUNCTION(vkSetHdrMetadataEXT)
