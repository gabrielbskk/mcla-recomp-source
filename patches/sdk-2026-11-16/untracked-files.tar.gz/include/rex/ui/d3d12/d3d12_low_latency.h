#pragma once
/**
 * Direct3D 12 low latency (rexglue-low-latency.patch). See include/rex/ui/low_latency.h.
 */

#include <memory>

#include <dxgi1_4.h>
#include <d3d12.h>

#include <rex/ui/graphics_provider.h>
#include <rex/ui/low_latency.h>

namespace rex {
namespace ui {
namespace d3d12 {

// The vendor's reducer for this device: NVIDIA Reflex (NVAPI) on an NVIDIA GPU, AMD Anti-Lag 2 on
// an AMD one. Null where there is none or the driver lacks it, with the reason (the settings'
// letters) in *why.
std::shared_ptr<LowLatencyBackend> CreateLowLatencyBackend(ID3D12Device* device,
                                                           GraphicsProvider::GpuVendorID vendor,
                                                           const char** why);

// With AMD's frame interpolation swap chain: its proxy reads the Anti-Lag 2 context from the
// swap chain's private data and tells the driver which of its presents are generated; the data
// is set once the context is made (when the reducer is first wanted). Null for the swap chain
// that is going, before it is released. Does nothing for another backend.
void SetAntiLagPrivateData(IDXGISwapChain* swap_chain, LowLatencyBackend* backend);

}  // namespace d3d12
}  // namespace ui
}  // namespace rex
