#pragma once

#include <android/native_window.h>

#include <rex/ui/surface.h>

namespace rex::ui {

// SDL owns the ANativeWindow; this non-owning wrapper is valid while the SDL
// window remains alive.
class AndroidNativeWindowSurface final : public Surface {
 public:
  explicit AndroidNativeWindowSurface(ANativeWindow* window) : window_(window) {}

  TypeIndex GetType() const override { return kTypeIndex_AndroidNativeWindow; }
  ANativeWindow* window() const { return window_; }

 protected:
  bool GetSizeImpl(uint32_t& width_out, uint32_t& height_out) const override {
    if (!window_) {
      return false;
    }
    const int width = ANativeWindow_getWidth(window_);
    const int height = ANativeWindow_getHeight(window_);
    if (width <= 0 || height <= 0) {
      return false;
    }
    width_out = static_cast<uint32_t>(width);
    height_out = static_cast<uint32_t>(height);
    return true;
  }

 private:
  ANativeWindow* window_;
};

}  // namespace rex::ui
