/**
 * @file        audio/audio_dump.h
 * @brief       Counters and WAV dumps of the audio path (fork instrumentation)
 *
 * Added by the mcla-recomp fork (patches/rexglue-xma-decoder-fixes.patch). Everything here is off
 * unless a cvar asks for it (audio_stats, audio_dump_dir); the checks on the hot paths are one
 * relaxed load.
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */
#pragma once

#include <atomic>
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <string>
#include <vector>

namespace rex::audio::dump {

/// Reads the cvars, creates the dump folder and starts the statistics reporter. Called by
/// AudioSystem::Setup. Shutdown() prints the totals and stops the reporter.
///
/// The game exits through std::_Exit (window close), which runs no Shutdown: Init() also arms a
/// process-exit guard (a static destructor, which still runs then, after the other threads have
/// been killed) that flushes every open dump file, patches its WAV header and writes the final
/// totals to <audio_dump_dir>/audio_stats_total.txt. Nothing here can end in std::terminate:
/// the reporter thread object is never destroyed while joinable.
void Init();
void Shutdown();

bool StatsEnabled();
bool DumpEnabled();

/// Microseconds since Init() (steady clock).
uint64_t NowUs();

/// CPU time the calling thread has used so far, in nanoseconds, or 0 when it cannot be read (not Windows). Windows:
/// QueryThreadCycleTime, which counts the cycles the thread ran, exactly, however short the stretch; GetThreadTimes
/// would only move in clock ticks (15.6 ms, or 1 ms when a program raises the timer resolution, as the game does), too
/// coarse for a 1 ms stretch. The cycles are turned into time by a factor measured in Init() (one busy spell of about
/// 24 ms on the calling thread, only with audio_stats). Take the difference of two calls.
uint64_t ThreadCpuNs();
/// True when ThreadCpuNs() works.
bool ThreadCpuAvailable();
/// Finds the clock and measures its factor (Init() calls it when audio_stats is on).
void InitThreadCpuClock();

/// Host code can add text to the end of every statistics line: an interval line and the TOTAL line that follows it.
/// `total` is false for an interval line (what happened since the last call with false, which only the reporter
/// thread makes) and true for a TOTAL line (since the start; also made once from the process-exit guard). Called only
/// with audio_stats; it must not block. Return "" for nothing, else text starting with " | ". Set it once, early (before Init() if possible).
using ExtraStatsFn = std::string (*)(bool total);
void SetExtraStats(ExtraStatsFn fn);

/// The folder of the dump files, with a trailing separator ("" when dumping is off).
const std::string& Dir();

/// Marks the calling thread as the XMA worker thread (so Work() can tell it from a kick's inline decode).
void MarkXmaWorkerThread();
bool IsXmaWorkerThread();

/// Cumulative counters. Maxima and minima are over the whole run (the reporter also prints
/// the per-interval ones it keeps itself).
struct Counters {
  // XMA contexts (Work() calls that decoded or consumed something)
  std::atomic<uint64_t> xma_work_inline{0};   // on the thread that kicked the context
  std::atomic<uint64_t> xma_work_worker{0};   // on the XMA worker thread
  std::atomic<uint64_t> xma_work_us{0};
  std::atomic<uint64_t> xma_work_us_max{0};
  std::atomic<uint64_t> xma_work_slow{0};     // Work() calls over 2 ms
  std::atomic<uint64_t> xma_kicks{0};         // kick register writes (contexts kicked)
  std::atomic<uint64_t> xma_frames{0};        // frames handed to the decoder
  std::atomic<uint64_t> xma_decode_errors{0};
  std::atomic<uint64_t> xma_recheck_abort{0}; // Work() found the context disabled/released once it had the lock
  std::atomic<uint64_t> xma_stalled_loops{0}; // Work() loops ended for lack of progress
  std::atomic<uint64_t> xma_cas_retries{0};
  // What the game wrote into a context while a Work() call on it was running. With the race fixes
  // off these writes are overwritten by the stale snapshot; with them on they are kept.
  std::atomic<uint64_t> xma_game_wrote_read_offset{0};
  std::atomic<uint64_t> xma_game_wrote_valid{0};
  std::atomic<uint64_t> xma_game_wrote_other{0};
  // The audio worker (guest XAudio2 mixer callbacks)
  std::atomic<uint64_t> pump_count{0};
  std::atomic<uint64_t> pump_us{0};
  std::atomic<uint64_t> pump_us_max{0};
  std::atomic<uint64_t> pump_gap_max_us{0};   // longest time between two callbacks of one client
  std::atomic<uint64_t> pump_late{0};         // callbacks that started over 8 ms after the previous one
  std::atomic<uint64_t> pump_over_4ms{0};     // callbacks that took over 4 ms (the frame period is 5.33 ms)
  std::atomic<uint64_t> pump_over_8ms{0};     // callbacks that took over 8 ms: more than a whole frame
  // The SDL output
  std::atomic<uint64_t> sdl_callbacks{0};
  std::atomic<uint64_t> sdl_frames{0};        // guest frames played
  std::atomic<uint64_t> sdl_underruns{0};     // callbacks that had to put silence in because no frame was queued
  std::atomic<uint64_t> sdl_queue_min{~0ull}; // fewest frames queued at the start of a callback
  // The same underruns split: before the guest mixer has delivered its first second of audio (the device starts
  // asking before the game's mixer runs: ~50 silent frames at the start of every run) and after it (the ones that
  // matter: silence in the middle of the game's audio, which stays in the stream as a delay).
  std::atomic<uint64_t> sdl_underruns_steady{0};
  std::atomic<uint64_t> sdl_silence_max{0};   // longest run of consecutive silent frames after the start
  std::atomic<uint64_t> sdl_queue_grown{0};   // frames of queue depth added by audio_adaptive_queue
  // How late the audio worker answers the device: the SDL callback stamps last_release_us when it gives the mixer
  // a credit (it consumed a frame), the worker measures the time to the start of the mixer callback it then runs.
  std::atomic<uint64_t> last_release_us{0};
  std::atomic<uint64_t> wake_lt1{0}, wake_lt2{0}, wake_lt4{0}, wake_lt8{0}, wake_lt16{0}, wake_ge16{0};
  std::atomic<uint64_t> wake_us_max{0};
};
Counters& C();

/// Silent frames the output has played in the middle of the game's audio (after its first second), counted always,
/// not only with audio_stats: the game's wake-on-demand watchdog (mcla_pump_wake_on_demand, src/poll_wait.cpp) polls it
/// and goes back to the game's own pacing when it rises. One relaxed load.
uint64_t SteadyUnderruns();

inline void Add(std::atomic<uint64_t>& a, uint64_t v) {
  a.fetch_add(v, std::memory_order_relaxed);
}
inline void Max(std::atomic<uint64_t>& a, uint64_t v) {
  uint64_t cur = a.load(std::memory_order_relaxed);
  while (v > cur && !a.compare_exchange_weak(cur, v, std::memory_order_relaxed)) {
  }
}
inline void Min(std::atomic<uint64_t>& a, uint64_t v) {
  uint64_t cur = a.load(std::memory_order_relaxed);
  while (v < cur && !a.compare_exchange_weak(cur, v, std::memory_order_relaxed)) {
  }
}

/// Bytes still allowed to be written by all dump writers together (audio_dump_max_mb).
bool TakeBudget(uint64_t bytes);

/// A dump file that the process-exit guard can bring to a consistent state (see Init()).
class ExitFlushable {
 public:
  /// Never blocks: skips the file when its lock cannot be taken (a thread killed inside a write).
  virtual void FlushForExit() = 0;

 protected:
  virtual ~ExitFlushable() = default;
  void RegisterForExit();
  void UnregisterForExit();
};

/// Streaming WAV writer: the header is written at Open and its sizes are patched after every
/// block that is written to the file (blocks of 256 KB) and at Close, so the file on disk is a
/// valid WAV at any moment, whatever happens to the process afterwards.
class WavWriter : public ExitFlushable {
 public:
  WavWriter() = default;
  ~WavWriter() { Close(); }
  WavWriter(const WavWriter&) = delete;
  WavWriter& operator=(const WavWriter&) = delete;

  /// format_tag 1 = integer PCM, 3 = IEEE float.
  bool Open(const std::string& path, uint16_t format_tag, uint16_t channels, uint32_t rate,
            uint16_t bits);
  void Write(const void* data, size_t bytes);
  void Close();
  bool is_open() const { return file_ != nullptr; }
  uint64_t data_bytes() const { return data_bytes_; }
  /// Number of blocks written to the file so far (changes when the file on disk has grown).
  uint32_t flushes() const { return flushes_; }
  void FlushForExit() override;

 private:
  void FlushLocked();
  std::mutex mutex_;
  std::FILE* file_ = nullptr;
  uint64_t data_bytes_ = 0;
  uint32_t flushes_ = 0;
  std::vector<uint8_t> buffer_;
};

/// Plain append-only file with the same budget.
class RawWriter : public ExitFlushable {
 public:
  RawWriter() = default;
  ~RawWriter() { Close(); }
  RawWriter(const RawWriter&) = delete;
  RawWriter& operator=(const RawWriter&) = delete;

  bool Open(const std::string& path);
  void Write(const void* data, size_t bytes);
  void Close();
  bool is_open() const { return file_ != nullptr; }
  uint64_t bytes() const { return bytes_; }
  void FlushForExit() override;

 private:
  std::mutex mutex_;
  std::FILE* file_ = nullptr;
  uint64_t bytes_ = 0;
};

/// 64-bit FNV-1a, for telling input buffers apart.
inline uint64_t Fnv1a(const uint8_t* data, size_t bytes, uint64_t h = 1469598103934665603ull) {
  for (size_t i = 0; i < bytes; ++i) {
    h ^= data[i];
    h *= 1099511628211ull;
  }
  return h;
}

/// A new number for file names (xma_ctx<id>_s<number>...).
uint32_t NextSession();

}  // namespace rex::audio::dump
