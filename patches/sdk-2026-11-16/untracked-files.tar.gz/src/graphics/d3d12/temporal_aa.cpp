/**
 * Temporal anti-aliasing (rexglue-temporal-aa.patch), Direct3D 12: see
 * CommandProcessor::TaaFrame and D3D12CommandProcessor::TaaRun.
 */

#include <atomic>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <string>
#include <thread>
#include <vector>

#include <rex/filesystem.h>
#include <rex/graphics/d3d12/command_processor.h>
#include <rex/graphics/flags.h>
#include <rex/logging.h>
#include <rex/platform/dynlib.h>
#include <rex/ui/d3d12/d3d12_util.h>

#include "../temporal_aa_fsr.h"

#if defined(REX_HAS_FSR) && REX_HAS_FSR
#include <ffx_api/dx12/ffx_api_dx12.h>
#endif

namespace rex::graphics::d3d12 {

namespace shaders {
#include "../shaders/bytecode/d3d12_5_1/taa_debug_view_cs.h"
#include "../shaders/bytecode/d3d12_5_1/taa_luma_snapshot_cs.h"
#include "../shaders/bytecode/d3d12_5_1/taa_motion_vectors_mcla_cs.h"
#include "../shaders/bytecode/d3d12_5_1/taa_reactive_mcla_cs.h"
#include "../shaders/bytecode/d3d12_5_1/taa_upscale_gather_mcla_cs.h"
}  // namespace shaders

struct D3D12CommandProcessor::TaaFsr {
  // kVectorsOnly: the motion vectors' texture alone, without FSR's context
  // (frame generation without FSR anti-aliasing).
  enum State : uint32_t { kNone, kCreating, kReady, kFailed, kVectorsOnly };
  std::atomic<uint32_t> state{kNone};
  std::thread thread;
  // The size of the context and the textures (the scene's, host pixels): the output's, and
  // the size FSR renders at (smaller with upscaling; the vectors are of that size).
  uint32_t width = 0;
  uint32_t height = 0;
  uint32_t render_width = 0;
  uint32_t render_height = 0;
  Microsoft::WRL::ComPtr<ID3D12Resource> vectors;  // R16G16_FLOAT
  Microsoft::WRL::ComPtr<ID3D12Resource> output;   // R16G16B16A16_FLOAT
  // With upscaling, FSR's colour and depth inputs, gathered at the render size.
  Microsoft::WRL::ComPtr<ID3D12Resource> color_in;  // R16G16B16A16_FLOAT
  Microsoft::WRL::ComPtr<ID3D12Resource> depth_in;  // R32_FLOAT
  D3D12_RESOURCE_STATES vectors_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  D3D12_RESOURCE_STATES output_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  D3D12_RESOURCE_STATES color_in_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  D3D12_RESOURCE_STATES depth_in_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  // The reactive mask: the luminance snapshots (R16_FLOAT) and the mask
  // (R8_UNORM), made with the first snapshot.
  Microsoft::WRL::ComPtr<ID3D12Resource> luma[2];
  Microsoft::WRL::ComPtr<ID3D12Resource> reactive;
  D3D12_RESOURCE_STATES luma_state[2] = {D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                                         D3D12_RESOURCE_STATE_UNORDERED_ACCESS};
  D3D12_RESOURCE_STATES reactive_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  FsrRuntime runtime;
  ffxContext context = nullptr;
#endif
  // Set on the submission thread when FSR's dispatch failed.
  std::atomic<bool> dispatch_failed{false};
  // Released, destroyed once the submissions that may use them are done.
  struct Retired {
    uint64_t submission;
    Microsoft::WRL::ComPtr<ID3D12Resource> resources[7];
    void* context;
  };
  std::vector<Retired> retired;
  // temporal_aa_debug 4: timestamps around the passes, a pair per slot, each
  // slot read back once its submission is done.
  static constexpr uint32_t kTimerSlots = 8;
  Microsoft::WRL::ComPtr<ID3D12QueryHeap> timer_heap;
  Microsoft::WRL::ComPtr<ID3D12Resource> timer_readback;
  uint64_t timer_submission[kTimerSlots] = {};  // 0: free
  uint32_t timer_next = 0;
  double timer_tick_ms = 0.0;
  double timer_ms = 0.0;
  uint32_t timer_count = 0;
};

namespace {

#if defined(REX_HAS_FSR) && REX_HAS_FSR
struct TaaFsrDispatch {
  PfnFfxDispatch dispatch;
  // The context's handle as it was when recorded (a later one may replace it
  // before this is executed).
  ffxContext context;
  std::atomic<bool>* failed;
  ffxDispatchDescUpscale desc;
};

void TaaFsrDispatchCallback(ID3D12GraphicsCommandList* command_list, const void* data) {
  TaaFsrDispatch dispatch;
  std::memcpy(&dispatch, data, sizeof(dispatch));
  dispatch.desc.commandList = command_list;
  ffxContext context = dispatch.context;
  ffxReturnCode_t result = dispatch.dispatch(&context, &dispatch.desc.header);
  if (result == FFX_API_RETURN_OK) {
    return;
  }
  // The scene as it was into the output, which is copied back into it next:
  // the frame is left as it was (FSR is given up at the end of the frame).
  dispatch.failed->store(true, std::memory_order_release);
  auto* color = static_cast<ID3D12Resource*>(dispatch.desc.color.resource);
  auto* output = static_cast<ID3D12Resource*>(dispatch.desc.output.resource);
  const D3D12_RESOURCE_STATES color_state =
      D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
  D3D12_RESOURCE_BARRIER barriers[2] = {};
  for (uint32_t i = 0; i < 2; ++i) {
    barriers[i].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barriers[i].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
  }
  barriers[0].Transition.pResource = color;
  barriers[0].Transition.StateBefore = color_state;
  barriers[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
  barriers[1].Transition.pResource = output;
  barriers[1].Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  barriers[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
  command_list->ResourceBarrier(2, barriers);
  D3D12_TEXTURE_COPY_LOCATION dest = {output, D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX, {}};
  D3D12_TEXTURE_COPY_LOCATION source = {color, D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX, {}};
  dest.SubresourceIndex = 0;
  source.SubresourceIndex = 0;
  command_list->CopyTextureRegion(&dest, 0, 0, 0, &source, nullptr);
  for (D3D12_RESOURCE_BARRIER& barrier : barriers) {
    std::swap(barrier.Transition.StateBefore, barrier.Transition.StateAfter);
  }
  command_list->ResourceBarrier(2, barriers);
  static std::atomic<bool> failure_logged{false};
  if (!failure_logged.exchange(true)) {
    REXGPU_ERROR("Temporal AA: FSR's dispatch failed ({}); giving FSR up", result);
  }
}
#endif

}  // namespace

void D3D12CommandProcessor::TaaFsrDeleter::operator()(TaaFsr* fsr) const {
  if (fsr->thread.joinable()) {
    fsr->thread.join();
  }
  delete fsr;
}

bool D3D12CommandProcessor::TaaReady() const {
  // Made for the size it is asked for now (the render size changes with the ratio).
  return taa_fsr_ && taa_fsr_->state.load(std::memory_order_acquire) == TaaFsr::kReady &&
         taa_fsr_->width == taa_up_.out_width && taa_fsr_->height == taa_up_.out_height &&
         taa_fsr_->render_width == taa_up_.render_width &&
         taa_fsr_->render_height == taa_up_.render_height;
}

bool D3D12CommandProcessor::TaaUpscaleSupported() const {
  // The scene is squeezed into host render targets and read back by resolves that stretch.
  return render_target_cache_ && render_target_cache_->DirectResolveStretchPossible() &&
         REXCVAR_GET(direct_host_resolve);
}

ID3D12Resource* D3D12CommandProcessor::TaaFrameVectors() const {
  // Frame generation (rexglue-frame-generation.patch).
  return taa_fsr_ && taa_frame_.done ? taa_fsr_->vectors.Get() : nullptr;
}

bool D3D12CommandProcessor::TaaCheckAvailable() {
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  // Loaded (and kept), not only looked for: a DLL whose imports fail (the Visual C++ runtime
  // missing) is there and unusable.
  std::string error;
  switch (rex::platform::CheckLoadable(
      rex::filesystem::GetExecutableFolder() / "amd_fidelityfx_dx12.dll", &error)) {
    case rex::platform::LibraryCheck::kLoads:
      return true;
    case rex::platform::LibraryCheck::kFailed:
      REXGPU_WARN("Temporal AA: amd_fidelityfx_dx12.dll is there but doesn't load ({})", error);
      return false;
    default:
      return false;
  }
#else
  return false;
#endif
}

void D3D12CommandProcessor::TaaRelease() {
  if (!taa_fsr_) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  if (fsr.thread.joinable()) {
    fsr.thread.join();
  }
  // The GPU and the submission thread may still use the context and the
  // textures: destroyed once the submissions so far are done.
  TaaFsr::Retired retired = {submission_current_,
                             {fsr.vectors, fsr.output, fsr.luma[0], fsr.luma[1], fsr.reactive,
                              fsr.color_in, fsr.depth_in},
                             nullptr};
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  retired.context = fsr.context;
  fsr.context = nullptr;
#endif
  bool released = retired.context != nullptr;
  for (const auto& resource : retired.resources) {
    released |= resource != nullptr;
  }
  if (released) {
    fsr.retired.push_back(std::move(retired));
    REXGPU_INFO("Temporal AA: FSR released");
  }
  fsr.vectors.Reset();
  fsr.output.Reset();
  fsr.luma[0].Reset();
  fsr.luma[1].Reset();
  fsr.reactive.Reset();
  fsr.color_in.Reset();
  fsr.depth_in.Reset();
  fsr.width = 0;
  fsr.height = 0;
  fsr.render_width = 0;
  fsr.render_height = 0;
  fsr.dispatch_failed.store(false, std::memory_order_relaxed);
  fsr.state.store(TaaFsr::kNone, std::memory_order_release);
}

void D3D12CommandProcessor::TaaCollectRetired(bool all) {
  if (!taa_fsr_) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  for (auto it = fsr.retired.begin(); it != fsr.retired.end();) {
    if (!all && it->submission > GetCompletedSubmission()) {
      ++it;
      continue;
    }
#if defined(REX_HAS_FSR) && REX_HAS_FSR
    if (it->context) {
      ffxContext context = it->context;
      fsr.runtime.destroy(&context, nullptr);
    }
#endif
    it = fsr.retired.erase(it);
  }
}

void D3D12CommandProcessor::TaaFrameEnd() {
  TaaCollectRetired(false);
}

uint32_t D3D12CommandProcessor::TaaTimerBegin() {
  if (TaaDebug() != 4 || !taa_fsr_) {
    return UINT32_MAX;
  }
  TaaFsr& fsr = *taa_fsr_;
  if (!fsr.timer_heap) {
    ID3D12Device* device = GetD3D12Provider().GetDevice();
    D3D12_QUERY_HEAP_DESC heap_desc = {D3D12_QUERY_HEAP_TYPE_TIMESTAMP, 2 * TaaFsr::kTimerSlots, 0};
    D3D12_RESOURCE_DESC desc = {};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    desc.Width = 2 * TaaFsr::kTimerSlots * sizeof(uint64_t);
    desc.Height = 1;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    UINT64 frequency = 0;
    if (FAILED(device->CreateQueryHeap(&heap_desc, IID_PPV_ARGS(&fsr.timer_heap))) ||
        FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesReadback, D3D12_HEAP_FLAG_NONE, &desc,
            D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&fsr.timer_readback))) ||
        FAILED(GetD3D12Provider().GetDirectQueue()->GetTimestampFrequency(&frequency)) ||
        !frequency) {
      fsr.timer_heap.Reset();
      fsr.timer_readback.Reset();
      return UINT32_MAX;
    }
    fsr.timer_tick_ms = 1000.0 / double(frequency);
  }
  TaaTimerCollect();
  uint32_t slot = fsr.timer_next;
  if (fsr.timer_submission[slot]) {
    return UINT32_MAX;
  }
  fsr.timer_next = (slot + 1) % TaaFsr::kTimerSlots;
  deferred_command_list_.D3DEndQuery(fsr.timer_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, slot * 2);
  return slot;
}

void D3D12CommandProcessor::TaaTimerEnd(uint32_t slot) {
  if (slot == UINT32_MAX) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  deferred_command_list_.D3DEndQuery(fsr.timer_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP,
                                     slot * 2 + 1);
  deferred_command_list_.D3DResolveQueryData(fsr.timer_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP,
                                             slot * 2, 2, fsr.timer_readback.Get(),
                                             slot * 2 * sizeof(uint64_t));
  fsr.timer_submission[slot] = submission_current_;
}

void D3D12CommandProcessor::TaaTimerCollect() {
  if (!taa_fsr_ || !taa_fsr_->timer_readback) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  for (uint32_t slot = 0; slot < TaaFsr::kTimerSlots; ++slot) {
    if (!fsr.timer_submission[slot] || fsr.timer_submission[slot] > GetCompletedSubmission()) {
      continue;
    }
    fsr.timer_submission[slot] = 0;
    D3D12_RANGE range = {slot * 2 * sizeof(uint64_t), (slot * 2 + 2) * sizeof(uint64_t)};
    void* mapping;
    if (SUCCEEDED(fsr.timer_readback->Map(0, &range, &mapping))) {
      const uint64_t* ticks =
          reinterpret_cast<const uint64_t*>(static_cast<const uint8_t*>(mapping) + range.Begin);
      if (ticks[1] > ticks[0]) {
        fsr.timer_ms += double(ticks[1] - ticks[0]) * fsr.timer_tick_ms;
        ++fsr.timer_count;
      }
      D3D12_RANGE written = {0, 0};
      fsr.timer_readback->Unmap(0, &written);
    }
  }
}

void D3D12CommandProcessor::TaaTakeGpuTime(double& ms_out, uint32_t& count_out) {
  ms_out = 0.0;
  count_out = 0;
  if (!taa_fsr_) {
    return;
  }
  TaaTimerCollect();
  ms_out = taa_fsr_->timer_ms;
  count_out = taa_fsr_->timer_count;
  taa_fsr_->timer_ms = 0.0;
  taa_fsr_->timer_count = 0;
}

bool D3D12CommandProcessor::TaaCreatePipeline() {
  if (taa_vectors_pipeline_ && taa_luma_pipeline_ && taa_reactive_pipeline_ &&
      taa_debug_pipeline_) {
    return true;
  }
  if (taa_pipeline_failed_) {
    return false;
  }
  const ui::d3d12::D3D12Provider& provider = GetD3D12Provider();
  // The first parameter: constants (root constants, or a CBV if 0), then a
  // table of one SRV for each texture and one of a UAV.
  auto create = [&](uint32_t constant_count, uint32_t texture_count, const void* shader,
                    size_t shader_size, Microsoft::WRL::ComPtr<ID3D12RootSignature>& root_signature,
                    Microsoft::WRL::ComPtr<ID3D12PipelineState>& pipeline) {
    D3D12_ROOT_PARAMETER parameters[5];
    D3D12_DESCRIPTOR_RANGE ranges[4];
    if (constant_count) {
      parameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
      parameters[0].Constants = {0, 0, constant_count};
    } else {
      parameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_CBV;
      parameters[0].Descriptor = {0, 0};
    }
    parameters[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    for (uint32_t i = 0; i <= texture_count; ++i) {
      bool uav = i == texture_count;
      ranges[i] = {uav ? D3D12_DESCRIPTOR_RANGE_TYPE_UAV : D3D12_DESCRIPTOR_RANGE_TYPE_SRV, 1,
                   uav ? 0 : i, 0, 0};
      parameters[1 + i].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
      parameters[1 + i].DescriptorTable = {1, &ranges[i]};
      parameters[1 + i].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    }
    D3D12_ROOT_SIGNATURE_DESC desc = {texture_count + 2, parameters, 0, nullptr,
                                      D3D12_ROOT_SIGNATURE_FLAG_NONE};
    *(root_signature.ReleaseAndGetAddressOf()) =
        ui::d3d12::util::CreateRootSignature(provider, desc);
    if (root_signature) {
      *(pipeline.ReleaseAndGetAddressOf()) = ui::d3d12::util::CreateComputePipeline(
          provider.GetDevice(), shader, shader_size, root_signature.Get());
    }
    return bool(pipeline);
  };
  if (!create(0, 2, shaders::taa_motion_vectors_mcla_cs,
              sizeof(shaders::taa_motion_vectors_mcla_cs), taa_vectors_root_signature_,
              taa_vectors_pipeline_) ||
      !create(4, 1, shaders::taa_luma_snapshot_cs, sizeof(shaders::taa_luma_snapshot_cs),
              taa_luma_root_signature_, taa_luma_pipeline_) ||
      !create(8, 3, shaders::taa_reactive_mcla_cs, sizeof(shaders::taa_reactive_mcla_cs),
              taa_reactive_root_signature_, taa_reactive_pipeline_) ||
      !create(4, 3, shaders::taa_debug_view_cs, sizeof(shaders::taa_debug_view_cs),
              taa_debug_root_signature_, taa_debug_pipeline_)) {
    REXGPU_ERROR("Temporal AA: failed to create the pipelines");
    taa_pipeline_failed_ = true;
    return false;
  }
  return true;
}

bool D3D12CommandProcessor::TaaCreateGatherPipeline() {
  if (taa_gather_pipeline_) {
    return true;
  }
  if (taa_pipeline_failed_) {
    return false;
  }
  const ui::d3d12::D3D12Provider& provider = GetD3D12Provider();
  // The constants (a CBV), then a table for each of the three textures (t0-t2) and each of
  // the three images (u0-u2).
  D3D12_ROOT_PARAMETER parameters[7];
  D3D12_DESCRIPTOR_RANGE ranges[6];
  parameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_CBV;
  parameters[0].Descriptor = {0, 0};
  parameters[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
  for (uint32_t i = 0; i < 6; ++i) {
    bool uav = i >= 3;
    ranges[i] = {uav ? D3D12_DESCRIPTOR_RANGE_TYPE_UAV : D3D12_DESCRIPTOR_RANGE_TYPE_SRV, 1,
                 uav ? i - 3 : i, 0, 0};
    parameters[1 + i].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    parameters[1 + i].DescriptorTable = {1, &ranges[i]};
    parameters[1 + i].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
  }
  D3D12_ROOT_SIGNATURE_DESC desc = {7, parameters, 0, nullptr, D3D12_ROOT_SIGNATURE_FLAG_NONE};
  *(taa_gather_root_signature_.ReleaseAndGetAddressOf()) =
      ui::d3d12::util::CreateRootSignature(provider, desc);
  if (taa_gather_root_signature_) {
    *(taa_gather_pipeline_.ReleaseAndGetAddressOf()) = ui::d3d12::util::CreateComputePipeline(
        provider.GetDevice(), shaders::taa_upscale_gather_mcla_cs,
        sizeof(shaders::taa_upscale_gather_mcla_cs), taa_gather_root_signature_.Get());
  }
  if (!taa_gather_pipeline_) {
    REXGPU_ERROR("FSR upscaling: failed to create the gather pipeline");
    taa_pipeline_failed_ = true;
    return false;
  }
  return true;
}

bool D3D12CommandProcessor::TaaEnsureReactiveTextures() {
  TaaFsr& fsr = *taa_fsr_;
  if (fsr.reactive) {
    return true;
  }
  ID3D12Device* device = GetD3D12Provider().GetDevice();
  D3D12_RESOURCE_DESC desc = {};
  desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
  desc.Width = fsr.width;
  desc.Height = fsr.height;
  desc.DepthOrArraySize = 1;
  desc.MipLevels = 1;
  desc.SampleDesc.Count = 1;
  desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
  for (uint32_t i = 0; i < 3; ++i) {
    desc.Format = i < 2 ? DXGI_FORMAT_R16_FLOAT : DXGI_FORMAT_R8_UNORM;
    Microsoft::WRL::ComPtr<ID3D12Resource>& resource = i < 2 ? fsr.luma[i] : fsr.reactive;
    if (FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, D3D12_HEAP_FLAG_NONE, &desc,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&resource)))) {
      REXGPU_ERROR("Temporal AA: failed to create the reactive mask's textures");
      fsr.luma[0].Reset();
      fsr.luma[1].Reset();
      fsr.reactive.Reset();
      return false;
    }
  }
  fsr.luma[0]->SetName(L"Temporal AA opaque luminance");
  fsr.luma[1]->SetName(L"Temporal AA composite luminance");
  fsr.reactive->SetName(L"Temporal AA reactive mask");
  fsr.luma_state[0] = fsr.luma_state[1] = fsr.reactive_state =
      D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  return true;
}

bool D3D12CommandProcessor::TaaSnapshot(uint32_t slot, uint32_t color_target_key) {
  if (!TaaReady() || slot > 1 || !TaaCreatePipeline() || !TaaEnsureReactiveTextures() ||
      !BeginSubmission(true)) {
    return false;
  }
  TaaFsr& fsr = *taa_fsr_;
  ui::d3d12::util::DescriptorCpuGpuHandlePair descriptors[2];
  if (!RequestOneUseSingleViewDescriptors(2, descriptors)) {
    return false;
  }
  uint32_t width, height;
  if (!render_target_cache_->TaaBeginReadColorTarget(color_target_key, descriptors[0].first, width,
                                                     height)) {
    return false;
  }
  if (width < fsr.width || height < fsr.height) {
    render_target_cache_->TaaEndReadColorTarget(color_target_key);
    return false;
  }
  D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
  uav_desc.Format = DXGI_FORMAT_R16_FLOAT;
  uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
  GetD3D12Provider().GetDevice()->CreateUnorderedAccessView(fsr.luma[slot].Get(), nullptr,
                                                            &uav_desc, descriptors[1].first);
  PushTransitionBarrier(fsr.luma[slot].Get(), fsr.luma_state[slot],
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
  fsr.luma_state[slot] = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  SubmitBarriers();
  uint32_t constants[4] = {fsr.width, fsr.height, 0, 0};
  deferred_command_list_.D3DSetComputeRootSignature(taa_luma_root_signature_.Get());
  SetExternalPipeline(taa_luma_pipeline_.Get());
  deferred_command_list_.D3DSetComputeRoot32BitConstants(0, 4, constants, 0);
  deferred_command_list_.D3DSetComputeRootDescriptorTable(1, descriptors[0].second);
  deferred_command_list_.D3DSetComputeRootDescriptorTable(2, descriptors[1].second);
  deferred_command_list_.D3DDispatch((fsr.width + 15) / 16, (fsr.height + 7) / 8, 1);
  PushTransitionBarrier(fsr.luma[slot].Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
  fsr.luma_state[slot] = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
  // The draws that follow need it as a render target.
  render_target_cache_->TaaEndReadColorTarget(color_target_key);
  SubmitBarriers();
  return true;
}

void D3D12CommandProcessor::TaaRunReactive(const D3D12Shader::TextureBinding& stencil_binding) {
  TaaFsr& fsr = *taa_fsr_;
  ui::d3d12::util::DescriptorCpuGpuHandlePair descriptors[4];
  uint32_t one_use_count = bindless_resources_used_ ? 3 : 4;
  if (!RequestOneUseSingleViewDescriptors(one_use_count, descriptors)) {
    taa_frame_.snapshots = 0;
    return;
  }
  ID3D12Device* device = GetD3D12Provider().GetDevice();
  D3D12_SHADER_RESOURCE_VIEW_DESC srv_desc = {};
  srv_desc.Format = DXGI_FORMAT_R16_FLOAT;
  srv_desc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
  srv_desc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
  srv_desc.Texture2D.MipLevels = 1;
  D3D12_GPU_DESCRIPTOR_HANDLE tables[4];
  for (uint32_t i = 0; i < 2; ++i) {
    device->CreateShaderResourceView(fsr.luma[i].Get(), &srv_desc, descriptors[i].first);
    tables[i] = descriptors[i].second;
  }
  if (bindless_resources_used_) {
    tables[2] = GetD3D12Provider().OffsetViewDescriptor(
        view_bindless_heap_gpu_start_,
        texture_cache_->GetActiveTextureBindlessSRVIndex(stencil_binding));
  } else {
    texture_cache_->WriteActiveTextureBindfulSRV(stencil_binding, descriptors[3].first);
    tables[2] = descriptors[3].second;
  }
  D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
  uav_desc.Format = DXGI_FORMAT_R8_UNORM;
  uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
  device->CreateUnorderedAccessView(fsr.reactive.Get(), nullptr, &uav_desc, descriptors[2].first);
  tables[3] = descriptors[2].second;
  PushTransitionBarrier(fsr.reactive.Get(), fsr.reactive_state,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
  fsr.reactive_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  SubmitBarriers();
  uint32_t constants[8] = {fsr.width, fsr.height, uint32_t(taa_vector_constants_.jitter[2]), 0};
  TaaReactiveCurve(reinterpret_cast<float*>(&constants[4]));
  deferred_command_list_.D3DSetComputeRootSignature(taa_reactive_root_signature_.Get());
  SetExternalPipeline(taa_reactive_pipeline_.Get());
  deferred_command_list_.D3DSetComputeRoot32BitConstants(0, 8, constants, 0);
  for (uint32_t i = 0; i < 4; ++i) {
    deferred_command_list_.D3DSetComputeRootDescriptorTable(1 + i, tables[i]);
  }
  deferred_command_list_.D3DDispatch((fsr.width + 15) / 16, (fsr.height + 7) / 8, 1);
  PushTransitionBarrier(fsr.reactive.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
  fsr.reactive_state = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
}

void D3D12CommandProcessor::TaaRunDebugView(const D3D12Shader::TextureBinding& scene_binding,
                                            uint32_t mode) {
  TaaFsr& fsr = *taa_fsr_;
  ui::d3d12::util::DescriptorCpuGpuHandlePair descriptors[4];
  if (!RequestOneUseSingleViewDescriptors(bindless_resources_used_ ? 3 : 4, descriptors)) {
    return;
  }
  ID3D12Device* device = GetD3D12Provider().GetDevice();
  D3D12_GPU_DESCRIPTOR_HANDLE tables[4];
  if (bindless_resources_used_) {
    tables[0] = GetD3D12Provider().OffsetViewDescriptor(
        view_bindless_heap_gpu_start_, texture_cache_->GetActiveTextureBindlessSRVIndex(scene_binding));
  } else {
    texture_cache_->WriteActiveTextureBindfulSRV(scene_binding, descriptors[3].first);
    tables[0] = descriptors[3].second;
  }
  D3D12_SHADER_RESOURCE_VIEW_DESC srv_desc = {};
  srv_desc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
  srv_desc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
  srv_desc.Texture2D.MipLevels = 1;
  srv_desc.Format = DXGI_FORMAT_R16G16_FLOAT;
  device->CreateShaderResourceView(fsr.vectors.Get(), &srv_desc, descriptors[0].first);
  tables[1] = descriptors[0].second;
  // No reactive mask this frame: a null view (zeros).
  srv_desc.Format = DXGI_FORMAT_R8_UNORM;
  device->CreateShaderResourceView(taa_frame_.snapshots == 3 ? fsr.reactive.Get() : nullptr,
                                   &srv_desc, descriptors[1].first);
  tables[2] = descriptors[1].second;
  D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
  uav_desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
  uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
  device->CreateUnorderedAccessView(fsr.output.Get(), nullptr, &uav_desc, descriptors[2].first);
  tables[3] = descriptors[2].second;
  uint32_t constants[4] = {fsr.width, fsr.height, mode, 0};
  deferred_command_list_.D3DSetComputeRootSignature(taa_debug_root_signature_.Get());
  SetExternalPipeline(taa_debug_pipeline_.Get());
  deferred_command_list_.D3DSetComputeRoot32BitConstants(0, 4, constants, 0);
  for (uint32_t i = 0; i < 4; ++i) {
    deferred_command_list_.D3DSetComputeRootDescriptorTable(1 + i, tables[i]);
  }
  deferred_command_list_.D3DDispatch((fsr.width + 15) / 16, (fsr.height + 7) / 8, 1);
  PushUAVBarrier(fsr.output.Get());
}

void D3D12CommandProcessor::TaaRun(const D3D12Shader& pixel_shader) {
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  ID3D12Resource* scene = texture_cache_->GetActiveTextureResource(kTaaFetchScene);
  ID3D12Resource* depth = texture_cache_->GetActiveTextureResource(kTaaFetchDepth);
  taa_frame_.status = 't';
  ID3D12Resource* stencil = texture_cache_->GetActiveTextureResource(kTaaFetchStencil);
  if (!scene || !depth || !stencil || !TaaCreatePipeline()) {
    return;
  }
  taa_frame_.status = 'r';
  D3D12_RESOURCE_DESC scene_desc = scene->GetDesc();
  D3D12_RESOURCE_DESC depth_desc = depth->GetDesc();
  D3D12_RESOURCE_DESC stencil_desc = stencil->GetDesc();
  uint32_t width = uint32_t(scene_desc.Width), height = scene_desc.Height;
  // The size FSR renders at (with upscaling, smaller than the output) and whether the scene
  // was squeezed to it in this frame.
  uint32_t render_width = width, render_height = height;
  if (taa_frame_.mode != TaaMode::kVectors && taa_up_.render_width && taa_up_.render_height &&
      taa_up_.render_width <= width && taa_up_.render_height <= height) {
    render_width = taa_up_.render_width;
    render_height = taa_up_.render_height;
  }
  const bool upscale_context = render_width != width || render_height != height;
  const bool squeezed = upscale_context && taa_frame_.up_state == 1;
  // The texture cache may make them typeless (for its loads' views); FSR is
  // given the formats they're sampled as.
  if ((scene_desc.Format != DXGI_FORMAT_R16G16B16A16_FLOAT &&
       scene_desc.Format != DXGI_FORMAT_R16G16B16A16_TYPELESS) ||
      (depth_desc.Format != DXGI_FORMAT_R32_FLOAT &&
       depth_desc.Format != DXGI_FORMAT_R32_TYPELESS) ||
      depth_desc.Width != scene_desc.Width || stencil_desc.Width != scene_desc.Width ||
      stencil_desc.Height != scene_desc.Height ||
      depth_desc.Height != scene_desc.Height) {
    static bool logged = false;
    if (!logged) {
      logged = true;
      REXGPU_WARN("Temporal AA: unexpected textures: scene {}x{} format {}, depth {}x{} format {}",
                  scene_desc.Width, scene_desc.Height, uint32_t(scene_desc.Format), depth_desc.Width,
                  depth_desc.Height, uint32_t(depth_desc.Format));
    }
    return;
  }
  const D3D12Shader::TextureBinding* bindings[2] = {};  // depth (t0), stencil (t1)
  const D3D12Shader::TextureBinding* scene_binding = nullptr;
  for (const D3D12Shader::TextureBinding& binding :
       pixel_shader.GetTextureBindingsAfterTranslation()) {
    if (binding.fetch_constant == kTaaFetchDepth && !bindings[0]) {
      bindings[0] = &binding;
    } else if (binding.fetch_constant == kTaaFetchStencil && !bindings[1]) {
      bindings[1] = &binding;
    } else if (binding.fetch_constant == kTaaFetchScene &&
               (!scene_binding || (scene_binding->is_signed && !binding.is_signed))) {
      // The unsigned binding if there are both.
      scene_binding = &binding;
    }
  }
  if (!bindings[0] || !bindings[1]) {
    taa_frame_.status = 'n';
    return;
  }

  // The upscaler, made for this size on another thread (the first one takes
  // half a second or so); the frames until it's ready are left as they are.
  if (!taa_fsr_) {
    taa_fsr_.reset(new TaaFsr());
  }
  TaaFsr& fsr = *taa_fsr_;
  uint32_t state = fsr.state.load(std::memory_order_acquire);
  const bool vectors_only = taa_frame_.mode == TaaMode::kVectors;
  if (!vectors_only && state == TaaFsr::kVectorsOnly) {
    // FSR wanted now: made with its context from the end of this frame.
    taa_release_pending_ = true;
    return;
  }
  if (state != TaaFsr::kNone && (fsr.width != width || fsr.height != height ||
                                 fsr.render_width != render_width ||
                                 fsr.render_height != render_height)) {
    // Made again for the new size, from the end of this frame (never released
    // in the middle of one).
    taa_release_pending_ = true;
    return;
  }
  if (fsr.dispatch_failed.load(std::memory_order_acquire)) {
    TaaSetUnavailable("its dispatch failed");
    fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
    taa_release_pending_ = true;
    return;
  }
  if (state == TaaFsr::kNone && vectors_only) {
    ID3D12Device* device = GetD3D12Provider().GetDevice();
    D3D12_RESOURCE_DESC desc = {};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width = width;
    desc.Height = height;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.SampleDesc.Count = 1;
    desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
    desc.Format = DXGI_FORMAT_R16G16_FLOAT;
    fsr.width = width;
    fsr.height = height;
    fsr.render_width = width;
    fsr.render_height = height;
    if (FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, D3D12_HEAP_FLAG_NONE, &desc,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&fsr.vectors)))) {
      REXGPU_ERROR("Temporal AA: failed to create the motion vector texture");
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    fsr.vectors_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    fsr.state.store(TaaFsr::kVectorsOnly, std::memory_order_release);
    state = TaaFsr::kVectorsOnly;
  }
  if (state == TaaFsr::kNone) {
    // A failure stays one for this size.
    fsr.width = width;
    fsr.height = height;
    fsr.render_width = render_width;
    fsr.render_height = render_height;
    if (!fsr.runtime.Load("dx12")) {
      TaaSetUnavailable("amd_fidelityfx_dx12.dll couldn't be loaded");
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    ID3D12Device* device = GetD3D12Provider().GetDevice();
    D3D12_RESOURCE_DESC desc = {};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width = render_width;
    desc.Height = render_height;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.SampleDesc.Count = 1;
    desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
    desc.Format = DXGI_FORMAT_R16G16_FLOAT;
    if (FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, D3D12_HEAP_FLAG_NONE, &desc,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&fsr.vectors)))) {
      REXGPU_ERROR("Temporal AA: failed to create the motion vector texture");
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    if (upscale_context) {
      // FSR's colour and depth inputs at the render size.
      desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
      bool made = SUCCEEDED(device->CreateCommittedResource(
          &ui::d3d12::util::kHeapPropertiesDefault, D3D12_HEAP_FLAG_NONE, &desc,
          D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&fsr.color_in)));
      desc.Format = DXGI_FORMAT_R32_FLOAT;
      made = made && SUCCEEDED(device->CreateCommittedResource(
                         &ui::d3d12::util::kHeapPropertiesDefault, D3D12_HEAP_FLAG_NONE, &desc,
                         D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr,
                         IID_PPV_ARGS(&fsr.depth_in)));
      if (!made) {
        REXGPU_ERROR("FSR upscaling: failed to create the colour and depth inputs");
        fsr.vectors.Reset();
        fsr.color_in.Reset();
        fsr.depth_in.Reset();
        fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
        return;
      }
      fsr.color_in->SetName(L"FSR upscaling colour input");
      fsr.depth_in->SetName(L"FSR upscaling depth input");
    }
    desc.Width = width;
    desc.Height = height;
    desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    if (FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, D3D12_HEAP_FLAG_NONE, &desc,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&fsr.output)))) {
      REXGPU_ERROR("Temporal AA: failed to create the output texture");
      fsr.vectors.Reset();
      fsr.color_in.Reset();
      fsr.depth_in.Reset();
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    fsr.vectors_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    fsr.output_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    fsr.color_in_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    fsr.depth_in_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    fsr.width = width;
    fsr.height = height;
    fsr.state.store(TaaFsr::kCreating, std::memory_order_release);
    uint32_t flags = kTaaFsrCreateFlags;
    if (TaaDebug() == 1) {
      flags |= FFX_UPSCALE_ENABLE_DEBUG_CHECKING;
    }
    fsr.thread = std::thread([&fsr, device, width, height, render_width, render_height, flags]() {
      auto start = std::chrono::steady_clock::now();
      ffxCreateBackendDX12Desc backend = {};
      backend.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_BACKEND_DX12;
      backend.device = device;
      ffxCreateContextDescUpscale create = {};
      create.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_UPSCALE;
      create.header.pNext = &backend.header;
      create.flags = flags;
      create.maxRenderSize = {render_width, render_height};
      create.maxUpscaleSize = {width, height};
      create.fpMessage = FsrRuntime::Message;
      ffxReturnCode_t result = fsr.runtime.create(&fsr.context, &create.header, nullptr);
      if (result != FFX_API_RETURN_OK) {
        fsr.context = nullptr;
        REXGPU_ERROR("Temporal AA: creating FSR failed ({})", result);
        TaaSetUnavailable("its context couldn't be created");
        fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
        return;
      }
      REXGPU_INFO("Temporal AA: FSR 3.1 ready for {}x{}{} (Direct3D 12) after {} ms", width, height,
                  render_width != width || render_height != height
                      ? fmt::format(" from {}x{}", render_width, render_height)
                      : std::string(),
                  std::chrono::duration_cast<std::chrono::milliseconds>(
                      std::chrono::steady_clock::now() - start)
                      .count());
      fsr.state.store(TaaFsr::kReady, std::memory_order_release);
    });
    return;
  }
  if (state != TaaFsr::kReady && state != TaaFsr::kVectorsOnly) {
    taa_frame_.status = state == TaaFsr::kCreating ? 'c' : 'x';
    return;
  }
  if (fsr.thread.joinable()) {
    fsr.thread.join();
  }

  // The motion vectors (with upscaling, also FSR's colour and depth inputs, gathered at the
  // render size from the output-size textures of the squeezed scene).
  if (upscale_context && !squeezed) {
    // FSR was made for a smaller render size and this frame wasn't squeezed (4x MSAA, another
    // surface): it doesn't run in it.
    taa_frame_.status = 'u';
    return;
  }
  const ui::d3d12::D3D12Provider& provider = GetD3D12Provider();
  TaaVectorConstants& constants = taa_vector_constants_;
  xenos::xe_gpu_texture_fetch_t scene_fetch = register_file_->GetTextureFetch(kTaaFetchScene);
  constants.size[0] = float(render_width);
  constants.size[1] = float(render_height);
  constants.size[2] = float(render_width) / float(scene_fetch.size_2d.width + 1);
  constants.size[3] = float(render_height) / float(scene_fetch.size_2d.height + 1);
  // The stencil is the stencil view's first byte (red): where the fetch
  // constant's swizzle puts it.
  uint32_t stencil_swizzle = texture_cache_->GetActiveTextureHostSwizzle(kTaaFetchStencil);
  constants.jitter[2] = 0.0f;
  for (uint32_t i = 0; i < 4; ++i) {
    if (((stencil_swizzle >> (3 * i)) & 7) == xenos::XE_GPU_TEXTURE_SWIZZLE_R) {
      constants.jitter[2] = float(i);
      break;
    }
  }
  static bool swizzle_logged = false;
  if (!swizzle_logged) {
    swizzle_logged = true;
    REXGPU_INFO(
        "Temporal AA: stencil view swizzle {:03X}, the stencil in component {}; scene swizzle "
        "{:03X}, depth swizzle {:03X}",
        stencil_swizzle, constants.jitter[2], texture_cache_->GetActiveTextureHostSwizzle(kTaaFetchScene),
        texture_cache_->GetActiveTextureHostSwizzle(kTaaFetchDepth));
  }
  // The gather pass has the output and render sizes after the vectors' constants.
  struct GatherConstants {
    TaaVectorConstants vectors;
    uint32_t map[4];
  } gather_constants;
  gather_constants.vectors = constants;
  gather_constants.map[0] = width;
  gather_constants.map[1] = height;
  gather_constants.map[2] = render_width;
  gather_constants.map[3] = render_height;
  D3D12_GPU_VIRTUAL_ADDRESS constants_address;
  uint8_t* constants_mapping = constant_buffer_pool_->Request(
      frame_current_, sizeof(gather_constants), D3D12_CONSTANT_BUFFER_DATA_PLACEMENT_ALIGNMENT,
      nullptr, nullptr, &constants_address);
  if (!constants_mapping) {
    return;
  }
  std::memcpy(constants_mapping, squeezed ? static_cast<const void*>(&gather_constants)
                                          : static_cast<const void*>(&constants),
              squeezed ? sizeof(gather_constants) : sizeof(constants));
  uint32_t timer_slot;
  if (!squeezed) {
    ui::d3d12::util::DescriptorCpuGpuHandlePair descriptors[3];
    uint32_t one_use_count = bindless_resources_used_ ? 1 : 3;
    if (!RequestOneUseSingleViewDescriptors(one_use_count, descriptors)) {
      return;
    }
    D3D12_GPU_DESCRIPTOR_HANDLE tables[3];
    for (uint32_t i = 0; i < 2; ++i) {
      if (bindless_resources_used_) {
        tables[i] = provider.OffsetViewDescriptor(
            view_bindless_heap_gpu_start_,
            texture_cache_->GetActiveTextureBindlessSRVIndex(*bindings[i]));
      } else {
        texture_cache_->WriteActiveTextureBindfulSRV(*bindings[i], descriptors[1 + i].first);
        tables[i] = descriptors[1 + i].second;
      }
    }
    D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
    uav_desc.Format = DXGI_FORMAT_R16G16_FLOAT;
    uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
    provider.GetDevice()->CreateUnorderedAccessView(fsr.vectors.Get(), nullptr, &uav_desc,
                                                    descriptors[0].first);
    tables[2] = descriptors[0].second;
    PushTransitionBarrier(fsr.vectors.Get(), fsr.vectors_state,
                          D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    fsr.vectors_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    SubmitBarriers();
    timer_slot = TaaTimerBegin();
    deferred_command_list_.D3DSetComputeRootSignature(taa_vectors_root_signature_.Get());
    SetExternalPipeline(taa_vectors_pipeline_.Get());
    deferred_command_list_.D3DSetComputeRootConstantBufferView(0, constants_address);
    for (uint32_t i = 0; i < 3; ++i) {
      deferred_command_list_.D3DSetComputeRootDescriptorTable(1 + i, tables[i]);
    }
    deferred_command_list_.D3DDispatch((render_width + 15) / 16, (render_height + 7) / 8, 1);
  } else {
    if (!TaaCreateGatherPipeline()) {
      taa_frame_.status = 'n';
      return;
    }
    ui::d3d12::util::DescriptorCpuGpuHandlePair descriptors[6];
    if (!RequestOneUseSingleViewDescriptors(bindless_resources_used_ ? 4 : 6, descriptors)) {
      return;
    }
    // t0 the depth, t1 the stencil view (the texture cache's), t2 the scene (a view made here
    // over the resource FSR reads in native mode, as FSR is told its format); u0 the vectors,
    // u1 the colour, u2 the depth, at the render size.
    const D3D12Shader::TextureBinding* srv_bindings[2] = {bindings[0], bindings[1]};
    D3D12_GPU_DESCRIPTOR_HANDLE tables[6];
    for (uint32_t i = 0; i < 2; ++i) {
      if (bindless_resources_used_) {
        tables[i] = provider.OffsetViewDescriptor(
            view_bindless_heap_gpu_start_,
            texture_cache_->GetActiveTextureBindlessSRVIndex(*srv_bindings[i]));
      } else {
        texture_cache_->WriteActiveTextureBindfulSRV(*srv_bindings[i], descriptors[3 + i].first);
        tables[i] = descriptors[3 + i].second;
      }
    }
    {
      const ui::d3d12::util::DescriptorCpuGpuHandlePair& scene_descriptor =
          descriptors[bindless_resources_used_ ? 3 : 5];
      D3D12_SHADER_RESOURCE_VIEW_DESC scene_srv = {};
      scene_srv.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
      scene_srv.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2DARRAY;
      scene_srv.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
      scene_srv.Texture2DArray.MostDetailedMip = 0;
      scene_srv.Texture2DArray.MipLevels = 1;
      scene_srv.Texture2DArray.FirstArraySlice = 0;
      scene_srv.Texture2DArray.ArraySize = 1;
      scene_srv.Texture2DArray.PlaneSlice = 0;
      scene_srv.Texture2DArray.ResourceMinLODClamp = 0.0f;
      provider.GetDevice()->CreateShaderResourceView(scene, &scene_srv, scene_descriptor.first);
      tables[2] = scene_descriptor.second;
    }
    ID3D12Resource* uav_resources[3] = {fsr.vectors.Get(), fsr.color_in.Get(), fsr.depth_in.Get()};
    const DXGI_FORMAT uav_formats[3] = {DXGI_FORMAT_R16G16_FLOAT, DXGI_FORMAT_R16G16B16A16_FLOAT,
                                        DXGI_FORMAT_R32_FLOAT};
    for (uint32_t i = 0; i < 3; ++i) {
      D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
      uav_desc.Format = uav_formats[i];
      uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
      provider.GetDevice()->CreateUnorderedAccessView(uav_resources[i], nullptr, &uav_desc,
                                                      descriptors[i].first);
      tables[3 + i] = descriptors[i].second;
    }
    PushTransitionBarrier(fsr.vectors.Get(), fsr.vectors_state,
                          D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    PushTransitionBarrier(fsr.color_in.Get(), fsr.color_in_state,
                          D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    PushTransitionBarrier(fsr.depth_in.Get(), fsr.depth_in_state,
                          D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    fsr.vectors_state = fsr.color_in_state = fsr.depth_in_state =
        D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    SubmitBarriers();
    timer_slot = TaaTimerBegin();
    deferred_command_list_.D3DSetComputeRootSignature(taa_gather_root_signature_.Get());
    SetExternalPipeline(taa_gather_pipeline_.Get());
    deferred_command_list_.D3DSetComputeRootConstantBufferView(0, constants_address);
    for (uint32_t i = 0; i < 6; ++i) {
      deferred_command_list_.D3DSetComputeRootDescriptorTable(1 + i, tables[i]);
    }
    deferred_command_list_.D3DDispatch((render_width + 15) / 16, (render_height + 7) / 8, 1);
    const D3D12_RESOURCE_STATES read_state =
        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    PushTransitionBarrier(fsr.color_in.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, read_state);
    PushTransitionBarrier(fsr.depth_in.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, read_state);
    fsr.color_in_state = fsr.depth_in_state = read_state;
  }
  PushTransitionBarrier(fsr.vectors.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
  fsr.vectors_state = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
  // Frame generation (rexglue-frame-generation.patch): the depth, for its
  // preparation at the swap; without FSR anti-aliasing, nothing more. With the squeezed
  // scene it is the gathered one, at the render size, like the vectors.
  if (!squeezed) {
    FgCopyDepth(depth, width, height);
  } else {
    // The gather's own transitions of the depth go out first: the copy transitions the
    // same resource again, and one barrier call must not name a subresource twice.
    SubmitBarriers();
    FgCopyDepth(fsr.depth_in.Get(), render_width, render_height, true);
  }
  if (vectors_only) {
    SubmitBarriers();
    taa_frame_.done = true;
    taa_frame_.status = 'v';
    TaaTimerEnd(timer_slot);
    return;
  }
  // The reactive mask, from this frame's snapshots of the scene.
  if (taa_frame_.snapshots == 3 && fsr.reactive) {
    TaaRunReactive(*bindings[1]);
  } else {
    taa_frame_.snapshots = 0;
  }
  PushTransitionBarrier(fsr.output.Get(), fsr.output_state, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
  fsr.output_state = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  SubmitBarriers();
  taa_frame_.done = true;
  taa_frame_.status = '+';
  if (squeezed && TaaDebug() == 9) {
    // Development: the gathered colour in the top-left corner of the scene texture.
    const D3D12_RESOURCE_STATES read_state =
        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    PushTransitionBarrier(fsr.color_in.Get(), read_state, D3D12_RESOURCE_STATE_COPY_SOURCE);
    texture_cache_->TransitionActiveTexture(kTaaFetchScene, D3D12_RESOURCE_STATE_COPY_DEST);
    SubmitBarriers();
    D3D12_TEXTURE_COPY_LOCATION dest_location = {}, source_location = {};
    dest_location.pResource = scene;
    dest_location.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    source_location.pResource = fsr.color_in.Get();
    source_location.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    D3D12_BOX box = {0, 0, 0, render_width, render_height, 1};
    deferred_command_list_.D3DCopyTextureRegion(&dest_location, 0, 0, 0, &source_location, &box);
    PushTransitionBarrier(fsr.color_in.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, read_state);
    texture_cache_->TransitionActiveTexture(kTaaFetchScene,
                                            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE |
                                                D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
    SubmitBarriers();
    TaaTimerEnd(timer_slot);
    return;
  }
  if (TaaDebug() == 3) {
    // The raw (jittered) input.
    TaaTimerEnd(timer_slot);
    return;
  }
  if ((TaaDebug() == 5 || TaaDebug() == 6) && scene_binding && !squeezed) {
    // A development view instead of FSR's output (7 is the upscaling log, not a view).
    TaaRunDebugView(*scene_binding, TaaDebug() - 5);
  } else {

  // FSR, recorded into the real command list where it falls (it restores the
  // states it was given), then the output into the scene texture.
  TaaFsrDispatch dispatch = {};
  dispatch.dispatch = fsr.runtime.dispatch;
  dispatch.context = fsr.context;
  dispatch.failed = &fsr.dispatch_failed;
  ffxDispatchDescUpscale& desc = dispatch.desc;
  desc.header.type = FFX_API_DISPATCH_DESC_TYPE_UPSCALE;
  desc.color = ffxApiGetResourceDX12(squeezed && TaaDebug() != 8 ? fsr.color_in.Get() : scene,
                                     FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ);
  desc.color.description.format = FFX_API_SURFACE_FORMAT_R16G16B16A16_FLOAT;
  desc.depth = ffxApiGetResourceDX12(squeezed ? fsr.depth_in.Get() : depth,
                                     FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ);
  desc.depth.description.format = FFX_API_SURFACE_FORMAT_R32_FLOAT;
  desc.motionVectors = ffxApiGetResourceDX12(fsr.vectors.Get(), FFX_API_RESOURCE_STATE_COMPUTE_READ);
  if (taa_frame_.snapshots == 3) {
    desc.reactive = ffxApiGetResourceDX12(fsr.reactive.Get(), FFX_API_RESOURCE_STATE_COMPUTE_READ);
  }
  desc.output = ffxApiGetResourceDX12(fsr.output.Get(), FFX_API_RESOURCE_STATE_UNORDERED_ACCESS);
  float jitter[2];
  TaaFsrJitter(jitter);
  desc.jitterOffset = {jitter[0], jitter[1]};
  desc.motionVectorScale = {1.0f, 1.0f};
  desc.renderSize = {render_width, render_height};
  desc.upscaleSize = {width, height};
  float sharpness = TaaSharpness();
  desc.enableSharpening = sharpness > 0.0f;
  desc.sharpness = sharpness;
  desc.frameTimeDelta = taa_frame_time_ms_;
  desc.preExposure = 1.0f;
  desc.reset = taa_camera_.reset;
  // (Development, temporal_aa_debug 10: the planes the other way round.)
  desc.cameraNear = TaaDebug() == 10 ? taa_camera_.far_plane : taa_camera_.near_plane;
  desc.cameraFar = TaaDebug() == 10 ? taa_camera_.near_plane : taa_camera_.far_plane;
  desc.cameraFovAngleVertical = taa_camera_.fov_vertical;
  desc.viewSpaceToMetersFactor = 1.0f;
  desc.flags = TaaDebug() == 1 ? FFX_UPSCALE_FLAG_DRAW_DEBUG_VIEW : 0;
  deferred_command_list_.ExternalCallback(TaaFsrDispatchCallback, &dispatch, sizeof(dispatch));
  // FSR set its own descriptor heaps, root signature and pipeline.
  if (bindless_resources_used_) {
    deferred_command_list_.SetDescriptorHeaps(view_bindless_heap_, sampler_bindless_heap_current_);
  } else if (view_bindful_heap_current_ || sampler_bindful_heap_current_) {
    deferred_command_list_.SetDescriptorHeaps(view_bindful_heap_current_,
                                              sampler_bindful_heap_current_);
  }
  current_guest_pipeline_ = nullptr;
  current_external_pipeline_ = nullptr;
  current_graphics_root_signature_ = nullptr;
  current_graphics_root_up_to_date_ = 0;
  }

  texture_cache_->TransitionActiveTexture(kTaaFetchScene, D3D12_RESOURCE_STATE_COPY_DEST);
  PushTransitionBarrier(fsr.output.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_COPY_SOURCE);
  fsr.output_state = D3D12_RESOURCE_STATE_COPY_SOURCE;
  SubmitBarriers();
  D3D12_TEXTURE_COPY_LOCATION copy_dest, copy_source;
  copy_dest.pResource = scene;
  copy_dest.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
  copy_dest.SubresourceIndex = 0;
  copy_source.pResource = fsr.output.Get();
  copy_source.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
  copy_source.SubresourceIndex = 0;
  deferred_command_list_.CopyTexture(copy_dest, copy_source);
  texture_cache_->TransitionActiveTexture(kTaaFetchScene,
                                          D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE |
                                              D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
  TaaTimerEnd(timer_slot);
#else
  (void)pixel_shader;
#endif  // REX_HAS_FSR
}

}  // namespace rex::graphics::d3d12
