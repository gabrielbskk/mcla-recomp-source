/**
 * Frame generation on Direct3D 12 (rexglue-frame-generation.patch): the
 * command processor's part. The presenter generates (AMD FSR 3.1 frame
 * interpolation through AMD's swap chain, d3d12_presenter_frame_generation.cpp)
 * from what the refresher gives it per guest frame: the HUD-less image
 * (hdr_refresh_fg.cs.xesl: the scene's code values before the UI), the depth
 * (copied here at the anti-aliasing draw) and the motion vectors (temporal
 * anti-aliasing's). The compose of a generated frame is hdr_refresh's, from
 * the generated code values with the frame's UI layer and levels, recorded on
 * the presenter's command list inside its present, before the next guest
 * frame's work.
 */

#include <memory>
#include <utility>

#include <rex/cvar.h>
#include <rex/graphics/d3d12/command_processor.h>
#include <rex/logging.h>
#include <rex/ui/d3d12/d3d12_presenter.h>
#include <rex/ui/d3d12/d3d12_util.h>

namespace rex::graphics::d3d12 {

namespace {
// The compose's descriptors per set: u0 the destination, t1 (unused), t0 the
// ramp, t2-t5 (t3 the UI layer, t4 the generated code values), u1 (unused).
constexpr uint32_t kFgComposeViewCount = 8;
}  // namespace

void D3D12CommandProcessor::FgCopyDepth(ID3D12Resource* depth, uint32_t width, uint32_t height,
                                        bool gathered) {
  // `gathered`: FSR upscaling's own render-size depth (after the gather it is in the
  // read state), not the guest's texture.
  const D3D12_RESOURCE_STATES gathered_state =
      D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
  // Only while the presenter takes frame generation's inputs (it decided at
  // start-up, and has its swap chain now).
  if (!frame_generation_inputs_given_) {
    return;
  }
  const ui::d3d12::D3D12Provider& provider = GetD3D12Provider();
  if (fg_depth_) {
    D3D12_RESOURCE_DESC desc = fg_depth_->GetDesc();
    if (desc.Width != width || desc.Height != height) {
      // Released when the GPU is done with it.
      fg_depth_->AddRef();
      resources_for_deletion_.emplace_back(submission_current_, fg_depth_.Get());
      fg_depth_.Reset();
    }
  }
  if (!fg_depth_) {
    D3D12_RESOURCE_DESC desc = {};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width = width;
    desc.Height = height;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.Format = DXGI_FORMAT_R32_FLOAT;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
    if (FAILED(provider.GetDevice()->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, provider.GetHeapFlagCreateNotZeroed(), &desc,
            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, nullptr, IID_PPV_ARGS(&fg_depth_)))) {
      REXGPU_ERROR("Frame generation: couldn't create the {}x{} depth copy", width, height);
      return;
    }
  }
  if (gathered) {
    PushTransitionBarrier(depth, gathered_state, D3D12_RESOURCE_STATE_COPY_SOURCE);
  } else {
    texture_cache_->TransitionActiveTexture(kTaaFetchDepth, D3D12_RESOURCE_STATE_COPY_SOURCE);
  }
  PushTransitionBarrier(fg_depth_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_COPY_DEST);
  SubmitBarriers();
  D3D12_TEXTURE_COPY_LOCATION copy_dest = {};
  copy_dest.pResource = fg_depth_.Get();
  copy_dest.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
  D3D12_TEXTURE_COPY_LOCATION copy_source = {};
  copy_source.pResource = depth;
  copy_source.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
  deferred_command_list_.CopyTexture(copy_dest, copy_source);
  PushTransitionBarrier(fg_depth_.Get(), D3D12_RESOURCE_STATE_COPY_DEST,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
  if (gathered) {
    PushTransitionBarrier(depth, D3D12_RESOURCE_STATE_COPY_SOURCE, gathered_state);
  } else {
    texture_cache_->TransitionActiveTexture(kTaaFetchDepth,
                                            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE |
                                                D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
  }
  fg_depth_frame_ = frame_current_;
}

bool D3D12CommandProcessor::FgEnsureResources(uint32_t width, uint32_t height,
                                              uint32_t generation_width,
                                              uint32_t generation_height) {
  if (!generation_width || !generation_height || generation_width > width ||
      generation_height > height || !fg_downscale_pipeline_) {
    return false;
  }
  const ui::d3d12::D3D12Provider& provider = GetD3D12Provider();
  ID3D12Device* device = provider.GetDevice();
  if (!fg_view_heap_) {
    D3D12_DESCRIPTOR_HEAP_DESC heap_desc = {};
    heap_desc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    heap_desc.NumDescriptors = kFgComposeViewCount * 2;
    heap_desc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    if (FAILED(device->CreateDescriptorHeap(&heap_desc, IID_PPV_ARGS(&fg_view_heap_)))) {
      REXGPU_ERROR("Frame generation: couldn't create the compose's descriptor heap");
      return false;
    }
  }
  D3D12_RESOURCE_DESC desc = {};
  desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
  desc.DepthOrArraySize = 1;
  desc.MipLevels = 1;
  desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
  desc.SampleDesc.Count = 1;
  desc.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
  desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
  if (!fg_dummy_uav_) {
    desc.Width = 1;
    desc.Height = 1;
    if (FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, provider.GetHeapFlagCreateNotZeroed(), &desc,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&fg_dummy_uav_)))) {
      REXGPU_ERROR("Frame generation: couldn't create a texture");
      return false;
    }
  }
  // The full-size image, and the generation-size one if smaller. The presenter
  // may still read the old ones (generation runs in its present, on the queue
  // before this frame's work): released once this submission is done.
  Microsoft::WRL::ComPtr<ID3D12Resource>* images[] = {std::addressof(fg_hudless_),
                                                      std::addressof(fg_hudless_small_)};
  const std::pair<uint32_t, uint32_t> sizes[] = {{width, height},
                                                 {generation_width, generation_height}};
  for (uint32_t i = 0; i < 2; ++i) {
    Microsoft::WRL::ComPtr<ID3D12Resource>* image = images[i];
    const std::pair<uint32_t, uint32_t>& size = sizes[i];
    if (i && generation_width == width && generation_height == height) {
      continue;
    }
    if (*image) {
      D3D12_RESOURCE_DESC image_desc = (*image)->GetDesc();
      if (image_desc.Width == size.first && image_desc.Height == size.second) {
        continue;
      }
      (*image)->AddRef();
      resources_for_deletion_.emplace_back(submission_current_, image->Get());
      image->Reset();
    }
    desc.Width = size.first;
    desc.Height = size.second;
    if (FAILED(device->CreateCommittedResource(
            &ui::d3d12::util::kHeapPropertiesDefault, provider.GetHeapFlagCreateNotZeroed(), &desc,
            D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, nullptr, IID_PPV_ARGS(image->GetAddressOf())))) {
      REXGPU_ERROR("Frame generation: couldn't create a {}x{} HUD-less image", size.first,
                   size.second);
      return false;
    }
  }
  return true;
}

bool D3D12CommandProcessor::FgDownscaleHudless(uint32_t width, uint32_t height,
                                               uint32_t generation_width,
                                               uint32_t generation_height) {
  if (generation_width == width && generation_height == height) {
    return true;
  }
  if (!fg_hudless_small_) {
    return false;
  }
  ui::d3d12::util::DescriptorCpuGpuHandlePair descriptors[2];
  if (!RequestOneUseSingleViewDescriptors(2, descriptors)) {
    return false;
  }
  ID3D12Device* device = GetD3D12Provider().GetDevice();
  D3D12_SHADER_RESOURCE_VIEW_DESC srv_desc = {};
  srv_desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
  srv_desc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
  srv_desc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
  srv_desc.Texture2D.MipLevels = 1;
  device->CreateShaderResourceView(fg_hudless_.Get(), &srv_desc, descriptors[0].first);
  D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
  uav_desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
  uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
  device->CreateUnorderedAccessView(fg_hudless_small_.Get(), nullptr, &uav_desc,
                                    descriptors[1].first);
  PushTransitionBarrier(fg_hudless_small_.Get(), D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
  deferred_command_list_.D3DSetComputeRootSignature(fg_downscale_root_signature_.Get());
  SetExternalPipeline(fg_downscale_pipeline_.Get());
  SubmitBarriers();
  const uint32_t constants[] = {width, height, generation_width, generation_height};
  deferred_command_list_.D3DSetComputeRoot32BitConstants(0, 4, constants, 0);
  deferred_command_list_.D3DSetComputeRootDescriptorTable(1, descriptors[0].second);
  deferred_command_list_.D3DSetComputeRootDescriptorTable(2, descriptors[1].second);
  deferred_command_list_.D3DDispatch((generation_width + 15) / 16, (generation_height + 7) / 8, 1);
  PushTransitionBarrier(fg_hudless_small_.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
  SubmitBarriers();
  return true;
}

bool D3D12CommandProcessor::FgComposeGenerated(void* context,
                                               ID3D12GraphicsCommandList* command_list,
                                               ID3D12Resource* generated, ID3D12Resource* dest) {
  auto& processor = *static_cast<D3D12CommandProcessor*>(context);
  if (!processor.hdr_refresh_fg_pipeline_ || !processor.fg_view_heap_ ||
      !processor.fg_dummy_uav_) {
    return false;
  }
  const ui::d3d12::D3D12Provider& provider = processor.GetD3D12Provider();
  ID3D12Device* device = provider.GetDevice();
  // The other set than the previous compose's (the proxy's Present waits for
  // the previous generation's work before calling for this one).
  processor.fg_view_set_ ^= 1;
  const uint32_t base = processor.fg_view_set_ * kFgComposeViewCount;
  D3D12_CPU_DESCRIPTOR_HANDLE cpu = processor.fg_view_heap_->GetCPUDescriptorHandleForHeapStart();
  D3D12_GPU_DESCRIPTOR_HANDLE gpu = processor.fg_view_heap_->GetGPUDescriptorHandleForHeapStart();
  auto cpu_at = [&](uint32_t i) { return provider.OffsetViewDescriptor(cpu, base + i); };
  auto gpu_at = [&](uint32_t i) { return provider.OffsetViewDescriptor(gpu, base + i); };
  D3D12_UNORDERED_ACCESS_VIEW_DESC uav_desc = {};
  uav_desc.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
  uav_desc.Format = ui::d3d12::D3D12Presenter::kGuestOutputFormat;
  device->CreateUnorderedAccessView(dest, nullptr, &uav_desc, cpu_at(0));
  processor.HdrWriteTextureSRV(kHdrTextureUiLayer, cpu_at(1));
  processor.WriteGammaRampSRV(processor.fg_compose_pwl_, cpu_at(2));
  processor.HdrWriteTextureSRV(kHdrTextureUiLayer, cpu_at(3));
  processor.HdrWriteTextureSRV(kHdrTextureUiLayer, cpu_at(4));
  D3D12_SHADER_RESOURCE_VIEW_DESC srv_desc = {};
  srv_desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
  srv_desc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
  srv_desc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
  srv_desc.Texture2D.MipLevels = 1;
  device->CreateShaderResourceView(generated, &srv_desc, cpu_at(5));
  processor.HdrWriteTextureSRV(kHdrTextureUiLayer, cpu_at(6));
  uav_desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
  device->CreateUnorderedAccessView(processor.fg_dummy_uav_.Get(), nullptr, &uav_desc, cpu_at(7));

  D3D12_RESOURCE_BARRIER barrier = {};
  barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
  barrier.Transition.pResource = dest;
  barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
  barrier.Transition.StateBefore = ui::d3d12::D3D12Presenter::kGuestOutputInternalState;
  barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
  command_list->ResourceBarrier(1, &barrier);
  ID3D12DescriptorHeap* heap = processor.fg_view_heap_.Get();
  command_list->SetDescriptorHeaps(1, &heap);
  command_list->SetComputeRootSignature(processor.hdr_refresh_fg_root_signature_.Get());
  command_list->SetPipelineState(processor.hdr_refresh_fg_pipeline_.Get());
  const HdrRefreshConstants& constants = processor.fg_compose_constants_;
  command_list->SetComputeRoot32BitConstants(UINT(ApplyGammaRootParameter::kConstants),
                                             sizeof(constants) / sizeof(uint32_t), &constants, 0);
  command_list->SetComputeRootDescriptorTable(UINT(ApplyGammaRootParameter::kDestination),
                                              gpu_at(0));
  command_list->SetComputeRootDescriptorTable(UINT(ApplyGammaRootParameter::kSource), gpu_at(1));
  command_list->SetComputeRootDescriptorTable(UINT(ApplyGammaRootParameter::kRamp), gpu_at(2));
  for (uint32_t i = 0; i < 4; ++i) {
    command_list->SetComputeRootDescriptorTable(UINT(ApplyGammaRootParameter::kCount) + i,
                                                gpu_at(3 + i));
  }
  command_list->SetComputeRootDescriptorTable(UINT(ApplyGammaRootParameter::kCount) + 4,
                                              gpu_at(7));
  command_list->Dispatch((constants.size[0] + 15) / 16, (constants.size[1] + 7) / 8, 1);
  std::swap(barrier.Transition.StateBefore, barrier.Transition.StateAfter);
  command_list->ResourceBarrier(1, &barrier);
  return true;
}

}  // namespace rex::graphics::d3d12
