/**
 * @file        graphics/shader_storage_progress.h
 * @brief       Progress of the start-up creation of stored pipelines, on standard output
 *
 * With shader_storage_progress set to N > 0, the pipeline caches print, while they create the
 * stored pipelines at start:
 *   SHADERPREP preload <done> <total>                 at the start and every N pipelines
 *   SHADERPREP preload-done <created> <total> <ms>    at the end
 * for a front end that prepares the storage and shows how far it got (mcla's
 * --mcla_prepare_shaders, which sets it). Off (0) by default.
 */

#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <string>
#include <string_view>

#include <rex/cvar.h>

REXCVAR_DECLARE(int32_t, shader_storage_progress);

namespace rex::graphics {

class ShaderStorageProgress {
 public:
  // print: false for a preload nobody waits for, which reports nothing.
  explicit ShaderStorageProgress(size_t total, bool print = true)
      : total_(total),
        interval_(print && REXCVAR_GET(shader_storage_progress) > 0
                      ? size_t(REXCVAR_GET(shader_storage_progress))
                      : 0),
        start_(std::chrono::steady_clock::now()) {
    if (interval_) {
      std::lock_guard<std::mutex> lock(print_lock_);
      std::fprintf(stdout, "SHADERPREP preload 0 %zu\n", total_);
      std::fflush(stdout);
    }
  }

  // One stored pipeline dealt with: created, failed or skipped.
  void Done(bool created) {
    if (created) {
      created_.fetch_add(1, std::memory_order_relaxed);
    }
    const size_t done = done_.fetch_add(1, std::memory_order_relaxed) + 1;
    if (interval_ && done % interval_ == 0 && done < total_) {
      std::lock_guard<std::mutex> lock(print_lock_);
      std::fprintf(stdout, "SHADERPREP preload %zu %zu\n", done, total_);
      std::fflush(stdout);
    }
  }

  void Finish() {
    if (interval_) {
      const long long ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                               std::chrono::steady_clock::now() - start_)
                               .count();
      std::lock_guard<std::mutex> lock(print_lock_);
      std::fprintf(stdout, "SHADERPREP preload-done %zu %zu %lld\n", created_.load(), total_, ms);
      std::fflush(stdout);
    }
  }

 private:
  const size_t total_;
  const size_t interval_;
  const std::chrono::steady_clock::time_point start_;
  std::atomic<size_t> done_{0};
  std::atomic<size_t> created_{0};
  std::mutex print_lock_;
};

// A JSON string literal of text (ShaderStorageReport).
inline std::string ShaderStorageJsonString(std::string_view text) {
  std::string out = "\"";
  for (char c : text) {
    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if (static_cast<unsigned char>(c) < 0x20) {
      char escaped[8];
      std::snprintf(escaped, sizeof(escaped), "\\u%04x", unsigned(static_cast<unsigned char>(c)));
      out += escaped;
    } else {
      out += c;
    }
  }
  out += '"';
  return out;
}

}  // namespace rex::graphics
