/**
 * Frame generation (rexglue-frame-generation.patch): AMD FSR 3.1's frame
 * generation from the same FidelityFX runtime as the temporal anti-aliasing
 * (temporal_aa_fsr.h, cmake/rexglue_fsr.cmake).
 */

#pragma once

#if defined(REX_HAS_FSR) && REX_HAS_FSR

#include <ffx_api/ffx_api.h>
#include <ffx_api/ffx_framegeneration.h>

namespace rex::graphics {

// What both backends create frame generation with. The prebuilt Vulkan shaders
// are made for these (launcher/dev/fsr/fsr_vk_shaders.py reads them here). The
// vectors are the temporal anti-aliasing pass's: at render size, with the
// jitter already taken out, so neither DISPLAY_RESOLUTION_MOTION_VECTORS nor
// MOTION_VECTORS_JITTER_CANCELLATION (which, at this FidelityFX commit, only
// selects other shader permutations); depth is reversed (1 = near).
constexpr uint32_t kFgCreateFlags = FFX_FRAMEGENERATION_ENABLE_DEPTH_INVERTED;

}  // namespace rex::graphics

#endif  // REX_HAS_FSR
