/**
 * Temporal anti-aliasing (rexglue-temporal-aa.patch), Vulkan: see
 * CommandProcessor::TaaFrame and VulkanCommandProcessor::TaaRun.
 */

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <string>
#include <thread>
#include <vector>

#include <rex/filesystem.h>
#include <rex/graphics/flags.h>
#include <rex/graphics/vulkan/command_processor.h>
#include <rex/logging.h>
#include <rex/platform/dynlib.h>
#include <rex/ui/vulkan/util.h>

#include "../frame_generation_fsr.h"
#include "../temporal_aa_fsr.h"

#if defined(REX_HAS_FSR) && REX_HAS_FSR
#include <ffx_api/vk/ffx_api_vk.h>
#if defined(REX_FSR_PREBUILT_SHADERS_VK) && REX_FSR_PREBUILT_SHADERS_VK
// The prebuilt shaders' create flags (thirdparty/fidelityfx-shaders-vk).
#include <rexglue_fsr_shaders_vk.h>
static_assert((rex::graphics::kTaaFsrCreateFlags & (REXGLUE_FSR_SHADERS_VK_FLAG_MASK)) ==
                  (REXGLUE_FSR_SHADERS_VK_FLAGS),
              "FSR's create flags differ from the prebuilt shaders' (thirdparty/fidelityfx-shaders-vk): "
              "make them again with launcher/dev/fsr/fsr_vk_shaders.py");
static_assert((rex::graphics::kFgCreateFlags & (REXGLUE_FSR_SHADERS_VK_FG_FLAG_MASK)) ==
                  (REXGLUE_FSR_SHADERS_VK_FG_FLAGS),
              "Frame generation's create flags differ from the prebuilt shaders' "
              "(thirdparty/fidelityfx-shaders-vk): make them again with launcher/dev/fsr/fsr_vk_shaders.py");
#endif
#endif

namespace rex::graphics::vulkan {

#if defined(REX_HAS_FSR) && REX_HAS_FSR && defined(REX_FSR_STATIC) && REX_FSR_STATIC
// temporal_aa_static.cpp: the Vulkan functions FidelityFX calls directly.
void TaaSetStaticVulkanFunctions(const ui::vulkan::VulkanInstance::Functions* ifn,
                                 const ui::vulkan::VulkanDevice::Functions* dfn);
#endif

namespace shaders {
#include "../shaders/vulkan_spirv/taa_debug_view_cs.h"
#include "../shaders/vulkan_spirv/taa_luma_snapshot_cs.h"
#include "../shaders/vulkan_spirv/taa_motion_vectors_mcla_cs.h"
#include "../shaders/vulkan_spirv/taa_reactive_mcla_cs.h"
#include "../shaders/vulkan_spirv/taa_upscale_gather_mcla_cs.h"
}  // namespace shaders

struct VulkanCommandProcessor::TaaFsr {
  // kVectorsOnly: the motion vectors' image alone, without FSR's context
  // (frame generation without FSR anti-aliasing).
  enum State : uint32_t { kNone, kCreating, kReady, kFailed, kVectorsOnly };
  std::atomic<uint32_t> state{kNone};
  std::thread thread;
  // The size of the context and the images (the scene's, host pixels): the output's, and
  // the size FSR renders at (smaller with upscaling; the vectors are of that size).
  uint32_t width = 0;
  uint32_t height = 0;
  uint32_t render_width = 0;
  uint32_t render_height = 0;
  HdrImage vectors;  // R16G16_SFLOAT
  HdrImage output;   // R16G16B16A16_SFLOAT
  // With upscaling, FSR's colour and depth inputs, gathered at the render size.
  HdrImage color_in;  // R16G16B16A16_SFLOAT
  HdrImage depth_in;  // R32_SFLOAT
  // The reactive mask: the luminance snapshots (R16_SFLOAT) and the mask
  // (R8_UNORM), made with the first snapshot.
  HdrImage luma[2];
  HdrImage reactive;
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  FsrRuntime runtime;
  ffxContext context = nullptr;
#endif
  // Set on the submission thread when FSR's dispatch failed.
  std::atomic<bool> dispatch_failed{false};
  // Released contexts, destroyed once the submissions that may use them are
  // done (the images go through the command processor's own queues).
  std::vector<std::pair<uint64_t, void*>> retired;
  // temporal_aa_debug 4: timestamps around the passes, a pair per slot, each
  // slot read once its submission is done.
  static constexpr uint32_t kTimerSlots = 8;
  VkQueryPool timer_pool = VK_NULL_HANDLE;
  PFN_vkCmdWriteTimestamp write_timestamp = nullptr;
  PFN_vkGetQueryPoolResults get_results = nullptr;
  uint64_t timer_submission[kTimerSlots] = {};  // 0: free
  uint32_t timer_next = 0;
  double timer_tick_ms = 0.0;
  double timer_ms = 0.0;
  uint32_t timer_count = 0;
};

namespace {

#if defined(REX_HAS_FSR) && REX_HAS_FSR
// FidelityFX's Vulkan backend asks for KHR aliases of functions that a Vulkan
// 1.1+ driver may expose only under their core names.
std::atomic<PFN_vkGetDeviceProcAddr> taa_get_device_proc_addr{nullptr};
VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL TaaGetDeviceProcAddr(VkDevice device, const char* name) {
  PFN_vkGetDeviceProcAddr get = taa_get_device_proc_addr.load(std::memory_order_relaxed);
  if (!get || !name) {
    return nullptr;
  }
  if (PFN_vkVoidFunction function = get(device, name)) {
    return function;
  }
  static const char* const kAliases[][2] = {
      {"vkGetBufferMemoryRequirements2KHR", "vkGetBufferMemoryRequirements2"},
      {"vkGetImageMemoryRequirements2KHR", "vkGetImageMemoryRequirements2"},
      {"vkBindBufferMemory2KHR", "vkBindBufferMemory2"},
      {"vkBindImageMemory2KHR", "vkBindImageMemory2"},
      {"vkCmdPipelineBarrier2KHR", "vkCmdPipelineBarrier2"},
      {"vkGetDeviceBufferMemoryRequirementsKHR", "vkGetDeviceBufferMemoryRequirements"},
      {"vkGetDeviceImageMemoryRequirementsKHR", "vkGetDeviceImageMemoryRequirements"},
  };
  for (const auto& alias : kAliases) {
    if (!std::strcmp(name, alias[0])) {
      return get(device, alias[1]);
    }
  }
  return nullptr;
}

}  // namespace

PFN_vkGetDeviceProcAddr TaaFfxDeviceProcAddr(const ui::vulkan::VulkanDevice* vulkan_device) {
  taa_get_device_proc_addr.store(
      reinterpret_cast<PFN_vkGetDeviceProcAddr>(
          vulkan_device->vulkan_instance()->functions().vkGetInstanceProcAddr(
              vulkan_device->vulkan_instance()->instance(), "vkGetDeviceProcAddr")),
      std::memory_order_relaxed);
  return TaaGetDeviceProcAddr;
}

namespace {

struct TaaFsrDispatch {
  PfnFfxDispatch dispatch;
  // The context's handle as it was when recorded (a later one may replace it
  // before this is executed).
  ffxContext context;
  std::atomic<bool>* failed;
  // For the fallback copy of the scene into the output.
  PFN_vkCmdPipelineBarrier pipeline_barrier;
  PFN_vkCmdCopyImage copy_image;
  ffxDispatchDescUpscale desc;
};

void TaaFsrDispatchCallback(VkCommandBuffer command_buffer, const void* data) {
  TaaFsrDispatch dispatch;
  std::memcpy(&dispatch, data, sizeof(dispatch));
  dispatch.desc.commandList = command_buffer;
  ffxContext context = dispatch.context;
  ffxReturnCode_t result = dispatch.dispatch(&context, &dispatch.desc.header);
  if (result == FFX_API_RETURN_OK) {
    return;
  }
  // The scene as it was into the output, which is copied back into it next:
  // the frame is left as it was (FSR is given up at the end of the frame).
  dispatch.failed->store(true, std::memory_order_release);
  auto color = static_cast<VkImage>(dispatch.desc.color.resource);
  auto output = static_cast<VkImage>(dispatch.desc.output.resource);
  VkImageMemoryBarrier barriers[2] = {};
  for (uint32_t i = 0; i < 2; ++i) {
    barriers[i].sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    barriers[i].srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    barriers[i].dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    barriers[i].subresourceRange = ui::vulkan::util::InitializeSubresourceRange();
  }
  barriers[0].image = color;
  barriers[0].srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
  barriers[0].dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
  barriers[0].oldLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
  barriers[0].newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
  barriers[1].image = output;
  barriers[1].srcAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
  barriers[1].dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
  barriers[1].oldLayout = VK_IMAGE_LAYOUT_GENERAL;
  barriers[1].newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
  dispatch.pipeline_barrier(command_buffer, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
                            VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 2, barriers);
  VkImageCopy region = {};
  region.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
  region.dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
  region.extent = {dispatch.desc.renderSize.width, dispatch.desc.renderSize.height, 1};
  dispatch.copy_image(command_buffer, color, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, output,
                      VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &region);
  for (VkImageMemoryBarrier& barrier : barriers) {
    std::swap(barrier.srcAccessMask, barrier.dstAccessMask);
    std::swap(barrier.oldLayout, barrier.newLayout);
  }
  dispatch.pipeline_barrier(command_buffer, VK_PIPELINE_STAGE_TRANSFER_BIT,
                            VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, 0, 0, nullptr, 0, nullptr, 2,
                            barriers);
  static std::atomic<bool> failure_logged{false};
  if (!failure_logged.exchange(true)) {
    REXGPU_ERROR("Temporal AA: FSR's dispatch failed ({}); giving FSR up", result);
  }
}

FfxApiResource TaaFsrResource(VkImage image, VkFormat format, uint32_t width, uint32_t height,
                              VkImageUsageFlags usage, uint32_t state) {
  // As far as FidelityFX looks at it (not mutable: it would take that for
  // sRGB).
  VkImageCreateInfo info = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
  info.imageType = VK_IMAGE_TYPE_2D;
  info.format = format;
  info.extent = {width, height, 1};
  info.mipLevels = 1;
  info.arrayLayers = 1;
  info.samples = VK_SAMPLE_COUNT_1_BIT;
  info.usage = usage;
  return ffxApiGetResourceVK(image, ffxApiGetImageResourceDescriptionVK(image, info, 0), state);
}
#endif

struct TaaTimestamp {
  PFN_vkCmdWriteTimestamp write_timestamp;
  VkQueryPool pool;
  uint32_t query;
  VkPipelineStageFlagBits stage;
};

void TaaTimestampCallback(VkCommandBuffer command_buffer, const void* data) {
  TaaTimestamp timestamp;
  std::memcpy(&timestamp, data, sizeof(timestamp));
  timestamp.write_timestamp(command_buffer, timestamp.stage, timestamp.pool, timestamp.query);
}

}  // namespace

uint32_t VulkanCommandProcessor::TaaTimerBegin() {
  if (TaaDebug() != 4 || !taa_fsr_) {
    return UINT32_MAX;
  }
  TaaFsr& fsr = *taa_fsr_;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  if (fsr.timer_pool == VK_NULL_HANDLE) {
    const ui::vulkan::VulkanInstance* instance = vulkan_device->vulkan_instance();
    auto get_device_proc_addr = reinterpret_cast<PFN_vkGetDeviceProcAddr>(
        instance->functions().vkGetInstanceProcAddr(instance->instance(), "vkGetDeviceProcAddr"));
    VkPhysicalDeviceProperties properties;
    instance->functions().vkGetPhysicalDeviceProperties(vulkan_device->physical_device(),
                                                        &properties);
    if (!get_device_proc_addr || !(properties.limits.timestampPeriod > 0.0f)) {
      return UINT32_MAX;
    }
    fsr.write_timestamp = reinterpret_cast<PFN_vkCmdWriteTimestamp>(
        get_device_proc_addr(vulkan_device->device(), "vkCmdWriteTimestamp"));
    fsr.get_results = reinterpret_cast<PFN_vkGetQueryPoolResults>(
        get_device_proc_addr(vulkan_device->device(), "vkGetQueryPoolResults"));
    VkQueryPoolCreateInfo pool_info = {VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
    pool_info.queryType = VK_QUERY_TYPE_TIMESTAMP;
    pool_info.queryCount = 2 * TaaFsr::kTimerSlots;
    if (!fsr.write_timestamp || !fsr.get_results ||
        vulkan_device->functions().vkCreateQueryPool(vulkan_device->device(), &pool_info, nullptr,
                                                     &fsr.timer_pool) != VK_SUCCESS) {
      fsr.timer_pool = VK_NULL_HANDLE;
      return UINT32_MAX;
    }
    fsr.timer_tick_ms = double(properties.limits.timestampPeriod) * 1e-6;
  }
  TaaTimerCollect();
  uint32_t slot = fsr.timer_next;
  if (fsr.timer_submission[slot]) {
    return UINT32_MAX;
  }
  fsr.timer_next = (slot + 1) % TaaFsr::kTimerSlots;
  deferred_command_buffer_.CmdVkResetQueryPool(fsr.timer_pool, slot * 2, 2);
  TaaTimestamp timestamp = {fsr.write_timestamp, fsr.timer_pool, slot * 2,
                            VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT};
  deferred_command_buffer_.CmdExternalCallback(TaaTimestampCallback, &timestamp,
                                               sizeof(timestamp));
  return slot;
}

void VulkanCommandProcessor::TaaTimerEnd(uint32_t slot) {
  if (slot == UINT32_MAX) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  TaaTimestamp timestamp = {fsr.write_timestamp, fsr.timer_pool, slot * 2 + 1,
                            VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT};
  deferred_command_buffer_.CmdExternalCallback(TaaTimestampCallback, &timestamp,
                                               sizeof(timestamp));
  fsr.timer_submission[slot] = GetCurrentSubmission();
}

void VulkanCommandProcessor::TaaTimerCollect() {
  if (!taa_fsr_ || taa_fsr_->timer_pool == VK_NULL_HANDLE) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  for (uint32_t slot = 0; slot < TaaFsr::kTimerSlots; ++slot) {
    if (!fsr.timer_submission[slot] || fsr.timer_submission[slot] > GetCompletedSubmission()) {
      continue;
    }
    fsr.timer_submission[slot] = 0;
    uint64_t ticks[2];
    if (fsr.get_results(vulkan_device->device(), fsr.timer_pool, slot * 2, 2, sizeof(ticks),
                        ticks, sizeof(uint64_t), VK_QUERY_RESULT_64_BIT) == VK_SUCCESS &&
        ticks[1] > ticks[0]) {
      fsr.timer_ms += double(ticks[1] - ticks[0]) * fsr.timer_tick_ms;
      ++fsr.timer_count;
    }
  }
}

void VulkanCommandProcessor::TaaTakeGpuTime(double& ms_out, uint32_t& count_out) {
  ms_out = 0.0;
  count_out = 0;
  if (!taa_fsr_) {
    return;
  }
  TaaTimerCollect();
  ms_out = taa_fsr_->timer_ms;
  count_out = taa_fsr_->timer_count;
  taa_fsr_->timer_ms = 0.0;
  taa_fsr_->timer_count = 0;
}

void VulkanCommandProcessor::TaaFsrDeleter::operator()(TaaFsr* fsr) const {
  if (fsr->thread.joinable()) {
    fsr->thread.join();
  }
  delete fsr;
}

bool VulkanCommandProcessor::TaaReady() const {
  // Made for the size it is asked for now (the render size changes with the ratio).
  return taa_fsr_ && taa_fsr_->state.load(std::memory_order_acquire) == TaaFsr::kReady &&
         taa_fsr_->width == taa_up_.out_width && taa_fsr_->height == taa_up_.out_height &&
         taa_fsr_->render_width == taa_up_.render_width &&
         taa_fsr_->render_height == taa_up_.render_height;
}

bool VulkanCommandProcessor::TaaUpscaleSupported() const {
  // The scene is squeezed into host render targets and read back by resolves that stretch.
  return render_target_cache_ && render_target_cache_->DirectResolveStretchPossible() &&
         REXCVAR_GET(direct_host_resolve);
}

VkImage VulkanCommandProcessor::TaaFrameVectors() const {
  // Frame generation (rexglue-frame-generation.patch).
  return taa_fsr_ && taa_frame_.done ? taa_fsr_->vectors.image : VK_NULL_HANDLE;
}

bool VulkanCommandProcessor::TaaDeviceSupported() {
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  // FidelityFX picks its shaders from the physical device's features and
  // extensions; the device enables the 16-bit and subgroup size features only
  // as Vulkan 1.2 and 1.3 features (vulkan_device.cpp), not the extensions
  // older devices have them as.
  if (vulkan_device->properties().apiVersion < VK_MAKE_API_VERSION(0, 1, 3, 0)) {
    TaaSetUnavailable("FSR needs a Vulkan 1.3 device");
    return false;
  }
  // The storage formats the passes write (FSR needs them too).
  const ui::vulkan::VulkanInstance* instance = vulkan_device->vulkan_instance();
  for (VkFormat format : {VK_FORMAT_R16G16_SFLOAT, VK_FORMAT_R16_SFLOAT, VK_FORMAT_R8_UNORM,
                          VK_FORMAT_R16G16B16A16_SFLOAT}) {
    VkFormatProperties properties;
    instance->functions().vkGetPhysicalDeviceFormatProperties(vulkan_device->physical_device(),
                                                              format, &properties);
    if (!(properties.optimalTilingFeatures & VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT)) {
      TaaSetUnavailable("the device can't write a format FSR needs in shaders");
      return false;
    }
  }
  return true;
}

// Whether FidelityFX's Vulkan runtime is there (next to the executable, or
// linked in).
static bool TaaRuntimeThere() {
#if !(defined(REX_HAS_FSR) && REX_HAS_FSR)
  return false;
#elif defined(REX_FSR_STATIC) && REX_FSR_STATIC
  return FsrRuntime::Linked();
#else
#if REX_PLATFORM_WIN32
  const char* name = "amd_fidelityfx_vk.dll";
#else
  const char* name = "libamd_fidelityfx_vk.so";
#endif
  // Loaded (and kept), not only looked for: a library whose imports fail (the Visual C++
  // runtime missing) is there and unusable.
  std::string error;
  switch (rex::platform::CheckLoadable(rex::filesystem::GetExecutableFolder() / name, &error)) {
    case rex::platform::LibraryCheck::kLoads:
      return true;
    case rex::platform::LibraryCheck::kFailed:
      REXGPU_WARN("Temporal AA: {} is there but doesn't load ({})", name, error);
      return false;
    default:
      return false;
  }
#endif
}

bool VulkanCommandProcessor::TaaCheckAvailable() {
  // Not on a device made without its features (temporal_aa_device_features).
  return GetVulkanDevice()->temporal_aa_features() && TaaRuntimeThere() && TaaDeviceSupported();
}

bool VulkanCommandProcessor::TaaAvailableAtNextStart() {
  return !GetVulkanDevice()->temporal_aa_features() && TaaRuntimeThere() && TaaDeviceSupported();
}

void VulkanCommandProcessor::TaaCollectRetired(bool all) {
  if (!taa_fsr_) {
    return;
  }
  TaaFsr& fsr = *taa_fsr_;
  for (auto it = fsr.retired.begin(); it != fsr.retired.end();) {
    if (!all && it->first > GetCompletedSubmission()) {
      ++it;
      continue;
    }
#if defined(REX_HAS_FSR) && REX_HAS_FSR
    ffxContext context = it->second;
    fsr.runtime.destroy(&context, nullptr);
#endif
    it = fsr.retired.erase(it);
  }
}

void VulkanCommandProcessor::TaaFrameEnd() {
  TaaCollectRetired(false);
  FgCollectRetired(false);
}

void VulkanCommandProcessor::TaaRelease() {
  if (!taa_fsr_) {
    return;
  }
  if (taa_fsr_->thread.joinable()) {
    taa_fsr_->thread.join();
  }
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  if (taa_fsr_->context) {
    // The GPU and the submission thread may still use it: destroyed once the
    // submissions so far are done.
    taa_fsr_->retired.emplace_back(GetCurrentSubmission(), taa_fsr_->context);
    taa_fsr_->context = nullptr;
    REXGPU_INFO("Temporal AA: FSR released");
  }
#endif
  taa_fsr_->dispatch_failed.store(false, std::memory_order_relaxed);
  for (HdrImage* image : {&taa_fsr_->vectors, &taa_fsr_->output, &taa_fsr_->luma[0],
                          &taa_fsr_->luma[1], &taa_fsr_->reactive, &taa_fsr_->color_in,
                          &taa_fsr_->depth_in}) {
    if (image->image != VK_NULL_HANDLE) {
      // Destroyed once the submissions that may use it are done.
      destroy_image_views_.emplace_back(GetCurrentSubmission(), image->view);
      destroy_images_.emplace_back(GetCurrentSubmission(), image->image);
      destroy_memory_.emplace_back(GetCurrentSubmission(), image->memory);
      *image = HdrImage();
    }
  }
  taa_fsr_->width = 0;
  taa_fsr_->height = 0;
  taa_fsr_->render_width = 0;
  taa_fsr_->render_height = 0;
  taa_fsr_->state.store(TaaFsr::kNone, std::memory_order_release);
}

bool VulkanCommandProcessor::TaaCreatePipeline() {
  if (taa_vectors_pipeline_ != VK_NULL_HANDLE) {
    return true;
  }
  if (taa_pipeline_failed_) {
    return false;
  }
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  taa_pipeline_failed_ = true;
  if (!TaaDeviceSupported()) {
    return false;
  }
  // Set layouts: the vectors' (a uniform buffer, two sampled images, a storage
  // image) and the reactive mask's (three sampled images, a storage image).
  for (uint32_t set = 0; set < 2; ++set) {
    VkDescriptorSetLayoutBinding bindings[4] = {};
    for (uint32_t i = 0; i < 4; ++i) {
      bindings[i].binding = i;
      bindings[i].descriptorType = i == 3                   ? VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
                                   : (!set && !i)           ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                                                            : VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
      bindings[i].descriptorCount = 1;
      bindings[i].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
    }
    VkDescriptorSetLayoutCreateInfo layout_info = {
        VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    layout_info.bindingCount = 4;
    layout_info.pBindings = bindings;
    if (dfn.vkCreateDescriptorSetLayout(device, &layout_info, nullptr,
                                        set ? &taa_reactive_set_layout_
                                            : &taa_descriptor_set_layout_) != VK_SUCCESS) {
      REXGPU_ERROR("Temporal AA: failed to create the descriptor set layouts");
      return false;
    }
  }
  // The gather pass's layout: a uniform buffer, three sampled images, three storage images.
  {
    VkDescriptorSetLayoutBinding gather_bindings[7] = {};
    for (uint32_t i = 0; i < 7; ++i) {
      gather_bindings[i].binding = i;
      gather_bindings[i].descriptorType = !i          ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                                          : i < 4     ? VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE
                                                      : VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
      gather_bindings[i].descriptorCount = 1;
      gather_bindings[i].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
    }
    VkDescriptorSetLayoutCreateInfo gather_layout_info = {
        VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    gather_layout_info.bindingCount = 7;
    gather_layout_info.pBindings = gather_bindings;
    if (dfn.vkCreateDescriptorSetLayout(device, &gather_layout_info, nullptr,
                                        &taa_gather_set_layout_) != VK_SUCCESS) {
      REXGPU_ERROR("FSR upscaling: failed to create the gather descriptor set layout");
      return false;
    }
  }
  VkDescriptorPoolSize pool_sizes[3] = {
      {VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 2 * kMaxFramesInFlight},
      {VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, 11 * kMaxFramesInFlight},
      {VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, 6 * kMaxFramesInFlight},
  };
  VkDescriptorPoolCreateInfo pool_info = {VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
  pool_info.maxSets = 4 * kMaxFramesInFlight;
  pool_info.poolSizeCount = 3;
  pool_info.pPoolSizes = pool_sizes;
  if (dfn.vkCreateDescriptorPool(device, &pool_info, nullptr, &taa_descriptor_pool_) !=
      VK_SUCCESS) {
    REXGPU_ERROR("Temporal AA: failed to create the descriptor pool");
    return false;
  }
  for (uint32_t set = 0; set < 3; ++set) {
    std::array<VkDescriptorSetLayout, kMaxFramesInFlight> layouts;
    layouts.fill(set ? taa_reactive_set_layout_ : taa_descriptor_set_layout_);
    VkDescriptorSetAllocateInfo allocate_info = {
        VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    allocate_info.descriptorPool = taa_descriptor_pool_;
    allocate_info.descriptorSetCount = kMaxFramesInFlight;
    allocate_info.pSetLayouts = layouts.data();
    VkDescriptorSet* sets = set == 2   ? taa_debug_descriptors_.data()
                            : set == 1 ? taa_reactive_descriptors_.data()
                                       : taa_descriptors_.data();
    if (dfn.vkAllocateDescriptorSets(device, &allocate_info, sets) != VK_SUCCESS) {
      REXGPU_ERROR("Temporal AA: failed to allocate the descriptor sets");
      return false;
    }
  }
  {
    std::array<VkDescriptorSetLayout, kMaxFramesInFlight> gather_layouts;
    gather_layouts.fill(taa_gather_set_layout_);
    VkDescriptorSetAllocateInfo gather_allocate_info = {
        VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    gather_allocate_info.descriptorPool = taa_descriptor_pool_;
    gather_allocate_info.descriptorSetCount = kMaxFramesInFlight;
    gather_allocate_info.pSetLayouts = gather_layouts.data();
    if (dfn.vkAllocateDescriptorSets(device, &gather_allocate_info,
                                     taa_gather_descriptors_.data()) != VK_SUCCESS) {
      REXGPU_ERROR("FSR upscaling: failed to allocate the gather descriptor sets");
      return false;
    }
  }
  auto create = [&](uint32_t set_count, const VkDescriptorSetLayout* set_layouts,
                    uint32_t push_constants_size, const uint32_t* shader, size_t shader_size,
                    const char* name, VkPipelineLayout& layout, VkPipeline& pipeline) {
    VkPushConstantRange push_constants = {VK_SHADER_STAGE_COMPUTE_BIT, 0, push_constants_size};
    VkPipelineLayoutCreateInfo layout_info = {VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    layout_info.setLayoutCount = set_count;
    layout_info.pSetLayouts = set_layouts;
    layout_info.pushConstantRangeCount = push_constants_size ? 1 : 0;
    layout_info.pPushConstantRanges = &push_constants;
    if (dfn.vkCreatePipelineLayout(device, &layout_info, nullptr, &layout) != VK_SUCCESS) {
      return false;
    }
    pipeline = ui::vulkan::util::CreateComputePipeline(vulkan_device, layout, shader, shader_size);
    if (pipeline == VK_NULL_HANDLE) {
      return false;
    }
    vulkan_device->SetObjectName(VK_OBJECT_TYPE_PIPELINE, pipeline, name);
    return true;
  };
  VkDescriptorSetLayout luma_sets[2] = {
      render_target_cache_->descriptor_set_layout_sampled_image(),
      GetSingleTransientDescriptorLayout(SingleTransientDescriptorLayout::kStorageImageCompute)};
  if (!create(1, &taa_descriptor_set_layout_, 0, shaders::taa_motion_vectors_mcla_cs,
              sizeof(shaders::taa_motion_vectors_mcla_cs), "Temporal AA motion vectors",
              taa_vectors_pipeline_layout_, taa_vectors_pipeline_) ||
      !create(2, luma_sets, 16, shaders::taa_luma_snapshot_cs,
              sizeof(shaders::taa_luma_snapshot_cs), "Temporal AA luminance snapshot",
              taa_luma_pipeline_layout_, taa_luma_pipeline_) ||
      !create(1, &taa_reactive_set_layout_, 32, shaders::taa_reactive_mcla_cs,
              sizeof(shaders::taa_reactive_mcla_cs), "Temporal AA reactive mask",
              taa_reactive_pipeline_layout_, taa_reactive_pipeline_)) {
    REXGPU_ERROR("Temporal AA: failed to create the pipelines");
    return false;
  }
  taa_debug_pipeline_ = ui::vulkan::util::CreateComputePipeline(
      vulkan_device, taa_reactive_pipeline_layout_, shaders::taa_debug_view_cs,
      sizeof(shaders::taa_debug_view_cs));
  if (taa_debug_pipeline_ == VK_NULL_HANDLE) {
    REXGPU_ERROR("Temporal AA: failed to create the pipelines");
    return false;
  }
  if (!create(1, &taa_gather_set_layout_, 0, shaders::taa_upscale_gather_mcla_cs,
              sizeof(shaders::taa_upscale_gather_mcla_cs), "FSR upscaling gather",
              taa_gather_pipeline_layout_, taa_gather_pipeline_)) {
    REXGPU_ERROR("FSR upscaling: failed to create the gather pipeline");
    return false;
  }
  taa_pipeline_failed_ = false;
  return true;
}

void VulkanCommandProcessor::TaaDestroyPipeline() {
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  for (VkPipeline* pipeline : {&taa_vectors_pipeline_, &taa_luma_pipeline_,
                               &taa_reactive_pipeline_, &taa_debug_pipeline_,
                               &taa_gather_pipeline_}) {
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, *pipeline);
  }
  for (VkPipelineLayout* layout : {&taa_vectors_pipeline_layout_, &taa_luma_pipeline_layout_,
                                   &taa_reactive_pipeline_layout_,
                                   &taa_gather_pipeline_layout_}) {
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipelineLayout, device, *layout);
  }
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyDescriptorPool, device,
                                         taa_descriptor_pool_);
  taa_descriptors_.fill(VK_NULL_HANDLE);
  taa_reactive_descriptors_.fill(VK_NULL_HANDLE);
  taa_debug_descriptors_.fill(VK_NULL_HANDLE);
  taa_gather_descriptors_.fill(VK_NULL_HANDLE);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyDescriptorSetLayout, device,
                                         taa_gather_set_layout_);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyDescriptorSetLayout, device,
                                         taa_descriptor_set_layout_);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyDescriptorSetLayout, device,
                                         taa_reactive_set_layout_);
  if (taa_fsr_) {
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyQueryPool, device, taa_fsr_->timer_pool);
    for (HdrImage* image : {&taa_fsr_->vectors, &taa_fsr_->output, &taa_fsr_->luma[0],
                            &taa_fsr_->luma[1], &taa_fsr_->reactive, &taa_fsr_->color_in,
                            &taa_fsr_->depth_in}) {
      ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImageView, device, image->view);
      ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImage, device, image->image);
      ui::vulkan::util::DestroyAndNullHandle(dfn.vkFreeMemory, device, image->memory);
    }
  }
}

bool VulkanCommandProcessor::TaaEnsureReactiveTextures() {
  TaaFsr& fsr = *taa_fsr_;
  if (fsr.reactive.image != VK_NULL_HANDLE) {
    return true;
  }
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  static const char* const kNames[3] = {"Temporal AA opaque luminance",
                                        "Temporal AA composite luminance",
                                        "Temporal AA reactive mask"};
  for (uint32_t i = 0; i < 3; ++i) {
    HdrImage& image = i < 2 ? fsr.luma[i] : fsr.reactive;
    VkImageCreateInfo image_info = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    image_info.imageType = VK_IMAGE_TYPE_2D;
    image_info.format = i < 2 ? VK_FORMAT_R16_SFLOAT : VK_FORMAT_R8_UNORM;
    image_info.extent = {fsr.width, fsr.height, 1};
    image_info.mipLevels = 1;
    image_info.arrayLayers = 1;
    image_info.samples = VK_SAMPLE_COUNT_1_BIT;
    image_info.tiling = VK_IMAGE_TILING_OPTIMAL;
    image_info.usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT;
    image_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    image_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VkImageViewCreateInfo view_info = {VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    if (ui::vulkan::util::CreateDedicatedAllocationImage(
            vulkan_device, image_info, ui::vulkan::util::MemoryPurpose::kDeviceLocal, image.image,
            image.memory)) {
      view_info.image = image.image;
      view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
      view_info.format = image_info.format;
      view_info.subresourceRange = ui::vulkan::util::InitializeSubresourceRange();
    }
    if (image.image == VK_NULL_HANDLE ||
        dfn.vkCreateImageView(device, &view_info, nullptr, &image.view) != VK_SUCCESS) {
      REXGPU_ERROR("Temporal AA: failed to create the reactive mask's images");
      for (HdrImage* made : {&fsr.luma[0], &fsr.luma[1], &fsr.reactive}) {
        ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImageView, device, made->view);
        ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImage, device, made->image);
        ui::vulkan::util::DestroyAndNullHandle(dfn.vkFreeMemory, device, made->memory);
        *made = HdrImage();
      }
      return false;
    }
    image.width = fsr.width;
    image.height = fsr.height;
    image.layout = VK_IMAGE_LAYOUT_UNDEFINED;
    vulkan_device->SetObjectName(VK_OBJECT_TYPE_IMAGE, image.image, kNames[i]);
  }
  return true;
}

bool VulkanCommandProcessor::TaaSnapshot(uint32_t slot, uint32_t color_target_key) {
  if (!TaaReady() || slot > 1 || !TaaCreatePipeline() || !BeginSubmission(true) ||
      !TaaEnsureReactiveTextures()) {
    return false;
  }
  TaaFsr& fsr = *taa_fsr_;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  VkDescriptorSet dest_set =
      AllocateSingleTransientDescriptor(SingleTransientDescriptorLayout::kStorageImageCompute);
  if (dest_set == VK_NULL_HANDLE) {
    return false;
  }
  EndRenderPass();
  uint32_t width, height;
  VkDescriptorSet source_set =
      render_target_cache_->TaaBeginReadColorTarget(color_target_key, width, height);
  if (source_set == VK_NULL_HANDLE) {
    return false;
  }
  if (width < fsr.width || height < fsr.height) {
    return false;
  }
  VkDescriptorImageInfo dest_info = {VK_NULL_HANDLE, fsr.luma[slot].view, VK_IMAGE_LAYOUT_GENERAL};
  VkWriteDescriptorSet write = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
  write.dstSet = dest_set;
  write.descriptorCount = 1;
  write.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
  write.pImageInfo = &dest_info;
  dfn.vkUpdateDescriptorSets(vulkan_device->device(), 1, &write, 0, nullptr);
  HdrTransitionImage(fsr.luma[slot], VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  BindExternalComputePipeline(taa_luma_pipeline_);
  VkDescriptorSet sets[2] = {source_set, dest_set};
  deferred_command_buffer_.CmdVkBindDescriptorSets(
      VK_PIPELINE_BIND_POINT_COMPUTE, taa_luma_pipeline_layout_, 0, 2, sets, 0, nullptr);
  uint32_t constants[4] = {fsr.width, fsr.height, 0, 0};
  deferred_command_buffer_.CmdVkPushConstants(taa_luma_pipeline_layout_,
                                              VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(constants),
                                              constants);
  deferred_command_buffer_.CmdVkDispatch((fsr.width + 15) / 16, (fsr.height + 7) / 8, 1);
  HdrTransitionImage(fsr.luma[slot], VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  return true;
}

void VulkanCommandProcessor::TaaRunDebugView(VkImageView scene_view, uint32_t mode) {
  TaaFsr& fsr = *taa_fsr_;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  VkDescriptorSet set = taa_debug_descriptors_[frame_current_ % kMaxFramesInFlight];
  // Without a reactive mask this frame: the vectors in its place (mode 1
  // doesn't read it).
  bool reactive = taa_frame_.snapshots == 3 && fsr.reactive.image != VK_NULL_HANDLE;
  VkDescriptorImageInfo images[4] = {
      {VK_NULL_HANDLE, scene_view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
      {VK_NULL_HANDLE, fsr.vectors.view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
      {VK_NULL_HANDLE, reactive ? fsr.reactive.view : fsr.vectors.view,
       VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
      {VK_NULL_HANDLE, fsr.output.view, VK_IMAGE_LAYOUT_GENERAL},
  };
  VkWriteDescriptorSet writes[2] = {};
  for (uint32_t i = 0; i < 2; ++i) {
    writes[i].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    writes[i].dstSet = set;
    writes[i].dstBinding = i ? 3 : 0;
    writes[i].descriptorCount = i ? 1 : 3;
    writes[i].descriptorType =
        i ? VK_DESCRIPTOR_TYPE_STORAGE_IMAGE : VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
    writes[i].pImageInfo = i ? &images[3] : images;
  }
  dfn.vkUpdateDescriptorSets(vulkan_device->device(), 2, writes, 0, nullptr);
  SubmitBarriers(true);
  BindExternalComputePipeline(taa_debug_pipeline_);
  deferred_command_buffer_.CmdVkBindDescriptorSets(
      VK_PIPELINE_BIND_POINT_COMPUTE, taa_reactive_pipeline_layout_, 0, 1, &set, 0, nullptr);
  uint32_t constants[4] = {fsr.width, fsr.height, reactive || mode ? mode : 1, 0};
  deferred_command_buffer_.CmdVkPushConstants(taa_reactive_pipeline_layout_,
                                              VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(constants),
                                              constants);
  deferred_command_buffer_.CmdVkDispatch((fsr.width + 15) / 16, (fsr.height + 7) / 8, 1);
  VkMemoryBarrier barrier = {VK_STRUCTURE_TYPE_MEMORY_BARRIER, nullptr, VK_ACCESS_SHADER_WRITE_BIT,
                             VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT};
  deferred_command_buffer_.CmdVkPipelineBarrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1,
                                                &barrier, 0, nullptr, 0, nullptr);
}

void VulkanCommandProcessor::TaaRunReactive(VkImageView stencil_view) {
  TaaFsr& fsr = *taa_fsr_;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  VkDescriptorSet set = taa_reactive_descriptors_[frame_current_ % kMaxFramesInFlight];
  VkDescriptorImageInfo images[4] = {
      {VK_NULL_HANDLE, fsr.luma[0].view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
      {VK_NULL_HANDLE, fsr.luma[1].view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
      {VK_NULL_HANDLE, stencil_view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
      {VK_NULL_HANDLE, fsr.reactive.view, VK_IMAGE_LAYOUT_GENERAL},
  };
  VkWriteDescriptorSet writes[2] = {};
  for (uint32_t i = 0; i < 2; ++i) {
    writes[i].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    writes[i].dstSet = set;
    writes[i].dstBinding = i ? 3 : 0;
    writes[i].descriptorCount = i ? 1 : 3;
    writes[i].descriptorType =
        i ? VK_DESCRIPTOR_TYPE_STORAGE_IMAGE : VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
    writes[i].pImageInfo = i ? &images[3] : images;
  }
  dfn.vkUpdateDescriptorSets(vulkan_device->device(), 2, writes, 0, nullptr);
  HdrTransitionImage(fsr.reactive, VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  BindExternalComputePipeline(taa_reactive_pipeline_);
  deferred_command_buffer_.CmdVkBindDescriptorSets(
      VK_PIPELINE_BIND_POINT_COMPUTE, taa_reactive_pipeline_layout_, 0, 1, &set, 0, nullptr);
  uint32_t constants[8] = {fsr.width, fsr.height, uint32_t(taa_vector_constants_.jitter[2]), 0};
  TaaReactiveCurve(reinterpret_cast<float*>(&constants[4]));
  deferred_command_buffer_.CmdVkPushConstants(taa_reactive_pipeline_layout_,
                                              VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(constants),
                                              constants);
  deferred_command_buffer_.CmdVkDispatch((fsr.width + 15) / 16, (fsr.height + 7) / 8, 1);
  HdrTransitionImage(fsr.reactive, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
}

void VulkanCommandProcessor::TaaRun(const VulkanShader& pixel_shader) {
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  VkFormat scene_format, depth_format;
  uint32_t width, height, depth_width, depth_height;
  VkImage scene = texture_cache_->GetActiveTextureImage(kTaaFetchScene, scene_format, width, height);
  VkImage depth =
      texture_cache_->GetActiveTextureImage(kTaaFetchDepth, depth_format, depth_width, depth_height);
  VkFormat stencil_format;
  uint32_t stencil_width, stencil_height;
  VkImage stencil = texture_cache_->GetActiveTextureImage(kTaaFetchStencil, stencil_format,
                                                          stencil_width, stencil_height);
  taa_frame_.status = 't';
  if (scene == VK_NULL_HANDLE || depth == VK_NULL_HANDLE ||
      scene_format != VK_FORMAT_R16G16B16A16_SFLOAT || depth_format != VK_FORMAT_R32_SFLOAT ||
      depth_width != width || depth_height != height || stencil == VK_NULL_HANDLE ||
      stencil_width != width || stencil_height != height || !TaaCreatePipeline()) {
    return;
  }
  // The scene's view for the debug views: whichever of the unsigned and the
  // signed view its fetch constant's signs made.
  VkImageView scene_view = VK_NULL_HANDLE;
  for (const VulkanShader::TextureBinding& binding :
       pixel_shader.GetTextureBindingsAfterTranslation()) {
    if (binding.fetch_constant == kTaaFetchScene) {
      for (bool is_signed : {false, true}) {
        if (scene_view == VK_NULL_HANDLE) {
          scene_view = texture_cache_->GetActiveBindingOrNullImageView(
              binding.fetch_constant, binding.dimension, is_signed);
        }
      }
      break;
    }
  }
  VkDescriptorImageInfo textures[2];  // depth (binding 1), stencil (binding 2)
  for (uint32_t i = 0; i < 2; ++i) {
    textures[i] = {VK_NULL_HANDLE, VK_NULL_HANDLE, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
    uint32_t fetch_constant = i ? kTaaFetchStencil : kTaaFetchDepth;
    for (const VulkanShader::TextureBinding& binding :
         pixel_shader.GetTextureBindingsAfterTranslation()) {
      if (binding.fetch_constant == fetch_constant) {
        textures[i].imageView = texture_cache_->GetActiveBindingOrNullImageView(
            binding.fetch_constant, binding.dimension, bool(binding.is_signed));
        break;
      }
    }
    if (textures[i].imageView == VK_NULL_HANDLE) {
      taa_frame_.status = 'n';
      return;
    }
  }

  // The size FSR renders at (with upscaling, smaller than the output) and whether the scene
  // was squeezed to it in this frame.
  uint32_t render_width = width, render_height = height;
  if (taa_frame_.mode != TaaMode::kVectors && taa_up_.render_width && taa_up_.render_height &&
      taa_up_.render_width <= width && taa_up_.render_height <= height) {
    render_width = taa_up_.render_width;
    render_height = taa_up_.render_height;
  }
  const bool upscale_context = render_width != width || render_height != height;
  const bool squeezed = upscale_context && taa_frame_.up_state == 1;

  // The upscaler, made for this size on another thread (the first one takes
  // half a second or so); the frames until it's ready are left as they are.
  if (!taa_fsr_) {
    taa_fsr_.reset(new TaaFsr());
  }
  TaaFsr& fsr = *taa_fsr_;
  uint32_t state = fsr.state.load(std::memory_order_acquire);
  const bool vectors_only = taa_frame_.mode == TaaMode::kVectors;
  if (!vectors_only && state == TaaFsr::kVectorsOnly) {
    // FSR wanted now: made with its context from the end of this frame.
    taa_release_pending_ = true;
    return;
  }
  if (state != TaaFsr::kNone && (fsr.width != width || fsr.height != height ||
                                 fsr.render_width != render_width ||
                                 fsr.render_height != render_height)) {
    // Made again for the new size, from the end of this frame (never released
    // in the middle of one).
    taa_release_pending_ = true;
    return;
  }
  if (fsr.dispatch_failed.load(std::memory_order_acquire)) {
    TaaSetUnavailable("its dispatch failed");
    fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
    taa_release_pending_ = true;
    return;
  }
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  if (state == TaaFsr::kNone && vectors_only) {
    // Frame generation without FSR: the motion vectors' image alone.
    fsr.width = width;
    fsr.height = height;
    fsr.render_width = width;
    fsr.render_height = height;
    if (!FgEnsureImage(fsr.vectors, width, height, VK_FORMAT_R16G16_SFLOAT)) {
      REXGPU_ERROR("Temporal AA: failed to create the motion vector image");
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    vulkan_device->SetObjectName(VK_OBJECT_TYPE_IMAGE, fsr.vectors.image,
                                 "Temporal AA motion vectors");
    fsr.state.store(TaaFsr::kVectorsOnly, std::memory_order_release);
    state = TaaFsr::kVectorsOnly;
  }
  if (state == TaaFsr::kNone) {
    // A failure stays one for this size.
    fsr.width = width;
    fsr.height = height;
    fsr.render_width = render_width;
    fsr.render_height = render_height;
    if (!vulkan_device->temporal_aa_features()) {
      // Created without the features FidelityFX's shaders use
      // (temporal_aa_device_features): not until the next start.
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    if (!fsr.runtime.Load("vk")) {
      TaaSetUnavailable("the Vulkan FidelityFX runtime couldn't be loaded");
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
    for (uint32_t i = 0; i < 2; ++i) {
      HdrImage& image = i ? fsr.output : fsr.vectors;
      VkImageCreateInfo image_info = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
      image_info.imageType = VK_IMAGE_TYPE_2D;
      image_info.format = i ? VK_FORMAT_R16G16B16A16_SFLOAT : VK_FORMAT_R16G16_SFLOAT;
      image_info.extent = i ? VkExtent3D{width, height, 1} : VkExtent3D{render_width, render_height, 1};
      image_info.mipLevels = 1;
      image_info.arrayLayers = 1;
      image_info.samples = VK_SAMPLE_COUNT_1_BIT;
      image_info.tiling = VK_IMAGE_TILING_OPTIMAL;
      image_info.usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT |
                         (i ? VK_IMAGE_USAGE_TRANSFER_SRC_BIT : 0);
      image_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
      image_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
      if (!ui::vulkan::util::CreateDedicatedAllocationImage(
              vulkan_device, image_info, ui::vulkan::util::MemoryPurpose::kDeviceLocal,
              image.image, image.memory)) {
        REXGPU_ERROR("Temporal AA: failed to create an image");
        TaaRelease();
        fsr.width = width;
        fsr.height = height;
        fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
        return;
      }
      VkImageViewCreateInfo view_info = {VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
      view_info.image = image.image;
      view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
      view_info.format = image_info.format;
      view_info.subresourceRange = ui::vulkan::util::InitializeSubresourceRange();
      if (dfn.vkCreateImageView(device, &view_info, nullptr, &image.view) != VK_SUCCESS) {
        REXGPU_ERROR("Temporal AA: failed to create an image view");
        TaaRelease();
        fsr.width = width;
        fsr.height = height;
        fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
        return;
      }
      image.width = i ? width : render_width;
      image.height = i ? height : render_height;
      image.layout = VK_IMAGE_LAYOUT_UNDEFINED;
      vulkan_device->SetObjectName(VK_OBJECT_TYPE_IMAGE, image.image,
                                   i ? "Temporal AA output" : "Temporal AA motion vectors");
    }
    if (upscale_context) {
      // FSR's colour and depth inputs at the render size.
      if (!FgEnsureImage(fsr.color_in, render_width, render_height,
                         VK_FORMAT_R16G16B16A16_SFLOAT) ||
          !FgEnsureImage(fsr.depth_in, render_width, render_height, VK_FORMAT_R32_SFLOAT)) {
        REXGPU_ERROR("FSR upscaling: failed to create the colour and depth inputs");
        TaaRelease();
        fsr.width = width;
        fsr.height = height;
        fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
        return;
      }
      vulkan_device->SetObjectName(VK_OBJECT_TYPE_IMAGE, fsr.color_in.image,
                                   "FSR upscaling colour input");
      vulkan_device->SetObjectName(VK_OBJECT_TYPE_IMAGE, fsr.depth_in.image,
                                   "FSR upscaling depth input");
    }
    fsr.width = width;
    fsr.height = height;
    fsr.render_width = render_width;
    fsr.render_height = render_height;
    fsr.state.store(TaaFsr::kCreating, std::memory_order_release);
    TaaFfxDeviceProcAddr(vulkan_device);
    uint32_t flags = kTaaFsrCreateFlags;
    if (TaaDebug() == 1) {
      flags |= FFX_UPSCALE_ENABLE_DEBUG_CHECKING;
    }
#if defined(REX_FSR_PREBUILT_SHADERS_VK) && REX_FSR_PREBUILT_SHADERS_VK
    // The runtime's shaders are only the permutations of the flags they were
    // made for (launcher/dev/fsr/fsr_vk_shaders.py); others would ask for ones
    // that aren't there.
    if ((flags & (REXGLUE_FSR_SHADERS_VK_FLAG_MASK)) != (REXGLUE_FSR_SHADERS_VK_FLAGS)) {
      REXGPU_ERROR("Temporal AA: FSR's prebuilt Vulkan shaders were made for other create flags "
                   "({:#x}, these {:#x})",
                   uint32_t(REXGLUE_FSR_SHADERS_VK_FLAGS),
                   flags & uint32_t(REXGLUE_FSR_SHADERS_VK_FLAG_MASK));
      TaaSetUnavailable("its prebuilt shaders don't have the permutations it would use");
      fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
      return;
    }
#endif
#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
    TaaSetStaticVulkanFunctions(&vulkan_device->vulkan_instance()->functions(),
                                &vulkan_device->functions());
#endif
    VkPhysicalDevice physical_device = vulkan_device->physical_device();
    fsr.thread = std::thread([&fsr, device, physical_device, width, height, render_width,
                              render_height, flags]() {
      auto start = std::chrono::steady_clock::now();
      ffxCreateBackendVKDesc backend = {};
      backend.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_BACKEND_VK;
      backend.vkDevice = device;
      backend.vkPhysicalDevice = physical_device;
      backend.vkDeviceProcAddr = TaaGetDeviceProcAddr;
      ffxCreateContextDescUpscale create = {};
      create.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_UPSCALE;
      create.header.pNext = &backend.header;
      create.flags = flags;
      create.maxRenderSize = {render_width, render_height};
      create.maxUpscaleSize = {width, height};
      create.fpMessage = FsrRuntime::Message;
      ffxReturnCode_t result = fsr.runtime.create(&fsr.context, &create.header, nullptr);
      if (result != FFX_API_RETURN_OK) {
        fsr.context = nullptr;
        REXGPU_ERROR("Temporal AA: creating FSR failed ({})", result);
        TaaSetUnavailable("its context couldn't be created");
        fsr.state.store(TaaFsr::kFailed, std::memory_order_release);
        return;
      }
      REXGPU_INFO("Temporal AA: FSR 3.1 ready for {}x{}{} (Vulkan) after {} ms", width, height,
                  render_width != width || render_height != height
                      ? fmt::format(" from {}x{}", render_width, render_height)
                      : std::string(),
                  std::chrono::duration_cast<std::chrono::milliseconds>(
                      std::chrono::steady_clock::now() - start)
                      .count());
      fsr.state.store(TaaFsr::kReady, std::memory_order_release);
    });
    return;
  }
  if (state != TaaFsr::kReady && state != TaaFsr::kVectorsOnly) {
    taa_frame_.status = state == TaaFsr::kCreating ? 'c' : 'x';
    return;
  }
  if (fsr.thread.joinable()) {
    fsr.thread.join();
  }

  // The motion vectors (with upscaling, also FSR's colour and depth inputs, gathered at the
  // render size from the output-size textures of the squeezed scene).
  if (upscale_context && !squeezed) {
    // FSR was made for a smaller render size and this frame wasn't squeezed (4x MSAA, another
    // surface): it doesn't run in it.
    taa_frame_.status = 'u';
    return;
  }
  TaaVectorConstants& constants = taa_vector_constants_;
  xenos::xe_gpu_texture_fetch_t scene_fetch = register_file_->GetTextureFetch(kTaaFetchScene);
  constants.size[0] = float(render_width);
  constants.size[1] = float(render_height);
  constants.size[2] = float(render_width) / float(scene_fetch.size_2d.width + 1);
  constants.size[3] = float(render_height) / float(scene_fetch.size_2d.height + 1);
  // The stencil is the stencil view's first byte (red): where the fetch
  // constant's swizzle puts it.
  uint32_t stencil_swizzle = texture_cache_->GetActiveTextureHostSwizzle(kTaaFetchStencil);
  constants.jitter[2] = 0.0f;
  for (uint32_t i = 0; i < 4; ++i) {
    if (((stencil_swizzle >> (3 * i)) & 7) == xenos::XE_GPU_TEXTURE_SWIZZLE_R) {
      constants.jitter[2] = float(i);
      break;
    }
  }
  static bool swizzle_logged = false;
  if (!swizzle_logged) {
    swizzle_logged = true;
    REXGPU_INFO("Temporal AA: stencil view swizzle {:03X}, the stencil in component {}",
                stencil_swizzle, constants.jitter[2]);
  }
  // The gather pass has the output and render sizes after the vectors' constants.
  struct GatherConstants {
    TaaVectorConstants vectors;
    uint32_t map[4];
  } gather_constants;
  gather_constants.vectors = constants;
  gather_constants.map[0] = width;
  gather_constants.map[1] = height;
  gather_constants.map[2] = render_width;
  gather_constants.map[3] = render_height;
  if (squeezed && scene_view == VK_NULL_HANDLE) {
    taa_frame_.status = 'n';
    return;
  }
  const size_t constants_size = squeezed ? sizeof(gather_constants) : sizeof(constants);
  VkDescriptorBufferInfo constants_info;
  uint8_t* constants_mapping = uniform_buffer_pool_->Request(
      frame_current_, constants_size,
      std::max(size_t(vulkan_device->properties().minUniformBufferOffsetAlignment), size_t(16)),
      constants_info.buffer, constants_info.offset);
  if (!constants_mapping) {
    return;
  }
  constants_info.range = constants_size;
  std::memcpy(constants_mapping,
              squeezed ? static_cast<const void*>(&gather_constants)
                       : static_cast<const void*>(&constants),
              constants_size);
  uint32_t frame_index = uint32_t(frame_current_ % kMaxFramesInFlight);
  uint32_t timer_slot;
  if (!squeezed) {
    VkDescriptorSet set = taa_descriptors_[frame_index];
    VkDescriptorImageInfo vectors_info = {VK_NULL_HANDLE, fsr.vectors.view,
                                          VK_IMAGE_LAYOUT_GENERAL};
    VkWriteDescriptorSet writes[3] = {};
    for (uint32_t i = 0; i < 3; ++i) {
      writes[i].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
      writes[i].dstSet = set;
    }
    writes[0].dstBinding = 0;
    writes[0].descriptorCount = 1;
    writes[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    writes[0].pBufferInfo = &constants_info;
    writes[1].dstBinding = 1;
    writes[1].descriptorCount = 2;
    writes[1].descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
    writes[1].pImageInfo = textures;
    writes[2].dstBinding = 3;
    writes[2].descriptorCount = 1;
    writes[2].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
    writes[2].pImageInfo = &vectors_info;
    dfn.vkUpdateDescriptorSets(device, 3, writes, 0, nullptr);
    EndRenderPass();
    HdrTransitionImage(fsr.vectors, VK_IMAGE_LAYOUT_GENERAL);
    if (!vectors_only) {
      HdrTransitionImage(fsr.output, VK_IMAGE_LAYOUT_GENERAL);
    }
    SubmitBarriers(true);
    timer_slot = TaaTimerBegin();
    // The game's textures were made visible to the guest shader stages.
    VkMemoryBarrier memory_barrier = {VK_STRUCTURE_TYPE_MEMORY_BARRIER, nullptr, 0,
                                      VK_ACCESS_SHADER_READ_BIT};
    deferred_command_buffer_.CmdVkPipelineBarrier(guest_shader_pipeline_stages_,
                                                  VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1,
                                                  &memory_barrier, 0, nullptr, 0, nullptr);
    BindExternalComputePipeline(taa_vectors_pipeline_);
    deferred_command_buffer_.CmdVkBindDescriptorSets(VK_PIPELINE_BIND_POINT_COMPUTE,
                                                     taa_vectors_pipeline_layout_, 0, 1, &set, 0,
                                                     nullptr);
    deferred_command_buffer_.CmdVkDispatch((render_width + 15) / 16, (render_height + 7) / 8, 1);
    HdrTransitionImage(fsr.vectors, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  } else {
    // t0 (binding 1) the depth, t1 (2) the stencil view, t2 (3) the scene (the texture
    // cache's views); u0 (4) the vectors, u1 (5) the colour, u2 (6) the depth, at the render
    // size.
    VkDescriptorSet set = taa_gather_descriptors_[frame_index];
    VkDescriptorImageInfo sampled_infos[3] = {
        textures[0],
        textures[1],
        {VK_NULL_HANDLE, scene_view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
    };
    VkDescriptorImageInfo storage_infos[3] = {
        {VK_NULL_HANDLE, fsr.vectors.view, VK_IMAGE_LAYOUT_GENERAL},
        {VK_NULL_HANDLE, fsr.color_in.view, VK_IMAGE_LAYOUT_GENERAL},
        {VK_NULL_HANDLE, fsr.depth_in.view, VK_IMAGE_LAYOUT_GENERAL},
    };
    VkWriteDescriptorSet writes[3] = {};
    for (uint32_t i = 0; i < 3; ++i) {
      writes[i].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
      writes[i].dstSet = set;
    }
    writes[0].dstBinding = 0;
    writes[0].descriptorCount = 1;
    writes[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    writes[0].pBufferInfo = &constants_info;
    writes[1].dstBinding = 1;
    writes[1].descriptorCount = 3;
    writes[1].descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
    writes[1].pImageInfo = sampled_infos;
    writes[2].dstBinding = 4;
    writes[2].descriptorCount = 3;
    writes[2].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
    writes[2].pImageInfo = storage_infos;
    dfn.vkUpdateDescriptorSets(device, 3, writes, 0, nullptr);
    EndRenderPass();
    HdrTransitionImage(fsr.vectors, VK_IMAGE_LAYOUT_GENERAL);
    HdrTransitionImage(fsr.color_in, VK_IMAGE_LAYOUT_GENERAL);
    HdrTransitionImage(fsr.depth_in, VK_IMAGE_LAYOUT_GENERAL);
    HdrTransitionImage(fsr.output, VK_IMAGE_LAYOUT_GENERAL);
    SubmitBarriers(true);
    timer_slot = TaaTimerBegin();
    // The game's textures were made visible to the guest shader stages.
    VkMemoryBarrier memory_barrier = {VK_STRUCTURE_TYPE_MEMORY_BARRIER, nullptr, 0,
                                      VK_ACCESS_SHADER_READ_BIT};
    deferred_command_buffer_.CmdVkPipelineBarrier(guest_shader_pipeline_stages_,
                                                  VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1,
                                                  &memory_barrier, 0, nullptr, 0, nullptr);
    BindExternalComputePipeline(taa_gather_pipeline_);
    deferred_command_buffer_.CmdVkBindDescriptorSets(VK_PIPELINE_BIND_POINT_COMPUTE,
                                                     taa_gather_pipeline_layout_, 0, 1, &set, 0,
                                                     nullptr);
    deferred_command_buffer_.CmdVkDispatch((render_width + 15) / 16, (render_height + 7) / 8, 1);
    HdrTransitionImage(fsr.vectors, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
    HdrTransitionImage(fsr.color_in, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
    HdrTransitionImage(fsr.depth_in, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  }
  // Frame generation (rexglue-frame-generation.patch): the depth, for its
  // preparation at the swap; without FSR anti-aliasing, nothing more. With the squeezed
  // scene it is the gathered one, at the render size, like the vectors.
  if (!squeezed) {
    FgCopyDepth(textures[0].imageView, width, height);
  } else {
    FgCopyDepth(fsr.depth_in.view, render_width, render_height);
  }
  if (vectors_only) {
    SubmitBarriers(true);
    taa_frame_.done = true;
    taa_frame_.status = 'v';
    TaaTimerEnd(timer_slot);
    return;
  }
  // The reactive mask, from this frame's snapshots of the scene.
  if (taa_frame_.snapshots == 3 && fsr.reactive.image != VK_NULL_HANDLE) {
    TaaRunReactive(textures[1].imageView);
  } else {
    taa_frame_.snapshots = 0;
  }
  SubmitBarriers(true);
  taa_frame_.done = true;
  taa_frame_.status = '+';
  if (TaaDebug() == 3) {
    // The raw (jittered) input.
    TaaTimerEnd(timer_slot);
    return;
  }
  static int debug_view_logged = -1;
  if ((TaaDebug() == 5 || TaaDebug() == 6) && TaaDebug() != debug_view_logged) {
    debug_view_logged = TaaDebug();
    REXGPU_INFO("Temporal AA: debug view {}, the scene's view {}", TaaDebug(),
                scene_view != VK_NULL_HANDLE ? "found" : "missing");
  }
  if ((TaaDebug() == 5 || TaaDebug() == 6) && scene_view != VK_NULL_HANDLE && !squeezed) {
    // A development view instead of FSR's output (7 is the upscaling log, not a view).
    TaaRunDebugView(scene_view, TaaDebug() - 5);
  } else {

  // FSR, recorded into the real command buffer where it falls (it restores
  // the states it was given), then the output into the scene texture.
  TaaFsrDispatch dispatch = {};
  dispatch.dispatch = fsr.runtime.dispatch;
  dispatch.context = fsr.context;
  dispatch.failed = &fsr.dispatch_failed;
  dispatch.pipeline_barrier = dfn.vkCmdPipelineBarrier;
  dispatch.copy_image = dfn.vkCmdCopyImage;
  ffxDispatchDescUpscale& desc = dispatch.desc;
  desc.header.type = FFX_API_DISPATCH_DESC_TYPE_UPSCALE;
  desc.color = squeezed
                   ? TaaFsrResource(fsr.color_in.image, VK_FORMAT_R16G16B16A16_SFLOAT, render_width,
                                    render_height,
                                    VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT,
                                    FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ)
                   : TaaFsrResource(scene, scene_format, width, height,
                                    VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT,
                                    FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ);
  desc.depth = squeezed
                   ? TaaFsrResource(fsr.depth_in.image, VK_FORMAT_R32_SFLOAT, render_width,
                                    render_height,
                                    VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT,
                                    FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ)
                   : TaaFsrResource(depth, depth_format, width, height,
                                    VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT,
                                    FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ);
  desc.motionVectors = TaaFsrResource(fsr.vectors.image, VK_FORMAT_R16G16_SFLOAT, render_width,
                                      render_height,
                                      VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT,
                                      FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ);
  if (taa_frame_.snapshots == 3) {
    desc.reactive = TaaFsrResource(fsr.reactive.image, VK_FORMAT_R8_UNORM, width, height,
                                   VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT,
                                   FFX_API_RESOURCE_STATE_PIXEL_COMPUTE_READ);
  }
  desc.output = TaaFsrResource(fsr.output.image, VK_FORMAT_R16G16B16A16_SFLOAT, width, height,
                               VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT |
                                   VK_IMAGE_USAGE_TRANSFER_SRC_BIT,
                               FFX_API_RESOURCE_STATE_UNORDERED_ACCESS);
  float jitter[2];
  TaaFsrJitter(jitter);
  desc.jitterOffset = {jitter[0], jitter[1]};
  desc.motionVectorScale = {1.0f, 1.0f};
  desc.renderSize = {render_width, render_height};
  desc.upscaleSize = {width, height};
  float sharpness = TaaSharpness();
  desc.enableSharpening = sharpness > 0.0f;
  desc.sharpness = sharpness;
  desc.frameTimeDelta = taa_frame_time_ms_;
  desc.preExposure = 1.0f;
  desc.reset = taa_camera_.reset;
  // (Development, temporal_aa_debug 10: the planes the other way round.)
  desc.cameraNear = TaaDebug() == 10 ? taa_camera_.far_plane : taa_camera_.near_plane;
  desc.cameraFar = TaaDebug() == 10 ? taa_camera_.near_plane : taa_camera_.far_plane;
  desc.cameraFovAngleVertical = taa_camera_.fov_vertical;
  desc.viewSpaceToMetersFactor = 1.0f;
  desc.flags = TaaDebug() == 1 ? FFX_UPSCALE_FLAG_DRAW_DEBUG_VIEW : 0;
  deferred_command_buffer_.CmdExternalCallback(TaaFsrDispatchCallback, &dispatch,
                                               sizeof(dispatch));
  // FSR bound its own compute pipeline and descriptor sets.
  current_external_compute_pipeline_ = VK_NULL_HANDLE;
  current_guest_graphics_pipeline_ = VK_NULL_HANDLE;
  current_external_graphics_pipeline_ = VK_NULL_HANDLE;
  current_graphics_descriptor_sets_bound_up_to_date_ = 0;
  }

  // FSR's reads of the scene (compute) before the transition below, whose
  // source scope is the guest shader stages, and the copy into it.
  deferred_command_buffer_.CmdVkPipelineBarrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                                guest_shader_pipeline_stages_, 0, 0, nullptr, 0,
                                                nullptr, 0, nullptr);
  texture_cache_->TransitionActiveTexture(kTaaFetchScene, true);
  HdrTransitionImage(fsr.output, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL);
  SubmitBarriers(true);
  VkImageCopy region = {};
  region.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
  region.dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
  region.extent = {width, height, 1};
  deferred_command_buffer_.CmdVkCopyImage(fsr.output.image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                                          scene, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, region);
  texture_cache_->TransitionActiveTexture(kTaaFetchScene, false);
  HdrTransitionImage(fsr.output, VK_IMAGE_LAYOUT_GENERAL);
  TaaTimerEnd(timer_slot);
#else
  (void)pixel_shader;
#endif  // REX_HAS_FSR
}

}  // namespace rex::graphics::vulkan
