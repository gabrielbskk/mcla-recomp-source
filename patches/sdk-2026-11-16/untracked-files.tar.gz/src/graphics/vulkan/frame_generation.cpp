/**
 * Frame generation on Vulkan (rexglue-frame-generation.patch): the command
 * processor's part, which on Vulkan includes generation itself. FidelityFX's
 * frame generation context comes from the same Vulkan runtime as FSR's
 * (amd_fidelityfx_vk, cmake/rexglue_fsr.cmake, its swap chain provider a stub)
 * and runs without a swap chain (FFX_FRAMEGENERATION_FLAG_NO_SWAPCHAIN_CONTEXT_NOTIFY):
 * everything is in the frame's own submission, at the swap, before the next
 * frame's work. The refresher writes the HUD-less image (hdr_refresh_fg.cs.xesl:
 * the scene's code values before the UI, scaled to the generation size if
 * smaller); the preparation reads this frame's depth (copied at the
 * anti-aliasing draw, fg_depth_copy.cs.xesl) and motion vectors (temporal
 * anti-aliasing's pass); generation interpolates between the previous HUD-less
 * image and this one; and hdr_refresh_fg.cs composes the generated frame with
 * this frame's UI layer and levels into the presenter's image. The presenter
 * paints it and the real frame into a pair of present images, and its pacer
 * shows the generated one half a frame before the real one
 * (vulkan_presenter_frame_generation.cpp).
 */

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <cstdlib>
#include <thread>
#include <utility>
#include <vector>

#include <rex/cvar.h>
#include <rex/graphics/vulkan/command_processor.h>
#include <rex/logging.h>
#include <rex/graphics/mcla_lsfg_api.h>
#include <rex/ui/vulkan/util.h>

#include "../frame_generation_fsr.h"
#include "../temporal_aa_fsr.h"

#if REX_PLATFORM_ANDROID
#include <dlfcn.h>
#endif

#if defined(REX_HAS_FSR) && REX_HAS_FSR
#include <ffx_api/vk/ffx_api_vk.h>
#endif

namespace rex::graphics::vulkan {

#if defined(REX_HAS_FSR) && REX_HAS_FSR
// temporal_aa.cpp: FidelityFX's device function lookup (with the core names of
// the KHR functions it asks for).
PFN_vkGetDeviceProcAddr TaaFfxDeviceProcAddr(const ui::vulkan::VulkanDevice* vulkan_device);
#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
void TaaSetStaticVulkanFunctions(const ui::vulkan::VulkanInstance::Functions* ifn,
                                 const ui::vulkan::VulkanDevice::Functions* dfn);
#endif
#endif

namespace shaders {
#include "../shaders/vulkan_spirv/fg_depth_copy_cs.h"
#include "../shaders/vulkan_spirv/fg_hudless_downscale_cs.h"
#include "../shaders/vulkan_spirv/hdr_refresh_fg_cs.h"
}  // namespace shaders

struct VulkanCommandProcessor::FgContext {
  // The context for a generation and render size, made on another thread (it
  // takes a while); a failure stays one for its sizes.
  enum State : uint32_t { kNone, kCreating, kReady, kFailed };
  std::atomic<uint32_t> state{kNone};
  std::thread thread;
  uint32_t width = 0;
  uint32_t height = 0;
  uint32_t render_width = 0;
  uint32_t render_height = 0;
  void* lsfg_module = nullptr;  // Kept loaded for the process; callbacks may be in flight.
  decltype(&mcla_lsfg_create) lsfg_create = nullptr;
  decltype(&mcla_lsfg_record) lsfg_record = nullptr;
  decltype(&mcla_lsfg_destroy) lsfg_destroy = nullptr;
  void* lsfg_context = nullptr;
  std::vector<std::pair<uint64_t, void*>> lsfg_retired;
  uint64_t lsfg_frames = 0;
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  FsrRuntime runtime;
  ffxContext context = nullptr;
#endif
  // Set on the submission thread when a frame's generation failed (its
  // generated frame isn't shown, and generation is given up).
  std::atomic<bool> dispatch_failed{false};
  bool given_up = false;
  // Released contexts, destroyed once the submissions that may use them are
  // done.
  std::vector<std::pair<uint64_t, void*>> retired;
  // FidelityFX's frame IDs: one more per generated frame.
  uint64_t next_frame_id = 1;
  // The next generation has no history (the first, after a frame without).
  bool reset_next = true;
  // Guest frames in a row without generation; after many, the context (hundreds
  // of MB at 4K) is released until generation can run again.
  uint32_t frames_without_generation = 0;
  // frame_generation_timing (development): timestamps around generation and
  // the compose, a pair per slot, read once its submission is done.
  static constexpr uint32_t kTimerSlots = 4;
  VkQueryPool timer_pool = VK_NULL_HANDLE;
  PFN_vkCmdWriteTimestamp write_timestamp = nullptr;
  PFN_vkGetQueryPoolResults get_results = nullptr;
  uint64_t timer_submission[kTimerSlots] = {};  // 0: free
  uint32_t timer_next = 0;
  double timer_tick_ms = 0.0;
  double timer_ms = 0.0;
  uint32_t timer_count = 0;
};

void VulkanCommandProcessor::FgContextDeleter::operator()(FgContext* context) const {
  if (context->thread.joinable()) {
    context->thread.join();
  }
  delete context;
}

namespace {

bool LsfgRequested() {
#if REX_PLATFORM_ANDROID
  return rex::cvar::GetFlagByName("frame_generation") == "lsfg";
#else
  return false;
#endif
}

struct LsfgDispatch {
  decltype(&mcla_lsfg_record) record;
  void* context;
  MclaLsfgFrame frame;
  std::atomic<bool>* failed;
  bool expected_ready;
};

void LsfgDispatchCallback(VkCommandBuffer command, const void* bytes) {
  LsfgDispatch dispatch;
  std::memcpy(&dispatch, bytes, sizeof(dispatch));
  dispatch.frame.command_buffer = command;
  char error[512] = {};
  int ready = 0;
  if (dispatch.record(dispatch.context, &dispatch.frame, &ready, error, sizeof(error)) ||
      bool(ready) != dispatch.expected_ready) {
    dispatch.failed->store(true, std::memory_order_release);
    REXGPU_ERROR("LSFG recording failed: {} ready={} expected={}", error, ready,
                 dispatch.expected_ready);
  }
}

#if defined(REX_HAS_FSR) && REX_HAS_FSR
struct FgDispatch {
  PfnFfxConfigure configure;
  PfnFfxDispatch dispatch;
  // The context's handle as it was when recorded.
  ffxContext context;
  std::atomic<bool>* failed;
  // frame_generation_debug_fail 2: the dispatch fails.
  bool force_failure;
  uint32_t configure_flags;
  ffxDispatchDescFrameGenerationPrepare prepare;
  ffxDispatchDescFrameGeneration generate;
};

// On the submission thread, into the frame's command buffer: the frame's
// configuration, the preparation, generation.
void FgDispatchCallback(VkCommandBuffer command_buffer, const void* data) {
  FgDispatch dispatch;
  std::memcpy(&dispatch, data, sizeof(dispatch));
  ffxContext context = dispatch.context;
  ffxConfigureDescFrameGeneration config = {};
  config.header.type = FFX_API_CONFIGURE_DESC_TYPE_FRAMEGENERATION;
  config.frameGenerationEnabled = true;
  config.flags = dispatch.configure_flags;
  config.generationRect = dispatch.generate.generationRect;
  config.frameID = dispatch.generate.frameID;
  const char* what = "configuration";
  ffxReturnCode_t result =
      dispatch.force_failure ? FFX_API_RETURN_ERROR : dispatch.configure(&context, &config.header);
  if (result == FFX_API_RETURN_OK) {
    what = "preparation";
    dispatch.prepare.commandList = command_buffer;
    result = dispatch.dispatch(&context, &dispatch.prepare.header);
  }
  if (result == FFX_API_RETURN_OK) {
    what = "dispatch";
    dispatch.generate.commandList = command_buffer;
    result = dispatch.dispatch(&context, &dispatch.generate.header);
  }
  if (result == FFX_API_RETURN_OK) {
    return;
  }
  dispatch.failed->store(true, std::memory_order_release);
  static std::atomic<bool> failure_logged{false};
  if (!failure_logged.exchange(true)) {
    REXGPU_ERROR("Frame generation: its {} failed ({}); giving frame generation up", what,
                 result);
  }
}

FfxApiResource FgResource(VkImage image, VkFormat format, uint32_t width, uint32_t height,
                          VkImageUsageFlags usage, uint32_t state) {
  VkImageCreateInfo info = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
  info.imageType = VK_IMAGE_TYPE_2D;
  info.format = format;
  info.extent = {width, height, 1};
  info.mipLevels = 1;
  info.arrayLayers = 1;
  info.samples = VK_SAMPLE_COUNT_1_BIT;
  info.usage = usage;
  return ffxApiGetResourceVK(image, ffxApiGetImageResourceDescriptionVK(image, info, 0), state);
}
#endif

struct FgTimestamp {
  PFN_vkCmdWriteTimestamp write_timestamp;
  VkQueryPool pool;
  uint32_t query;
  VkPipelineStageFlagBits stage;
};

void FgTimestampCallback(VkCommandBuffer command_buffer, const void* data) {
  FgTimestamp timestamp;
  std::memcpy(&timestamp, data, sizeof(timestamp));
  timestamp.write_timestamp(command_buffer, timestamp.stage, timestamp.pool, timestamp.query);
}

}  // namespace

bool VulkanCommandProcessor::FgSetup() {
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  // hdr_refresh_fg.cs: hdr_refresh's sets and constants, and the HUD-less
  // image (set 4).
  VkDescriptorSetLayout refresh_set_layouts[] = {
      swap_descriptor_set_layout_uniform_texel_buffer_, swap_descriptor_set_layout_sampled_image_,
      swap_descriptor_set_layout_storage_image_, hdr_descriptor_set_layout_images_,
      swap_descriptor_set_layout_storage_image_};
  VkPushConstantRange push_constant_range = {VK_SHADER_STAGE_COMPUTE_BIT, 0,
                                             sizeof(HdrRefreshConstants)};
  VkPipelineLayoutCreateInfo layout_create_info = {VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
  layout_create_info.setLayoutCount = uint32_t(std::size(refresh_set_layouts));
  layout_create_info.pSetLayouts = refresh_set_layouts;
  layout_create_info.pushConstantRangeCount = 1;
  layout_create_info.pPushConstantRanges = &push_constant_range;
  if (dfn.vkCreatePipelineLayout(device, &layout_create_info, nullptr,
                                 &hdr_refresh_fg_pipeline_layout_) == VK_SUCCESS) {
    hdr_refresh_fg_pipeline_ = ui::vulkan::util::CreateComputePipeline(
        vulkan_device, hdr_refresh_fg_pipeline_layout_, shaders::hdr_refresh_fg_cs,
        sizeof(shaders::hdr_refresh_fg_cs));
  }
  // fg_hudless_downscale.cs and fg_depth_copy.cs: a sampled image, a storage
  // image, four sizes.
  VkDescriptorSetLayout copy_set_layouts[] = {swap_descriptor_set_layout_sampled_image_,
                                              swap_descriptor_set_layout_storage_image_};
  push_constant_range.size = sizeof(uint32_t) * 4;
  layout_create_info.setLayoutCount = uint32_t(std::size(copy_set_layouts));
  layout_create_info.pSetLayouts = copy_set_layouts;
  if (dfn.vkCreatePipelineLayout(device, &layout_create_info, nullptr,
                                 &fg_copy_pipeline_layout_) == VK_SUCCESS) {
    fg_downscale_pipeline_ = ui::vulkan::util::CreateComputePipeline(
        vulkan_device, fg_copy_pipeline_layout_, shaders::fg_hudless_downscale_cs,
        sizeof(shaders::fg_hudless_downscale_cs));
    fg_depth_copy_pipeline_ = ui::vulkan::util::CreateComputePipeline(
        vulkan_device, fg_copy_pipeline_layout_, shaders::fg_depth_copy_cs,
        sizeof(shaders::fg_depth_copy_cs));
  }
  if (hdr_refresh_fg_pipeline_ == VK_NULL_HANDLE || fg_downscale_pipeline_ == VK_NULL_HANDLE ||
      fg_depth_copy_pipeline_ == VK_NULL_HANDLE) {
    REXGPU_ERROR("Failed to create the frame generation pipelines");
    return false;
  }
  // The sets, per frame in flight: the HUD-less image (storage), the
  // downscale's (sampled, storage), the depth copy's (sampled, storage), the
  // compose's (the source: sampled; the destination: storage; hdr_refresh's
  // four images; the HUD-less image: storage).
  VkDescriptorPoolSize pool_sizes[2] = {
      {VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, kMaxFramesInFlight * 7},
      {VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, kMaxFramesInFlight * 5},
  };
  VkDescriptorPoolCreateInfo pool_create_info = {VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
  pool_create_info.maxSets = kMaxFramesInFlight * 9;
  pool_create_info.poolSizeCount = uint32_t(std::size(pool_sizes));
  pool_create_info.pPoolSizes = pool_sizes;
  if (dfn.vkCreateDescriptorPool(device, &pool_create_info, nullptr, &fg_descriptor_pool_) !=
      VK_SUCCESS) {
    REXGPU_ERROR("Failed to create the frame generation descriptor pool");
    return false;
  }
  for (FgFrameSets& sets : fg_sets_) {
    const std::pair<VkDescriptorSet*, VkDescriptorSetLayout> allocations[] = {
        {&sets.hudless, swap_descriptor_set_layout_storage_image_},
        {&sets.downscale_source, swap_descriptor_set_layout_sampled_image_},
        {&sets.downscale_dest, swap_descriptor_set_layout_storage_image_},
        {&sets.depth_source, swap_descriptor_set_layout_sampled_image_},
        {&sets.depth_dest, swap_descriptor_set_layout_storage_image_},
        {&sets.compose_source, swap_descriptor_set_layout_sampled_image_},
        {&sets.compose_dest, swap_descriptor_set_layout_storage_image_},
        {&sets.compose_images, hdr_descriptor_set_layout_images_},
        {&sets.compose_hudless, swap_descriptor_set_layout_storage_image_},
    };
    for (const auto& allocation : allocations) {
      VkDescriptorSetAllocateInfo allocate_info = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
      allocate_info.descriptorPool = fg_descriptor_pool_;
      allocate_info.descriptorSetCount = 1;
      allocate_info.pSetLayouts = &allocation.second;
      if (dfn.vkAllocateDescriptorSets(device, &allocate_info, allocation.first) != VK_SUCCESS) {
        REXGPU_ERROR("Failed to allocate the frame generation descriptor sets");
        return false;
      }
    }
  }
  return true;
}

void VulkanCommandProcessor::FgShutdown() {
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  if (fg_context_) {
    FgContext& fg = *fg_context_;
    if (fg.thread.joinable()) {
      fg.thread.join();
    }
#if defined(REX_HAS_FSR) && REX_HAS_FSR
    if (fg.context) {
      fg.retired.emplace_back(0, fg.context);
      fg.context = nullptr;
    }
#endif
    FgCollectRetired(true);
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyQueryPool, device, fg.timer_pool);
    fg_context_.reset();
  }
  for (HdrImage* image : {&fg_hudless_, &fg_hudless_small_, &fg_generated_, &fg_depth_,
                          &fg_dummy_}) {
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImageView, device, image->view);
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImage, device, image->image);
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkFreeMemory, device, image->memory);
    *image = HdrImage();
  }
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyDescriptorPool, device,
                                         fg_descriptor_pool_);
  fg_sets_ = {};
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, fg_depth_copy_pipeline_);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, fg_downscale_pipeline_);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, hdr_refresh_fg_pipeline_);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipelineLayout, device,
                                         fg_copy_pipeline_layout_);
  ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyPipelineLayout, device,
                                         hdr_refresh_fg_pipeline_layout_);
}

void VulkanCommandProcessor::FgCollectRetired(bool all) {
  if (!fg_context_) {
    return;
  }
  FgContext& fg = *fg_context_;
  for (auto it = fg.lsfg_retired.begin(); it != fg.lsfg_retired.end();) {
    if ((!all && it->first > GetCompletedSubmission()) ||
        fg.lsfg_destroy(it->second, all ? UINT64_MAX : GetCompletedSubmission()) != 0) {
      ++it;
    } else {
      it = fg.lsfg_retired.erase(it);
    }
  }
  for (auto it = fg.retired.begin(); it != fg.retired.end();) {
    if (!all && it->first > GetCompletedSubmission()) {
      ++it;
      continue;
    }
#if defined(REX_HAS_FSR) && REX_HAS_FSR
    ffxContext context = it->second;
    fg.runtime.destroy(&context, nullptr);
#endif
    it = fg.retired.erase(it);
  }
}

bool VulkanCommandProcessor::FgEnsureImage(HdrImage& image, uint32_t width, uint32_t height,
                                           VkFormat format) {
  if (image.image != VK_NULL_HANDLE && image.width == width && image.height == height) {
    return true;
  }
  if (image.image != VK_NULL_HANDLE) {
    // Destroyed once the submissions that may use it are done.
    destroy_image_views_.emplace_back(GetCurrentSubmission(), image.view);
    destroy_images_.emplace_back(GetCurrentSubmission(), image.image);
    destroy_memory_.emplace_back(GetCurrentSubmission(), image.memory);
    image = HdrImage();
  }
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  const ui::vulkan::VulkanDevice::Functions& dfn = vulkan_device->functions();
  const VkDevice device = vulkan_device->device();
  VkImageCreateInfo image_create_info = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
  image_create_info.imageType = VK_IMAGE_TYPE_2D;
  image_create_info.format = format;
  image_create_info.extent = {width, height, 1};
  image_create_info.mipLevels = 1;
  image_create_info.arrayLayers = 1;
  image_create_info.samples = VK_SAMPLE_COUNT_1_BIT;
  image_create_info.tiling = VK_IMAGE_TILING_OPTIMAL;
  // FidelityFX copies some of what it's given (the HUD-less image into its
  // history) with transfers.
  image_create_info.usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT |
                            VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
  image_create_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
  image_create_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
  if (!ui::vulkan::util::CreateDedicatedAllocationImage(
          vulkan_device, image_create_info, ui::vulkan::util::MemoryPurpose::kDeviceLocal,
          image.image, image.memory)) {
    REXGPU_ERROR("Frame generation: couldn't create a {}x{} image", width, height);
    return false;
  }
  VkImageViewCreateInfo view_create_info = {VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
  view_create_info.image = image.image;
  view_create_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
  view_create_info.format = format;
  view_create_info.subresourceRange = ui::vulkan::util::InitializeSubresourceRange();
  if (dfn.vkCreateImageView(device, &view_create_info, nullptr, &image.view) != VK_SUCCESS) {
    REXGPU_ERROR("Frame generation: couldn't create a {}x{} image view", width, height);
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkDestroyImage, device, image.image);
    ui::vulkan::util::DestroyAndNullHandle(dfn.vkFreeMemory, device, image.memory);
    return false;
  }
  image.width = width;
  image.height = height;
  image.layout = VK_IMAGE_LAYOUT_UNDEFINED;
  return true;
}

void VulkanCommandProcessor::FgWriteImageSet(VkDescriptorSet set, VkImageView view,
                                             VkDescriptorType type, VkImageLayout layout) {
  VkDescriptorImageInfo image_info = {VK_NULL_HANDLE, view, layout};
  VkWriteDescriptorSet write = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
  write.dstSet = set;
  write.descriptorCount = 1;
  write.descriptorType = type;
  write.pImageInfo = &image_info;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  vulkan_device->functions().vkUpdateDescriptorSets(vulkan_device->device(), 1, &write, 0,
                                                     nullptr);
}

void VulkanCommandProcessor::FgCopyDepth(VkImageView depth_view, uint32_t width,
                                         uint32_t height) {
  // Only while the presenter takes frame generation's inputs.
  if (!frame_generation_inputs_given_ || fg_depth_copy_pipeline_ == VK_NULL_HANDLE ||
      depth_view == VK_NULL_HANDLE ||
      !FgEnsureImage(fg_depth_, width, height, VK_FORMAT_R32_SFLOAT)) {
    return;
  }
  const FgFrameSets& sets = fg_sets_[frame_current_ % kMaxFramesInFlight];
  // The guest's texture as the vectors pass read it.
  FgWriteImageSet(sets.depth_source, depth_view, VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,
                  VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  FgWriteImageSet(sets.depth_dest, fg_depth_.view, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                  VK_IMAGE_LAYOUT_GENERAL);
  HdrTransitionImage(fg_depth_, VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  BindExternalComputePipeline(fg_depth_copy_pipeline_);
  const VkDescriptorSet descriptor_sets[] = {sets.depth_source, sets.depth_dest};
  deferred_command_buffer_.CmdVkBindDescriptorSets(VK_PIPELINE_BIND_POINT_COMPUTE,
                                                   fg_copy_pipeline_layout_, 0, 2,
                                                   descriptor_sets, 0, nullptr);
  const uint32_t constants[4] = {width, height, 0, 0};
  deferred_command_buffer_.CmdVkPushConstants(fg_copy_pipeline_layout_,
                                              VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(constants),
                                              constants);
  deferred_command_buffer_.CmdVkDispatch((width + 15) / 16, (height + 7) / 8, 1);
  HdrTransitionImage(fg_depth_, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  fg_depth_frame_ = frame_current_;
}

bool VulkanCommandProcessor::FgEnsureResources(uint32_t width, uint32_t height,
                                               uint32_t generation_width,
                                               uint32_t generation_height) {
  if (!generation_width || !generation_height || generation_width > width ||
      generation_height > height || hdr_refresh_fg_pipeline_ == VK_NULL_HANDLE ||
      fg_downscale_pipeline_ == VK_NULL_HANDLE) {
    return false;
  }
  if (fg_context_ && fg_context_->given_up) {
    return false;
  }
  // A texel for set 4 where nothing is written to it.
  if (fg_dummy_.image == VK_NULL_HANDLE) {
    if (!FgEnsureImage(fg_dummy_, 1, 1, VK_FORMAT_R16G16B16A16_SFLOAT)) {
      return false;
    }
    HdrTransitionImage(fg_dummy_, VK_IMAGE_LAYOUT_GENERAL);
  }
  // The full-size image, and the generation-size one if smaller (the old ones
  // are destroyed once the submissions so far are done).
  if (!FgEnsureImage(fg_hudless_, width, height, VK_FORMAT_R16G16B16A16_SFLOAT)) {
    return false;
  }
  if ((generation_width != width || generation_height != height) &&
      !FgEnsureImage(fg_hudless_small_, generation_width, generation_height,
                     VK_FORMAT_R16G16B16A16_SFLOAT)) {
    return false;
  }
  return true;
}

bool VulkanCommandProcessor::FgDownscaleHudless(uint32_t width, uint32_t height,
                                                uint32_t generation_width,
                                                uint32_t generation_height) {
  if (generation_width == width && generation_height == height) {
    return true;
  }
  if (fg_hudless_small_.image == VK_NULL_HANDLE || fg_hudless_small_.width != generation_width ||
      fg_hudless_small_.height != generation_height) {
    return false;
  }
  const FgFrameSets& sets = fg_sets_[frame_current_ % kMaxFramesInFlight];
  FgWriteImageSet(sets.downscale_source, fg_hudless_.view, VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,
                  VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  FgWriteImageSet(sets.downscale_dest, fg_hudless_small_.view, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                  VK_IMAGE_LAYOUT_GENERAL);
  HdrTransitionImage(fg_hudless_small_, VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  BindExternalComputePipeline(fg_downscale_pipeline_);
  const VkDescriptorSet descriptor_sets[] = {sets.downscale_source, sets.downscale_dest};
  deferred_command_buffer_.CmdVkBindDescriptorSets(VK_PIPELINE_BIND_POINT_COMPUTE,
                                                   fg_copy_pipeline_layout_, 0, 2,
                                                   descriptor_sets, 0, nullptr);
  const uint32_t constants[4] = {width, height, generation_width, generation_height};
  deferred_command_buffer_.CmdVkPushConstants(fg_copy_pipeline_layout_,
                                              VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(constants),
                                              constants);
  deferred_command_buffer_.CmdVkDispatch((generation_width + 15) / 16,
                                         (generation_height + 7) / 8, 1);
  HdrTransitionImage(fg_hudless_small_, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
  SubmitBarriers(true);
  return true;
}

bool VulkanCommandProcessor::FgEnsureContext(uint32_t width, uint32_t height,
                                             uint32_t render_width, uint32_t render_height) {
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  FgContext& fg = *fg_context_;
  uint32_t state = fg.state.load(std::memory_order_acquire);
  const bool same_size = fg.width == width && fg.height == height &&
                         fg.render_width == render_width && fg.render_height == render_height;
  if (same_size) {
    if (state == FgContext::kReady) {
      if (fg.thread.joinable()) {
        fg.thread.join();
      }
      return true;
    }
    if (state != FgContext::kNone) {
      // Being made, or failed for these sizes.
      return false;
    }
  }
  if (state == FgContext::kCreating) {
    return false;
  }
  // New sizes: the old context goes once the submissions that may use it are
  // done.
  if (fg.thread.joinable()) {
    fg.thread.join();
  }
  if (fg.context) {
    fg.retired.emplace_back(GetCurrentSubmission(), fg.context);
    fg.context = nullptr;
  }
  fg.width = width;
  fg.height = height;
  fg.render_width = render_width;
  fg.render_height = render_height;
  fg.reset_next = true;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();
  if (REXCVAR_QUERY(int32_t, frame_generation_debug_fail) == 1) {
    REXGPU_ERROR("Frame generation: its context was made to fail (frame_generation_debug_fail)");
    fg.state.store(FgContext::kFailed, std::memory_order_release);
    return false;
  }
  if (!vulkan_device->temporal_aa_features()) {
    // Created without the features FidelityFX's shaders use
    // (temporal_aa_device_features).
    REXGPU_WARN("Frame generation: the Vulkan device was created without the features "
                "FidelityFX needs; not available until the next start");
    fg.state.store(FgContext::kFailed, std::memory_order_release);
    return false;
  }
  if (!fg.runtime.Load("vk")) {
    REXGPU_WARN("Frame generation: the Vulkan FidelityFX runtime couldn't be loaded");
    fg.state.store(FgContext::kFailed, std::memory_order_release);
    return false;
  }
#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
  TaaSetStaticVulkanFunctions(&vulkan_device->vulkan_instance()->functions(),
                              &vulkan_device->functions());
#endif
  const PFN_vkGetDeviceProcAddr get_device_proc_addr = TaaFfxDeviceProcAddr(vulkan_device);
  const VkDevice device = vulkan_device->device();
  const VkPhysicalDevice physical_device = vulkan_device->physical_device();
  fg.state.store(FgContext::kCreating, std::memory_order_release);
  FgContext* fg_pointer = &fg;
  fg.thread = std::thread([fg_pointer, device, physical_device, get_device_proc_addr, width,
                           height, render_width, render_height]() {
    ffxCreateBackendVKDesc backend = {};
    backend.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_BACKEND_VK;
    backend.vkDevice = device;
    backend.vkPhysicalDevice = physical_device;
    backend.vkDeviceProcAddr = get_device_proc_addr;
    ffxCreateContextDescFrameGeneration create = {};
    create.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_FRAMEGENERATION;
    create.header.pNext = &backend.header;
    create.flags = kFgCreateFlags;
    create.displaySize = {width, height};
    create.maxRenderSize = {render_width, render_height};
    // The code values the refresher writes (hdr_refresh_fg.cs.xesl).
    create.backBufferFormat = FFX_API_SURFACE_FORMAT_R16G16B16A16_FLOAT;
    const auto start = std::chrono::steady_clock::now();
    ffxContext context = nullptr;
    ffxReturnCode_t result = fg_pointer->runtime.create(&context, &create.header, nullptr);
    if (result != FFX_API_RETURN_OK || !context) {
      REXGPU_ERROR("Frame generation: its context couldn't be created for {}x{} (render {}x{}): "
                   "{}",
                   width, height, render_width, render_height, result);
      fg_pointer->state.store(FgContext::kFailed, std::memory_order_release);
      return;
    }
    fg_pointer->context = context;
    REXGPU_INFO("Frame generation: ready for {}x{} (render {}x{}, Vulkan) after {} ms", width,
                height, render_width, render_height,
                std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - start)
                    .count());
    fg_pointer->state.store(FgContext::kReady, std::memory_order_release);
  });
  return false;
#else
  (void)width;
  (void)height;
  (void)render_width;
  (void)render_height;
  return false;
#endif
}

void VulkanCommandProcessor::FgReleaseResources() {
  if (fg_context_) {
    FgContext& fg = *fg_context_;
    if (fg.thread.joinable()) {
      fg.thread.join();
    }
    if (fg.lsfg_context) {
      fg.lsfg_retired.emplace_back(GetCurrentSubmission(), fg.lsfg_context);
      fg.lsfg_context = nullptr;
    }
    fg.lsfg_frames = 0;
    fg.reset_next = true;
#if defined(REX_HAS_FSR) && REX_HAS_FSR
    if (fg.context) {
      fg.retired.emplace_back(GetCurrentSubmission(), fg.context);
      fg.context = nullptr;
    }
#endif
    fg.state.store(FgContext::kNone, std::memory_order_release);
    fg.width = fg.height = fg.render_width = fg.render_height = 0;
  }
  for (HdrImage* image : {&fg_hudless_, &fg_hudless_small_, &fg_generated_, &fg_depth_}) {
    if (image->image != VK_NULL_HANDLE) {
      // Destroyed once the submissions that may use them are done.
      destroy_image_views_.emplace_back(GetCurrentSubmission(), image->view);
      destroy_images_.emplace_back(GetCurrentSubmission(), image->image);
      destroy_memory_.emplace_back(GetCurrentSubmission(), image->memory);
      *image = HdrImage();
    }
  }
}

const char* VulkanCommandProcessor::FgUnavailableReason() {
  if (!fg_setup_tried_) {
    fg_setup_tried_ = true;
    fg_setup_ok_ = FgSetup();
  }
  if (!fg_setup_ok_) {
    return "its pipelines couldn't be created";
  }
  if (LsfgRequested()) {
    const auto& properties = GetVulkanDevice()->properties();
    const char* enabled = std::getenv("REX_MCLA_LSFG");
    if (!enabled || std::strcmp(enabled, "1") || !GetVulkanDevice()->frame_generation_supported() || !properties.nullDescriptor ||
        !properties.shaderStorageImageExtendedFormats)
      return "the device was created without LSFG features; restart required";
    if (fg_context_ && (fg_context_->given_up ||
        fg_context_->dispatch_failed.load(std::memory_order_acquire) ||
        fg_context_->state.load(std::memory_order_acquire) == FgContext::kFailed))
      return "the LSFG backend failed; real frames only";
    return nullptr;
  }
#if !(defined(REX_HAS_FSR) && REX_HAS_FSR)
  return "FidelityFX isn't built into this build";
#else
  if (!GetVulkanDevice()->temporal_aa_features()) {
    return "the device was created without the features FidelityFX needs";
  }
  if (taa_pipeline_failed_) {
    return "temporal anti-aliasing's pass, which makes its motion vectors, isn't available";
  }
  if (fg_context_) {
    if (fg_context_->given_up || fg_context_->dispatch_failed.load(std::memory_order_acquire)) {
      return "a generation failed on the GPU's queue";
    }
    if (fg_context_->state.load(std::memory_order_acquire) == FgContext::kFailed) {
      return "its context couldn't be created";
    }
  }
  return nullptr;
#endif
}

bool VulkanCommandProcessor::FgAvailable(
    ui::vulkan::VulkanPresenter::FrameGenerationInputs& inputs) {
  if (!fg_unavailable_reason_) {
    fg_unavailable_reason_ = FgUnavailableReason();
    if (fg_unavailable_reason_) {
      REXGPU_WARN("Frame generation can't run: {}", fg_unavailable_reason_);
      FgReleaseResources();
    }
  }
  if (!fg_unavailable_reason_) {
    return true;
  }
  inputs.unavailable_reason = fg_unavailable_reason_;
  return false;
}

void VulkanCommandProcessor::FgSkip() {
  if (!fg_context_) {
    return;
  }
  FgContext& fg = *fg_context_;
  fg.reset_next = true;
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  if (fg.context && ++fg.frames_without_generation >= 1200) {
    // Nothing to generate from for a while (menus, FXAA or the piecewise
    // linear ramp in SDR, or the presenter away): the context and the images go
    // until generation can run again.
    FgReleaseResources();
    fg.frames_without_generation = 0;
    REXGPU_INFO(
        "Frame generation: its context and images released (nothing to generate from "
        "for 1200 frames)");
  }
#endif
}

bool VulkanCommandProcessor::FgDispatchFailed() const {
  return fg_context_ && fg_context_->dispatch_failed.load(std::memory_order_acquire);
}

bool VulkanCommandProcessor::FgGenerateLsfg(
    ui::vulkan::VulkanPresenter::FrameGenerationInputs& inputs,
    uint32_t guest_output_width, uint32_t guest_output_height, VkDescriptorSet ramp_set) {
#if !REX_PLATFORM_ANDROID
  return false;
#else
  if (!fg_context_) fg_context_.reset(new FgContext());
  FgContext& fg = *fg_context_;
  if (fg.given_up || fg.dispatch_failed.load(std::memory_order_acquire)) return false;
  const uint32_t width = inputs.generation_width, height = inputs.generation_height;
  const auto state = fg.state.load(std::memory_order_acquire);
  if (state == FgContext::kCreating || state == FgContext::kFailed) return false;
  if (fg.lsfg_context && (fg.width != width || fg.height != height)) {
    FgReleaseResources();
    return false;
  }
  const ui::vulkan::VulkanDevice* const device = GetVulkanDevice();
  if (!fg.lsfg_context) {
    if (fg.thread.joinable()) fg.thread.join();
    if (!fg.lsfg_module) {
      fg.lsfg_module = dlopen("libmcla_lsfg.so", RTLD_NOW | RTLD_LOCAL);
      if (fg.lsfg_module) {
        fg.lsfg_create = reinterpret_cast<decltype(fg.lsfg_create)>(dlsym(fg.lsfg_module, "mcla_lsfg_create"));
        fg.lsfg_record = reinterpret_cast<decltype(fg.lsfg_record)>(dlsym(fg.lsfg_module, "mcla_lsfg_record"));
        fg.lsfg_destroy = reinterpret_cast<decltype(fg.lsfg_destroy)>(dlsym(fg.lsfg_module, "mcla_lsfg_destroy"));
      }
    }
    const char* path = std::getenv("REX_MCLA_LSFG_DLL");
    if (!fg.lsfg_create || !fg.lsfg_record || !fg.lsfg_destroy || !path || !*path) {
      REXGPU_ERROR("LSFG: optional backend or user DLL path missing; real frames only");
      fg.state.store(FgContext::kFailed, std::memory_order_release);
      return false;
    }
    MclaLsfgDevice description{};
    description.abi_version = MCLA_LSFG_ABI_VERSION;
    description.instance = device->vulkan_instance()->instance();
    description.physical_device = device->physical_device();
    description.device = device->device();
    description.queue_family = device->queue_family_graphics_compute();
    device->functions().vkGetDeviceQueue(description.device, description.queue_family, 0, &description.queue);
    description.get_instance_proc_addr = device->vulkan_instance()->functions().vkGetInstanceProcAddr;
    description.enabled_features = MCLA_LSFG_REQUIRED_FEATURES;
    description.width = width;
    description.height = height;
    const std::string dll_path(path);
    fg.width = width;
    fg.height = height;
    fg.reset_next = true;
    fg.lsfg_frames = 0;
    fg.state.store(FgContext::kCreating, std::memory_order_release);
    fg.thread = std::thread([&fg, description, dll_path]() mutable {
      description.dll_path = dll_path.c_str();
      char error[512] = {};
      fg.lsfg_context = fg.lsfg_create(&description, error, sizeof(error));
      if (fg.lsfg_context) {
        REXGPU_INFO("LSFG: SDR 2x context ready {}x{}; three cold frames suppressed", description.width, description.height);
        fg.state.store(FgContext::kReady, std::memory_order_release);
      } else {
        REXGPU_ERROR("LSFG context creation failed: {}", error);
        fg.state.store(FgContext::kFailed, std::memory_order_release);
      }
    });
    return false;
  }
  if (inputs.generated_image == VK_NULL_HANDLE ||
      !FgEnsureImage(fg_generated_, width, height, VK_FORMAT_R16G16B16A16_SFLOAT)) return false;
  const bool downscaled = width != guest_output_width || height != guest_output_height;
  const HdrImage& hudless = downscaled ? fg_hudless_small_ : fg_hudless_;
  if (hudless.image == VK_NULL_HANDLE) return false;
  HdrTransitionImage(fg_generated_, VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  if (fg.reset_next) fg.lsfg_frames = 0;
  LsfgDispatch dispatch{};
  dispatch.record = fg.lsfg_record;
  dispatch.context = fg.lsfg_context;
  dispatch.failed = &fg.dispatch_failed;
  dispatch.frame.source = hudless.image;
  dispatch.frame.destination = fg_generated_.image;
  dispatch.frame.source_layout = hudless.layout;
  dispatch.frame.destination_layout = VK_IMAGE_LAYOUT_GENERAL;
  dispatch.frame.source_format = dispatch.frame.destination_format = VK_FORMAT_R16G16B16A16_SFLOAT;
  dispatch.frame.submission = GetCurrentSubmission();
  dispatch.frame.reset_history = fg.reset_next;
  dispatch.expected_ready = fg.lsfg_frames++ >= 3;
  deferred_command_buffer_.CmdExternalCallback(LsfgDispatchCallback, &dispatch, sizeof(dispatch));
  current_external_compute_pipeline_ = VK_NULL_HANDLE;
  current_guest_graphics_pipeline_ = VK_NULL_HANDLE;
  current_external_graphics_pipeline_ = VK_NULL_HANDLE;
  current_graphics_descriptor_sets_bound_up_to_date_ = 0;
  fg.reset_next = false;
  if (!dispatch.expected_ready) {
    inputs.generated = false;
    return true;  // Keep warming history; do not call FgSkip and reset it again.
  }
  VkMemoryBarrier memory = {VK_STRUCTURE_TYPE_MEMORY_BARRIER, nullptr,
                            VK_ACCESS_MEMORY_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT};
  deferred_command_buffer_.CmdVkPipelineBarrier(VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
      VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1, &memory, 0, nullptr, 0, nullptr);
  const VkImageSubresourceRange range = ui::vulkan::util::InitializeSubresourceRange();
  PushImageMemoryBarrier(inputs.generated_image, range,
      inputs.generated_ever_written ? ui::vulkan::VulkanPresenter::kGuestOutputInternalStageMask : VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
      VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
      inputs.generated_ever_written ? ui::vulkan::VulkanPresenter::kGuestOutputInternalAccessMask : 0,
      VK_ACCESS_SHADER_WRITE_BIT, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  const FgFrameSets& sets = fg_sets_[frame_current_ % kMaxFramesInFlight];
  const HdrImage& ui_layer = hdr_images_[kHdrTextureUiLayer];
  const VkImageView ui_view = ui_layer.view != VK_NULL_HANDLE ? ui_layer.view : fg_generated_.view;
  const VkImageLayout ui_layout = ui_layer.view != VK_NULL_HANDLE ? ui_layer.layout : VK_IMAGE_LAYOUT_GENERAL;
  FgWriteImageSet(sets.compose_source, ui_view, VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, ui_layout);
  FgWriteImageSet(sets.compose_dest, inputs.generated_view, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, VK_IMAGE_LAYOUT_GENERAL);
  FgWriteImageSet(sets.compose_hudless, fg_dummy_.view, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE, VK_IMAGE_LAYOUT_GENERAL);
  VkDescriptorImageInfo image_infos[4];
  for (auto& info : image_infos) info = {VK_NULL_HANDLE, ui_view, ui_layout};
  image_infos[2] = {VK_NULL_HANDLE, fg_generated_.view, VK_IMAGE_LAYOUT_GENERAL};
  VkWriteDescriptorSet write = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
  write.dstSet = sets.compose_images;
  write.descriptorCount = 4;
  write.descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
  write.pImageInfo = image_infos;
  device->functions().vkUpdateDescriptorSets(device->device(), 1, &write, 0, nullptr);
  BindExternalComputePipeline(hdr_refresh_fg_pipeline_);
  const VkDescriptorSet descriptors[] = {ramp_set, sets.compose_source, sets.compose_dest,
                                        sets.compose_images, sets.compose_hudless};
  deferred_command_buffer_.CmdVkBindDescriptorSets(VK_PIPELINE_BIND_POINT_COMPUTE,
      hdr_refresh_fg_pipeline_layout_, 0, uint32_t(std::size(descriptors)), descriptors, 0, nullptr);
  deferred_command_buffer_.CmdVkPushConstants(hdr_refresh_fg_pipeline_layout_, VK_SHADER_STAGE_COMPUTE_BIT,
      0, sizeof(fg_compose_constants_), &fg_compose_constants_);
  deferred_command_buffer_.CmdVkDispatch((width + 15) / 16, (height + 7) / 8, 1);
  PushImageMemoryBarrier(inputs.generated_image, range, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
      ui::vulkan::VulkanPresenter::kGuestOutputInternalStageMask, VK_ACCESS_SHADER_WRITE_BIT,
      ui::vulkan::VulkanPresenter::kGuestOutputInternalAccessMask, VK_IMAGE_LAYOUT_GENERAL,
      ui::vulkan::VulkanPresenter::kGuestOutputInternalLayout);
  SubmitBarriers(true);
  inputs.generated = true;
  if ((fg.lsfg_frames % 300) == 0) REXGPU_INFO("LSFG: {} guest frames processed; generated frames handed to existing pacer", fg.lsfg_frames);
  return true;
#endif
}

bool VulkanCommandProcessor::FgGenerate(ui::vulkan::VulkanPresenter::FrameGenerationInputs& inputs,
                                         uint32_t guest_output_width,
                                         uint32_t guest_output_height, VkDescriptorSet ramp_set) {
  if (LsfgRequested())
    return FgGenerateLsfg(inputs, guest_output_width, guest_output_height, ramp_set);
#if defined(REX_HAS_FSR) && REX_HAS_FSR
  if (!fg_context_) {
    fg_context_.reset(new FgContext());
  }
  FgContext& fg = *fg_context_;
  if (fg.given_up) {
    return false;
  }
  if (fg.dispatch_failed.load(std::memory_order_acquire)) {
    // Not again in this session.
    fg.given_up = true;
    if (fg.thread.joinable()) {
      fg.thread.join();
    }
    if (fg.context) {
      fg.retired.emplace_back(GetCurrentSubmission(), fg.context);
      fg.context = nullptr;
    }
    fg.state.store(FgContext::kFailed, std::memory_order_release);
    return false;
  }
  const uint32_t generation_width = inputs.generation_width;
  const uint32_t generation_height = inputs.generation_height;
  VkImage vectors = TaaFrameVectors();
  if (vectors == VK_NULL_HANDLE || fg_depth_.image == VK_NULL_HANDLE ||
      fg_depth_frame_ != frame_current_ || inputs.generated_image == VK_NULL_HANDLE) {
    // (The refresher calls FgSkip for the frame.)
    return false;
  }
  const uint32_t render_width = fg_depth_.width;
  const uint32_t render_height = fg_depth_.height;
  if (!FgEnsureContext(generation_width, generation_height, render_width, render_height) ||
      !FgEnsureImage(fg_generated_, generation_width, generation_height,
                     VK_FORMAT_R16G16B16A16_SFLOAT)) {
    return false;
  }
  fg.frames_without_generation = 0;
  const ui::vulkan::VulkanDevice* const vulkan_device = GetVulkanDevice();

  // frame_generation_timing (development).
  uint32_t timer_slot = UINT32_MAX;
  // (The presenter's cvars, from the runtime's registry.)
  if (REXCVAR_QUERY(bool, frame_generation_timing)) {
    if (fg.timer_pool == VK_NULL_HANDLE) {
      const ui::vulkan::VulkanInstance* instance = vulkan_device->vulkan_instance();
      auto get_device_proc_addr = reinterpret_cast<PFN_vkGetDeviceProcAddr>(
          instance->functions().vkGetInstanceProcAddr(instance->instance(),
                                                      "vkGetDeviceProcAddr"));
      VkPhysicalDeviceProperties properties;
      instance->functions().vkGetPhysicalDeviceProperties(vulkan_device->physical_device(),
                                                          &properties);
      if (get_device_proc_addr && properties.limits.timestampPeriod > 0.0f) {
        fg.write_timestamp = reinterpret_cast<PFN_vkCmdWriteTimestamp>(
            get_device_proc_addr(vulkan_device->device(), "vkCmdWriteTimestamp"));
        fg.get_results = reinterpret_cast<PFN_vkGetQueryPoolResults>(
            get_device_proc_addr(vulkan_device->device(), "vkGetQueryPoolResults"));
        VkQueryPoolCreateInfo pool_info = {VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
        pool_info.queryType = VK_QUERY_TYPE_TIMESTAMP;
        pool_info.queryCount = 2 * FgContext::kTimerSlots;
        if (fg.write_timestamp && fg.get_results &&
            vulkan_device->functions().vkCreateQueryPool(vulkan_device->device(), &pool_info,
                                                         nullptr,
                                                         &fg.timer_pool) == VK_SUCCESS) {
          fg.timer_tick_ms = double(properties.limits.timestampPeriod) * 1e-6;
        } else {
          fg.timer_pool = VK_NULL_HANDLE;
        }
      }
    }
    if (fg.timer_pool != VK_NULL_HANDLE) {
      for (uint32_t slot = 0; slot < FgContext::kTimerSlots; ++slot) {
        if (!fg.timer_submission[slot] || fg.timer_submission[slot] > GetCompletedSubmission()) {
          continue;
        }
        fg.timer_submission[slot] = 0;
        uint64_t ticks[2];
        if (fg.get_results(vulkan_device->device(), fg.timer_pool, slot * 2, 2, sizeof(ticks),
                           ticks, sizeof(uint64_t), VK_QUERY_RESULT_64_BIT) == VK_SUCCESS &&
            ticks[1] > ticks[0]) {
          fg.timer_ms += double(ticks[1] - ticks[0]) * fg.timer_tick_ms;
          if (++fg.timer_count >= 300) {
            REXGPU_INFO("Frame generation: {:.3f} ms of GPU time per generated frame (its "
                        "preparation, generation and compose, {}x{}, average of {})",
                        fg.timer_ms / fg.timer_count, generation_width, generation_height,
                        fg.timer_count);
            fg.timer_ms = 0.0;
            fg.timer_count = 0;
          }
        }
      }
      if (!fg.timer_submission[fg.timer_next]) {
        timer_slot = fg.timer_next;
        fg.timer_next = (timer_slot + 1) % FgContext::kTimerSlots;
      }
    }
  }
  if (timer_slot != UINT32_MAX) {
    deferred_command_buffer_.CmdVkResetQueryPool(fg.timer_pool, timer_slot * 2, 2);
    FgTimestamp timestamp = {fg.write_timestamp, fg.timer_pool, timer_slot * 2,
                             VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT};
    deferred_command_buffer_.CmdExternalCallback(FgTimestampCallback, &timestamp,
                                                 sizeof(timestamp));
  }

  // Generation: after the HUD-less image's writes (made visible to compute
  // reads by its transition) and the previous compose's reads of the generated
  // image (this barrier), FidelityFX transitions its inputs itself, from the
  // states given, and back.
  HdrTransitionImage(fg_generated_, VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  const bool downscaled = generation_width != guest_output_width ||
                          generation_height != guest_output_height;
  const HdrImage& hudless = downscaled ? fg_hudless_small_ : fg_hudless_;
  FgDispatch dispatch = {};
  dispatch.configure = fg.runtime.configure;
  dispatch.dispatch = fg.runtime.dispatch;
  dispatch.context = fg.context;
  dispatch.failed = &fg.dispatch_failed;
  dispatch.force_failure = REXCVAR_QUERY(int32_t, frame_generation_debug_fail) == 2;
  // Development views.
  const int32_t debug = REXCVAR_QUERY(int32_t, frame_generation_debug);
  dispatch.configure_flags = FFX_FRAMEGENERATION_FLAG_NO_SWAPCHAIN_CONTEXT_NOTIFY |
                             (debug == 1   ? FFX_FRAMEGENERATION_FLAG_DRAW_DEBUG_TEAR_LINES
                              : debug == 2 ? FFX_FRAMEGENERATION_FLAG_DRAW_DEBUG_VIEW
                                           : 0);
  ffxDispatchDescFrameGenerationPrepare& prepare = dispatch.prepare;
  prepare.header.type = FFX_API_DISPATCH_DESC_TYPE_FRAMEGENERATION_PREPARE;
  prepare.frameID = fg.next_frame_id;
  prepare.renderSize = {render_width, render_height};
  float jitter[2];
  TaaFsrJitter(jitter);
  prepare.jitterOffset = {jitter[0], jitter[1]};
  prepare.motionVectorScale = {1.0f, 1.0f};
  prepare.frameTimeDelta = taa_frame_time_ms_;
  prepare.cameraNear = taa_camera_.near_plane;
  prepare.cameraFar = taa_camera_.far_plane;
  prepare.cameraFovAngleVertical = taa_camera_.fov_vertical;
  prepare.viewSpaceToMetersFactor = 1.0f;
  prepare.depth = FgResource(fg_depth_.image, VK_FORMAT_R32_SFLOAT, render_width, render_height,
                             VK_IMAGE_USAGE_SAMPLED_BIT, FFX_API_RESOURCE_STATE_COMPUTE_READ);
  prepare.motionVectors =
      FgResource(vectors, VK_FORMAT_R16G16_SFLOAT, render_width, render_height,
                 VK_IMAGE_USAGE_SAMPLED_BIT, FFX_API_RESOURCE_STATE_COMPUTE_READ);
  ffxDispatchDescFrameGeneration& generate = dispatch.generate;
  generate.header.type = FFX_API_DISPATCH_DESC_TYPE_FRAMEGENERATION;
  generate.presentColor =
      FgResource(hudless.image, VK_FORMAT_R16G16B16A16_SFLOAT, generation_width, generation_height,
                 VK_IMAGE_USAGE_SAMPLED_BIT, FFX_API_RESOURCE_STATE_COMPUTE_READ);
  generate.outputs[0] =
      FgResource(fg_generated_.image, VK_FORMAT_R16G16B16A16_SFLOAT, generation_width,
                 generation_height, VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_STORAGE_BIT,
                 FFX_API_RESOURCE_STATE_UNORDERED_ACCESS);
  generate.numGeneratedFrames = 1;
  generate.reset = fg.reset_next || taa_camera_.reset;
  // Code values: the transfer function only steers its luminance heuristics.
  generate.backbufferTransferFunction = FFX_API_BACKBUFFER_TRANSFER_FUNCTION_SRGB;
  generate.minMaxLuminance[0] = 0.0f;
  generate.minMaxLuminance[1] = 1.0f;
  generate.generationRect = {0, 0, int32_t(generation_width), int32_t(generation_height)};
  generate.frameID = fg.next_frame_id;
  deferred_command_buffer_.CmdExternalCallback(FgDispatchCallback, &dispatch, sizeof(dispatch));
  // FidelityFX bound its own compute pipelines and descriptor sets.
  current_external_compute_pipeline_ = VK_NULL_HANDLE;
  current_guest_graphics_pipeline_ = VK_NULL_HANDLE;
  current_external_graphics_pipeline_ = VK_NULL_HANDLE;
  current_graphics_descriptor_sets_bound_up_to_date_ = 0;
  ++fg.next_frame_id;
  fg.reset_next = false;

  // The compose: hdr_refresh_fg.cs from the generated code values (bit 12)
  // with this frame's UI layer, into the presenter's image at the generation
  // size (written whole).
  VkMemoryBarrier generated_barrier = {VK_STRUCTURE_TYPE_MEMORY_BARRIER, nullptr,
                                       VK_ACCESS_SHADER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT};
  deferred_command_buffer_.CmdVkPipelineBarrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1,
                                                &generated_barrier, 0, nullptr, 0, nullptr);
  const VkImageSubresourceRange range = ui::vulkan::util::InitializeSubresourceRange();
  PushImageMemoryBarrier(inputs.generated_image, range,
                         inputs.generated_ever_written
                             ? ui::vulkan::VulkanPresenter::kGuestOutputInternalStageMask
                             : VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                         VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                         inputs.generated_ever_written
                             ? ui::vulkan::VulkanPresenter::kGuestOutputInternalAccessMask
                             : 0,
                         VK_ACCESS_SHADER_WRITE_BIT, VK_IMAGE_LAYOUT_UNDEFINED,
                         VK_IMAGE_LAYOUT_GENERAL);
  SubmitBarriers(true);
  const FgFrameSets& sets = fg_sets_[frame_current_ % kMaxFramesInFlight];
  // The UI layer as the refresher read it; the generated image where the scene
  // is read (t4), the UI layer in the unused places.
  const HdrImage& ui_layer = hdr_images_[kHdrTextureUiLayer];
  VkImageView ui_view = ui_layer.view;
  VkImageLayout ui_image_layout = ui_layer.layout;
  if (ui_view == VK_NULL_HANDLE) {
    ui_view = fg_generated_.view;
    ui_image_layout = VK_IMAGE_LAYOUT_GENERAL;
  }
  FgWriteImageSet(sets.compose_source, ui_view, VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,
                  ui_image_layout);
  FgWriteImageSet(sets.compose_dest, inputs.generated_view, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                  VK_IMAGE_LAYOUT_GENERAL);
  FgWriteImageSet(sets.compose_hudless, fg_dummy_.view, VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                  VK_IMAGE_LAYOUT_GENERAL);
  {
    VkDescriptorImageInfo image_infos[4];
    for (uint32_t i = 0; i < 4; ++i) {
      image_infos[i] = {VK_NULL_HANDLE, ui_view, ui_image_layout};
    }
    image_infos[2] = {VK_NULL_HANDLE, fg_generated_.view, VK_IMAGE_LAYOUT_GENERAL};
    VkWriteDescriptorSet write = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
    write.dstSet = sets.compose_images;
    write.descriptorCount = 4;
    write.descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
    write.pImageInfo = image_infos;
    vulkan_device->functions().vkUpdateDescriptorSets(vulkan_device->device(), 1, &write, 0,
                                                       nullptr);
  }
  BindExternalComputePipeline(hdr_refresh_fg_pipeline_);
  const VkDescriptorSet descriptor_sets[] = {ramp_set, sets.compose_source, sets.compose_dest,
                                             sets.compose_images, sets.compose_hudless};
  deferred_command_buffer_.CmdVkBindDescriptorSets(
      VK_PIPELINE_BIND_POINT_COMPUTE, hdr_refresh_fg_pipeline_layout_, 0,
      uint32_t(std::size(descriptor_sets)), descriptor_sets, 0, nullptr);
  deferred_command_buffer_.CmdVkPushConstants(hdr_refresh_fg_pipeline_layout_,
                                              VK_SHADER_STAGE_COMPUTE_BIT, 0,
                                              sizeof(fg_compose_constants_),
                                              &fg_compose_constants_);
  deferred_command_buffer_.CmdVkDispatch((generation_width + 15) / 16,
                                         (generation_height + 7) / 8, 1);
  PushImageMemoryBarrier(inputs.generated_image, range, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                         ui::vulkan::VulkanPresenter::kGuestOutputInternalStageMask,
                         VK_ACCESS_SHADER_WRITE_BIT,
                         ui::vulkan::VulkanPresenter::kGuestOutputInternalAccessMask,
                         VK_IMAGE_LAYOUT_GENERAL,
                         ui::vulkan::VulkanPresenter::kGuestOutputInternalLayout);
  SubmitBarriers(true);
  if (timer_slot != UINT32_MAX) {
    FgTimestamp timestamp = {fg.write_timestamp, fg.timer_pool, timer_slot * 2 + 1,
                             VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT};
    deferred_command_buffer_.CmdExternalCallback(FgTimestampCallback, &timestamp,
                                                 sizeof(timestamp));
    fg.timer_submission[timer_slot] = GetCurrentSubmission();
  }
  inputs.generated = true;
  return true;
#else
  (void)inputs;
  (void)guest_output_width;
  (void)guest_output_height;
  (void)ramp_set;
  return false;
#endif
}

}  // namespace rex::graphics::vulkan
