/**
 * Temporal anti-aliasing (rexglue-temporal-aa.patch), where FidelityFX is
 * linked statically (REX_FSR_STATIC: the PS5, which can't load modules and has
 * no Vulkan loader, its driver being linked in as an ICD).
 *
 * FidelityFX's Vulkan backend gets its device functions through the
 * vkGetDeviceProcAddr it is given, but refers to eight directly, as exported by
 * a loader (ffx_vk.cpp at the pinned commit): these are those, forwarded to the
 * instance and device the GPU plugin created (one of each). ps5/make_ps5.sh
 * checks that nothing else is left undefined.
 */

#if defined(REX_FSR_STATIC) && REX_FSR_STATIC

#include <atomic>

#include <rex/ui/vulkan/device.h>
#include <rex/ui/vulkan/instance.h>

namespace rex::graphics::vulkan {

namespace {
std::atomic<const ui::vulkan::VulkanInstance::Functions*> taa_static_ifn{nullptr};
std::atomic<const ui::vulkan::VulkanDevice::Functions*> taa_static_dfn{nullptr};
}  // namespace

// Before FSR's context is created (VulkanCommandProcessor::TaaRun).
void TaaSetStaticVulkanFunctions(const ui::vulkan::VulkanInstance::Functions* ifn,
                                 const ui::vulkan::VulkanDevice::Functions* dfn) {
  taa_static_ifn.store(ifn, std::memory_order_release);
  taa_static_dfn.store(dfn, std::memory_order_release);
}

}  // namespace rex::graphics::vulkan

using rex::graphics::vulkan::taa_static_dfn;
using rex::graphics::vulkan::taa_static_ifn;

extern "C" {

VKAPI_ATTR VkResult VKAPI_CALL vkEnumerateDeviceExtensionProperties(
    VkPhysicalDevice physical_device, const char* layer_name, uint32_t* count,
    VkExtensionProperties* properties) {
  return taa_static_ifn.load(std::memory_order_acquire)
      ->vkEnumerateDeviceExtensionProperties(physical_device, layer_name, count, properties);
}

VKAPI_ATTR void VKAPI_CALL vkGetPhysicalDeviceFeatures(VkPhysicalDevice physical_device,
                                                       VkPhysicalDeviceFeatures* features) {
  taa_static_ifn.load(std::memory_order_acquire)
      ->vkGetPhysicalDeviceFeatures(physical_device, features);
}

VKAPI_ATTR void VKAPI_CALL vkGetPhysicalDeviceFeatures2(VkPhysicalDevice physical_device,
                                                        VkPhysicalDeviceFeatures2* features) {
  taa_static_ifn.load(std::memory_order_acquire)
      ->vkGetPhysicalDeviceFeatures2(physical_device, features);
}

VKAPI_ATTR void VKAPI_CALL vkGetPhysicalDeviceMemoryProperties(
    VkPhysicalDevice physical_device, VkPhysicalDeviceMemoryProperties* properties) {
  taa_static_ifn.load(std::memory_order_acquire)
      ->vkGetPhysicalDeviceMemoryProperties(physical_device, properties);
}

VKAPI_ATTR void VKAPI_CALL vkGetPhysicalDeviceProperties(VkPhysicalDevice physical_device,
                                                         VkPhysicalDeviceProperties* properties) {
  taa_static_ifn.load(std::memory_order_acquire)
      ->vkGetPhysicalDeviceProperties(physical_device, properties);
}

VKAPI_ATTR void VKAPI_CALL vkGetPhysicalDeviceProperties2(
    VkPhysicalDevice physical_device, VkPhysicalDeviceProperties2* properties) {
  taa_static_ifn.load(std::memory_order_acquire)
      ->vkGetPhysicalDeviceProperties2(physical_device, properties);
}

// Only its address is taken (a fallback for the vkGetDeviceProcAddr FidelityFX
// is given), but the link needs it all the same.
VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL vkGetDeviceProcAddr(VkDevice device, const char* name) {
  return taa_static_ifn.load(std::memory_order_acquire)->vkGetDeviceProcAddr(device, name);
}

VKAPI_ATTR VkResult VKAPI_CALL vkCreateBuffer(VkDevice device, const VkBufferCreateInfo* info,
                                              const VkAllocationCallbacks* allocator,
                                              VkBuffer* buffer) {
  return taa_static_dfn.load(std::memory_order_acquire)
      ->vkCreateBuffer(device, info, allocator, buffer);
}

}  // extern "C"

#endif  // REX_FSR_STATIC
