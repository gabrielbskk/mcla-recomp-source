/**
 * Temporal anti-aliasing (rexglue-temporal-aa.patch): the AMD FSR 3.1 runtime
 * (FidelityFX SDK 1.1.4 ffx-api, MIT, built from source by
 * cmake/rexglue_fsr.cmake), loaded at run time from the executable's folder.
 */

#pragma once

#if defined(REX_HAS_FSR) && REX_HAS_FSR

#include <ffx_api/ffx_api.h>
#include <ffx_api/ffx_upscale.h>

namespace rex::graphics {

// What both backends create FSR with. The prebuilt Vulkan shaders are made for
// these (launcher/dev/fsr/fsr_vk_shaders.py reads them here).
constexpr uint32_t kTaaFsrCreateFlags = FFX_UPSCALE_ENABLE_HIGH_DYNAMIC_RANGE |
                                        FFX_UPSCALE_ENABLE_DEPTH_INVERTED |
                                        FFX_UPSCALE_ENABLE_AUTO_EXPOSURE;

struct FsrRuntime {
  PfnFfxCreateContext create = nullptr;
  PfnFfxDestroyContext destroy = nullptr;
  PfnFfxConfigure configure = nullptr;
  PfnFfxQuery query = nullptr;
  PfnFfxDispatch dispatch = nullptr;
  // Loads amd_fidelityfx_<api> (dx12 or vk) the first time; false (logged
  // once) if it isn't there.
  bool Load(const char* api);
  // Logs FidelityFX's messages.
  static void Message(uint32_t type, const wchar_t* message);
#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
  // Whether FidelityFX is linked into the executable.
  static bool Linked();
#endif

 private:
  bool tried_ = false;
  void* library_ = nullptr;
};

}  // namespace rex::graphics

#endif  // REX_HAS_FSR
