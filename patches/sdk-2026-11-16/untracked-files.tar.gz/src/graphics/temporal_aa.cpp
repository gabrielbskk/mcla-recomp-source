/**
 * Temporal anti-aliasing (rexglue-temporal-aa.patch): the backend-independent
 * part, see CommandProcessor::TaaFrame in command_processor.h.
 *
 * The jitter is FSR's: Halton(2, 3), 8 phases at native resolution, in host
 * pixels with +y down; a draw is moved by it through its NDC offset (the host
 * viewport's: +y up on Direct3D 12, down on Vulkan).
 *
 * Midnight Club: Los Angeles's anti-aliasing point is its motion blur
 * (pixel shader A6B9B6B0FA692C54, once in every frame that has a 3D scene,
 * after the scene and before the tone map), which samples the scene (fetch 0,
 * 16_16_16_16_EXPAND), the stencil view of the depth resolve (fetch 1,
 * 8_8_8_8; the vehicle ID in x >> 2), the depth (fetch 2, 24_8_FLOAT, 1 near,
 * 0 far) and has in its constants c4-c7 the view, c8-c11 the view-projection
 * (row vectors), c12-c15 the view's inverse (c15 the camera's position),
 * c62 the frame's size and c69 + 4k to c72 + 4k (k < 24) the previous frame's
 * view-projection to pixels, for k > 0 with vehicle k's own motion folded in
 * (launcher/dev/frame-structure-2026-10-16.md and the M3 design).
 */

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>

#include <rex/chrono/clock.h>
#include <rex/cvar.h>
#include <rex/graphics/command_processor.h>
#include <rex/graphics/registers.h>
#include <rex/graphics/pipeline/shader/shader.h>
#include <rex/graphics/xenos.h>
#include <rex/logging.h>

REXCVAR_DEFINE_STRING(temporal_aa, "off", "GPU",
                      "Temporal anti-aliasing (rexglue-temporal-aa.patch):\n"
                      " off: none (the default)\n"
                      " fsr: AMD FSR 3.1 at native resolution (Native AA)")
    .allowed({"off", "fsr"})
    .lifecycle(rex::cvar::Lifecycle::kHotReload)
    // The game sets it from its own setting (mcla_anti_aliasing) while running: not saved, and
    // a line for it in a config file is ignored.
    .transient();
REXCVAR_DEFINE_STRING(temporal_aa_available, "unknown", "GPU",
                      "Temporal anti-aliasing, set by the GPU plugin when the first frame ends: "
                      "whether FSR can run with this graphics API and device (yes: its runtime "
                      "is there and it hasn't failed; next_start: after a restart, the device "
                      "having been created without the features it uses; no; unknown before)")
    .allowed({"unknown", "yes", "next_start", "no"})
    .lifecycle(rex::cvar::Lifecycle::kHotReload)
    .transient();
REXCVAR_DEFINE_DOUBLE(temporal_aa_sharpness, 0.2, "GPU",
                      "Temporal anti-aliasing: sharpening after FSR (RCAS), 0 (off) to 1")
    .range(0.0, 1.0)
    .lifecycle(rex::cvar::Lifecycle::kHotReload);
REXCVAR_DEFINE_UINT32(temporal_aa_debug, 0, "GPU",
                      "Temporal anti-aliasing, development: 1 FSR's debug view, 2 no jitter, "
                      "3 jitter without the anti-aliasing (the raw input), 4 log every 120 frames "
                      "the jitter gate's counts, how far the pass got and its GPU time, 5 the "
                      "reactive mask (red over the scene), 6 the motion vectors (hue: direction, "
                      "brightness: length, full at 16 pixels), 7 FSR upscaling: log what the "
                      "scene's draws and resolves do, 8 FSR upscaling: FSR is given the full-size scene texture "
                      "in place of the gathered colour (a check of the gather), 9 the gathered colour is "
                      "put in the corner of the scene texture instead of FSR's output, 10 the camera's "
                      "near and far planes given to FSR the other way round (FSR's inverted-depth "
                      "check wants near > far; a picture that differs from 0 means the order matters)")
    .range(0, 10)
    .lifecycle(rex::cvar::Lifecycle::kHotReload);
REXCVAR_DEFINE_UINT32(temporal_aa_flip_jitter, 0, "GPU",
                      "Temporal anti-aliasing, development: the jitter FSR is told, x (1) and y (2) "
                      "flipped, for checking the convention (a still picture is sharpest unflipped)")
    .range(0, 3)
    .lifecycle(rex::cvar::Lifecycle::kHotReload);
REXCVAR_DEFINE_DOUBLE(temporal_aa_reactive, 0.0, "GPU",
                      "Temporal anti-aliasing, experimental: how strongly the scene's translucent "
                      "effects (rain, smoke, particles) make FSR lean on the current frame, the "
                      "reactive mask's scale on their relative change of luminance (4 is a "
                      "start); 0, the default: no reactive mask")
    .range(0.0, 100.0)
    .lifecycle(rex::cvar::Lifecycle::kHotReload);
REXCVAR_DEFINE_DOUBLE(temporal_aa_cut_distance, 25.0, "GPU",
                      "Temporal anti-aliasing: a camera move longer than this (game units) in "
                      "one frame is a cut, and FSR's history is dropped")
    .range(0.0, 10000.0)
    .lifecycle(rex::cvar::Lifecycle::kHotReload);
REXCVAR_DEFINE_DOUBLE(temporal_aa_upscale, 1.0, "GPU",
                      "FSR upscaling (rexglue-fsr-upscaling.patch), with temporal_aa = fsr: the "
                      "ratio of the output to the size the 3D scene is drawn at (4/3 Ultra "
                      "Quality, 1.5 Quality, 1.7 Balanced, 2 Performance, 3 Ultra Performance); "
                      "1, the default: the scene is drawn at the output size (FSR native AA). "
                      "The size is the output's over the ratio, rounded: 1920x1080 for a "
                      "2560x1440 output at 4/3. Post-processing and the HUD stay at the output "
                      "size.")
    .range(1.0, 3.0)
    .lifecycle(rex::cvar::Lifecycle::kHotReload)
    // The game sets it from its own setting, like temporal_aa.
    .transient();
REXCVAR_DEFINE_STRING(temporal_aa_upscale_available, "unknown", "GPU",
                      "FSR upscaling, set by the GPU plugin when the first frame ends: whether "
                      "the scene can be drawn smaller here (yes), or not (no: render targets "
                      "emulated with rasterizer-ordered views, or it gave up after a resolve it "
                      "couldn't handle)")
    .allowed({"unknown", "yes", "no"})
    .lifecycle(rex::cvar::Lifecycle::kHotReload)
    .transient();

namespace rex::graphics {

namespace {

constexpr uint64_t kTaaMotionBlurPixelShader = 0xA6B9B6B0FA692C54;
// FSR's phase count at native resolution (8 x the scale squared; ffxFsr3GetJitterPhaseCount).
constexpr uint32_t kTaaJitterPhases = 8;

float TaaHalton(uint32_t index, uint32_t base) {
  float f = 1.0f, result = 0.0f;
  for (uint32_t i = index; i; i /= base) {
    f /= float(base);
    result += f * float(i % base);
  }
  return result;
}

// 4x4 row-major, row vectors (v' = v M).
using Mat4 = double[4][4];
void TaaMul(const Mat4 a, const Mat4 b, Mat4 out) {
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      double sum = 0.0;
      for (int k = 0; k < 4; ++k) {
        sum += a[i][k] * b[k][j];
      }
      out[i][j] = sum;
    }
  }
}
bool TaaInverse(const Mat4 m, Mat4 out) {
  double a[4][8];
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      a[i][j] = m[i][j];
      a[i][4 + j] = i == j ? 1.0 : 0.0;
    }
  }
  for (int c = 0; c < 4; ++c) {
    int pivot = c;
    for (int r = c + 1; r < 4; ++r) {
      if (std::abs(a[r][c]) > std::abs(a[pivot][c])) {
        pivot = r;
      }
    }
    if (!(std::abs(a[pivot][c]) > 1e-30)) {
      return false;
    }
    if (pivot != c) {
      for (int j = 0; j < 8; ++j) {
        std::swap(a[c][j], a[pivot][j]);
      }
    }
    double inv = 1.0 / a[c][c];
    for (int j = 0; j < 8; ++j) {
      a[c][j] *= inv;
    }
    for (int r = 0; r < 4; ++r) {
      if (r != c && a[r][c] != 0.0) {
        double f = a[r][c];
        for (int j = 0; j < 8; ++j) {
          a[r][j] -= f * a[c][j];
        }
      }
    }
  }
  for (int i = 0; i < 4; ++i) {
    for (int j = 0; j < 4; ++j) {
      out[i][j] = a[i][4 + j];
      if (!std::isfinite(out[i][j])) {
        return false;
      }
    }
  }
  return true;
}

}  // namespace

float CommandProcessor::TaaSharpness() {
  return float(std::clamp(REXCVAR_GET(temporal_aa_sharpness), 0.0, 1.0));
}

uint32_t CommandProcessor::TaaDebug() {
  return REXCVAR_GET(temporal_aa_debug);
}

void CommandProcessor::TaaReactiveCurve(float curve_out[4]) {
  // Changes below 3% (noise, the fog's edges) aren't reactive; at most 0.9,
  // as AMD recommends.
  curve_out[0] = float(REXCVAR_GET(temporal_aa_reactive));
  curve_out[1] = 0.03f;
  curve_out[2] = 0.9f;
  curve_out[3] = 0.0f;
}

void CommandProcessor::TaaSceneMarker(uint32_t slot) {
  // In the scene of a jittered frame (the pass ran in the one before, so FSR
  // is ready); replayed per tile in a tiled scene, where the snapshots would
  // be of one tile, so only the first is taken.
  // (Not with upscaling: the mask would be made at the render size from the full-size
  // textures, which isn't done.)
  if (!taa_frame_.armed || !taa_frame_.in_scene || taa_frame_.up_wanted ||
      REXCVAR_GET(temporal_aa_reactive) <= 0.0 ||
      (taa_frame_.snapshots & (1u << slot))) {
    return;
  }
  if (slot && !(taa_frame_.snapshots & 1)) {
    return;
  }
  if (TaaSnapshot(slot, HdrColorTargetKey(0))) {
    taa_frame_.snapshots |= 1u << slot;
  }
}

void CommandProcessor::TaaSetUnavailable(const char* why) {
  static std::atomic<bool> logged{false};
  if (!logged.exchange(true)) {
    REXGPU_WARN("Temporal AA: FSR is unavailable ({})", why);
  }
  rex::cvar::SetFlagByName("temporal_aa_available", "no");
}

void CommandProcessor::TaaFsrJitter(float jitter_out[2]) const {
  // What the scene's draws were actually moved by (none were: none).
  if (!taa_frame_.jittered_draws) {
    jitter_out[0] = jitter_out[1] = 0.0f;
    return;
  }
  uint32_t flip = REXCVAR_GET(temporal_aa_flip_jitter);
  jitter_out[0] = (flip & 1) ? -taa_frame_.jitter[0] : taa_frame_.jitter[0];
  jitter_out[1] = (flip & 2) ? -taa_frame_.jitter[1] : taa_frame_.jitter[1];
}

void CommandProcessor::TaaJitterNdcOffset(xenos::PrimitiveType primitive_type,
                                          bool origin_bottom_left, const uint32_t extent[2],
                                          float ndc_offset[3]) {
  if (!taa_frame_.in_scene) {
    return;
  }
  ++taa_frame_.scene_draws;
  if (taa_frame_.up_wanted && taa_frame_.up_state == 0) {
    TaaUpscaleDecide();
  }
  if (TaaDebug() == 7 && taa_up_frames_ % 300 == 1) {
    // Development: which surfaces the scene's draws go to.
    const RegisterFile& dregs = *register_file_;
    auto surface = dregs.Get<reg::RB_SURFACE_INFO>();
    auto color_info = dregs.Get<reg::RB_COLOR_INFO>();
    auto depth_info = dregs.Get<reg::RB_DEPTH_INFO>();
    static uint32_t last_key = 0, repeats = 0;
    uint32_t key = surface.value ^ (color_info.value * 31u) ^ (depth_info.value * 17u) ^
                   (uint32_t(primitive_type) << 24);
    if (key == last_key) {
      ++repeats;
    } else {
      REXGPU_INFO(
          "UPS draw: pitch {} msaa {} color fmt {} base {} depth fmt {} base {} prim {} "
          "viewport extent {}x{} (x{} like the last)",
          uint32_t(surface.surface_pitch), uint32_t(surface.msaa_samples),
          uint32_t(color_info.color_format),
          uint32_t(color_info.color_base), uint32_t(depth_info.depth_format),
          uint32_t(depth_info.depth_base), uint32_t(primitive_type), extent[0], extent[1],
          repeats);
      last_key = key;
      repeats = 0;
    }
  }
  if (!taa_frame_.armed || !extent[0] || !extent[1]) {
    return;
  }
  // Upscaling asked for and this frame isn't squeezed (4x MSAA, another surface): FSR
  // doesn't run in it, so nothing is shaken.
  if (taa_frame_.up_wanted && taa_frame_.up_state != 1) {
    return;
  }
  // The scene's full-screen passes (the fog) are rectangles; its geometry
  // isn't, and is drawn through the viewport into the main view (as wide as
  // the target).
  if (primitive_type == xenos::PrimitiveType::kRectangleList) {
    return;
  }
  const RegisterFile& regs = *register_file_;
  if (regs.Get<reg::PA_CL_CLIP_CNTL>().clip_disable) {
    return;
  }
  auto vte = regs.Get<reg::PA_CL_VTE_CNTL>();
  if (!vte.vport_x_scale_ena || !vte.vport_y_scale_ena || !vte.vport_x_offset_ena ||
      !vte.vport_y_offset_ena) {
    return;
  }
  float x_scale = regs.Get<float>(XE_GPU_REG_PA_CL_VPORT_XSCALE);
  uint32_t pitch = regs.Get<reg::RB_SURFACE_INFO>().surface_pitch;
  if (std::abs(std::abs(x_scale) * 2.0f - float(pitch)) > 1.0f) {
    return;
  }
  // The jitter is in pixels of the surface the draw is drawn at: the squeezed one when
  // the scene is squeezed (the viewport's extent is scaled by the same ratio).
  float jitter_extent[2] = {float(extent[0]), float(extent[1])};
  if (taa_frame_.up_state == 1 && taa_up_.out_width && taa_up_.out_height) {
    jitter_extent[0] *= float(taa_up_.render_width) / float(taa_up_.out_width);
    jitter_extent[1] *= float(taa_up_.render_height) / float(taa_up_.out_height);
  }
  ndc_offset[0] += 2.0f * taa_frame_.jitter[0] / jitter_extent[0];
  ndc_offset[1] += (origin_bottom_left ? -2.0f : 2.0f) * taa_frame_.jitter[1] / jitter_extent[1];
  ++taa_frame_.jittered_draws;
}

void CommandProcessor::TaaUpscaleSizes(bool fsr_mode, double ratio) {
  // The size FSR is made for: the output over the ratio asked for.
  taa_up_.render_width = taa_up_.out_width;
  taa_up_.render_height = taa_up_.out_height;
  if (fsr_mode && ratio > 1.0 && taa_up_.out_width && taa_up_.out_height && !taa_up_.failed &&
      TaaUpscaleSupported()) {
    taa_up_.render_width = std::max<uint32_t>(16, uint32_t(double(taa_up_.out_width) / ratio + 0.5));
    taa_up_.render_height =
        std::max<uint32_t>(16, uint32_t(double(taa_up_.out_height) / ratio + 0.5));
    taa_up_.render_width = std::min(taa_up_.render_width, taa_up_.out_width);
    taa_up_.render_height = std::min(taa_up_.render_height, taa_up_.out_height);
  }
}

void CommandProcessor::TaaUpscaleFail(const char* why) {
  static std::atomic<bool> logged{false};
  if (!logged.exchange(true)) {
    REXGPU_ERROR("FSR upscaling: giving up for this session ({})", why);
  }
  rex::cvar::SetFlagByName("temporal_aa_upscale_available", "no");
}

void CommandProcessor::TaaUpscaleDecide() {
  // At the scene's first draw of a frame that may be squeezed: gameplay is one
  // single-sampled surface of the output's width. The three-tile 4x MSAA worlds behind
  // the pause menu and the GPS map are not squeezed.
  taa_frame_.up_state = 2;
  if (!taa_frame_.up_armed) {
    return;
  }
  const RegisterFile& regs = *register_file_;
  auto surface = regs.Get<reg::RB_SURFACE_INFO>();
  uint32_t scale_x = 1, scale_y = 1;
  HdrDrawResolutionScale(scale_x, scale_y);
  if (surface.msaa_samples != xenos::MsaaSamples::k1X || !taa_up_.out_width ||
      surface.surface_pitch * scale_x != taa_up_.out_width ||
      taa_up_.render_width >= taa_up_.out_width || !HdrHostRenderTargets()) {
    return;
  }
  taa_up_.scene_pitch = surface.surface_pitch;
  taa_frame_.up_state = 1;
}

bool CommandProcessor::TaaDrawSqueezed() const {
  return taa_frame_.up_state == 1 && taa_frame_.in_scene &&
         register_file_->Get<reg::RB_SURFACE_INFO>().surface_pitch == taa_up_.scene_pitch;
}

float CommandProcessor::TaaPsParamGenScale() const {
  if (!TaaDrawSqueezed() || !taa_up_.render_width) {
    return 1.0f;
  }
  return float(taa_up_.out_width) / float(taa_up_.render_width);
}

uint32_t CommandProcessor::TaaLodBias() const {
  if (!TaaDrawSqueezed() || !taa_up_.render_width) {
    return 0;
  }
  // The pixels of the scene are (output / render) times as far apart, so textures are
  // sampled at that many times the size: log2 of it, in eighths, a level sharper.
  float bias = std::log2(float(taa_up_.out_width) / float(taa_up_.render_width)) * 8.0f;
  return uint32_t(std::clamp(bias + 0.5f, 0.0f, 15.0f));
}

void CommandProcessor::TaaSqueeze(uint32_t viewport_offset[2], uint32_t viewport_extent[2],
                                  uint32_t scissor_offset[2], uint32_t scissor_extent[2]) {
  if (!TaaDrawSqueezed()) {
    return;
  }
  const uint32_t render[2] = {taa_up_.render_width, taa_up_.render_height};
  const uint32_t output[2] = {taa_up_.out_width, taa_up_.out_height};
  // The edges are scaled, not the sizes, so that rectangles that meet still do.
  auto scale = [&](uint32_t offset[2], uint32_t extent[2]) {
    for (uint32_t i = 0; i < 2; ++i) {
      uint64_t begin = (uint64_t(offset[i]) * render[i] + output[i] / 2) / output[i];
      uint64_t end = (uint64_t(offset[i]) + extent[i]) * render[i];
      end = (end + output[i] / 2) / output[i];
      if (extent[i] && end <= begin) {
        end = begin + 1;
      }
      offset[i] = uint32_t(begin);
      extent[i] = uint32_t(end - begin);
    }
  };
  scale(viewport_offset, viewport_extent);
  scale(scissor_offset, scissor_extent);
  ++taa_frame_.up_squeezed_draws;
}

void CommandProcessor::TaaResolveStretch(const TaaResolveInfo& resolve, TaaStretch& stretch_out) {
  stretch_out = TaaStretch();
  if (!TaaSqueezingScene()) {
    return;
  }
  const bool scene_resolve =
      resolve.pitch_px == taa_up_.scene_pitch && resolve.msaa_samples == 1;
  // Development: the first resolves of the squeezed frames, and every scene resolve that
  // can't be stretched.
  if (TaaDebug() == 7 && (taa_up_resolve_logs_ < 80 || (scene_resolve && !resolve.copy_ok))) {
    ++taa_up_resolve_logs_;
    REXGPU_INFO(
        "UPS resolve: {} format {}, copy shader {}, source pitch {} px, {} samples (scene pitch "
        "{}), one owner {}, stretchable {}",
        resolve.is_depth ? "depth" : "color", resolve.format, resolve.copy_shader, resolve.pitch_px,
        resolve.msaa_samples, taa_up_.scene_pitch, resolve.direct_source, resolve.copy_ok);
  }
  if (!scene_resolve) {
    ++taa_frame_.up_other_resolves;
    return;
  }
  if (!resolve.copy_ok) {
    ++taa_frame_.up_other_resolves;
    TaaUpscaleFail(
        fmt::format("a resolve of the squeezed scene could not be stretched: {} format {}, copy "
                    "shader {}, {}",
                    resolve.is_depth ? "depth" : "color", resolve.format, resolve.copy_shader,
                    resolve.direct_source ? "no stretching shader for it"
                                          : "no single render target owns the area")
            .c_str());
    taa_up_.failed = true;
    return;
  }
  stretch_out.active = true;
  stretch_out.num[0] = taa_up_.render_width;
  stretch_out.num[1] = taa_up_.render_height;
  stretch_out.den[0] = taa_up_.out_width;
  stretch_out.den[1] = taa_up_.out_height;
  ++taa_frame_.up_stretched_resolves;
}

bool CommandProcessor::TaaCheckDraw() {
  if (taa_frame_.mode == TaaMode::kOff || !taa_frame_.post || taa_frame_.done) {
    return false;
  }
  const RegisterFile& regs = *register_file_;
  if (regs.Get<reg::RB_MODECONTROL>().edram_mode != xenos::EdramMode::kColorDepth) {
    return false;
  }
  Shader* pixel_shader = active_pixel_shader();
  if (!pixel_shader || pixel_shader->ucode_data_hash() != kTaaMotionBlurPixelShader) {
    return false;
  }
  taa_frame_.status = 'f';  // the draw found, its fetch constants not as expected
  // The scene, the stencil view and the depth: 2D, the same size, the frame's.
  static const xenos::TextureFormat kFormats[3] = {xenos::TextureFormat::k_16_16_16_16_EXPAND,
                                                   xenos::TextureFormat::k_8_8_8_8,
                                                   xenos::TextureFormat::k_24_8_FLOAT};
  uint32_t width = 0, height = 0;
  for (uint32_t i = 0; i < 3; ++i) {
    xenos::xe_gpu_texture_fetch_t fetch = regs.GetTextureFetch(i);
    if (fetch.type != xenos::FetchConstantType::kTexture ||
        fetch.dimension != xenos::DataDimension::k2DOrStacked || fetch.format != kFormats[i]) {
      return false;
    }
    uint32_t fetch_width = fetch.size_2d.width + 1, fetch_height = fetch.size_2d.height + 1;
    if (!i) {
      width = fetch_width;
      height = fetch_height;
    } else if (fetch_width != width || fetch_height != height) {
      return false;
    }
  }
  auto constant = [&regs](uint32_t index, uint32_t component) {
    uint32_t bits = regs[XE_GPU_REG_SHADER_CONSTANT_256_X + index * 4 + component];
    float value;
    std::memcpy(&value, &bits, sizeof(float));
    return double(value);
  };
  if (constant(62, 0) != double(width) || constant(62, 1) != double(height)) {
    taa_frame_.status = 's';
    return false;
  }
  // The scene textures' size is the output FSR upscales to; with upscaling asked for,
  // the size it is made for follows from it.
  // (The fetch constants' size is the guest's; the output is in host pixels.)
  uint32_t host_scale_x = 1, host_scale_y = 1;
  HdrDrawResolutionScale(host_scale_x, host_scale_y);
  if (taa_up_.out_width != width * host_scale_x || taa_up_.out_height != height * host_scale_y) {
    taa_up_.out_width = width * host_scale_x;
    taa_up_.out_height = height * host_scale_y;
  }
  // The ratio the frame was started with (the setting may change in the middle of a frame).
  TaaUpscaleSizes(taa_frame_.mode == TaaMode::kFsr, taa_frame_.up_ratio);
  taa_frame_.status = 'i';  // the matrices not invertible
  Mat4 view, view_projection, inverse_view_projection;
  for (uint32_t i = 0; i < 4; ++i) {
    for (uint32_t j = 0; j < 4; ++j) {
      view[i][j] = constant(4 + i, j);
      view_projection[i][j] = constant(8 + i, j);
    }
  }
  if (!TaaInverse(view_projection, inverse_view_projection)) {
    return false;
  }
  taa_frame_.status = 'b';  // the backend's turn
  // Clip position to the previous frame's pixels, per vehicle ID.
  TaaVectorConstants& constants = taa_vector_constants_;
  for (uint32_t k = 0; k < 24; ++k) {
    Mat4 previous, combined;
    for (uint32_t i = 0; i < 4; ++i) {
      for (uint32_t j = 0; j < 4; ++j) {
        previous[i][j] = constant(69 + 4 * k + i, j);
      }
    }
    TaaMul(inverse_view_projection, previous, combined);
    for (uint32_t i = 0; i < 4; ++i) {
      for (uint32_t j = 0; j < 4; ++j) {
        constants.previous[k][i][j] = float(combined[i][j]);
      }
    }
  }
  // The rest (the host size, the jitter) is the backend's.
  constants.jitter[0] = taa_frame_.jitter[0];
  constants.jitter[1] = taa_frame_.jitter[1];

  // The projection (view inverse x view-projection): the planes' distances and
  // the vertical field of view, for FSR's depth tests.
  Mat4 inverse_view, projection;
  TaaCamera& camera = taa_camera_;
  if (TaaInverse(view, inverse_view)) {
    TaaMul(inverse_view, view_projection, projection);
    double a = projection[2][2], b = projection[3][2], w = projection[2][3];
    // Depth (view space) at NDC z 0 and 1: z = b / (w ndc - a).
    double z0 = std::abs(a) > 1e-12 ? std::abs(b / a) : 0.0;
    double z1 = std::abs(w - a) > 1e-12 ? std::abs(b / (w - a)) : 0.0;
    double near_plane = std::min(z0, z1), far_plane = std::max(z0, z1);
    if (std::isfinite(near_plane) && std::isfinite(far_plane) && near_plane > 0.0 &&
        far_plane > near_plane && std::abs(projection[1][1]) > 1e-6) {
      camera.near_plane = float(near_plane);
      camera.far_plane = float(far_plane);
      camera.fov_vertical = float(2.0 * std::atan(1.0 / std::abs(projection[1][1])));
    }
  }
  // A cut: the camera jumped, turned by more than 30 degrees, or zoomed by
  // more than 5% (the replay cameras).
  float position[3] = {float(constant(15, 0)), float(constant(15, 1)), float(constant(15, 2))};
  float forward[3] = {float(constant(14, 0)), float(constant(14, 1)), float(constant(14, 2))};
  camera.reset = !taa_last_done_ || !taa_have_last_camera_;
  if (taa_have_last_camera_) {
    float dx = position[0] - taa_last_camera_[0][0], dy = position[1] - taa_last_camera_[0][1],
          dz = position[2] - taa_last_camera_[0][2];
    float forward_dot = forward[0] * taa_last_camera_[1][0] +
                        forward[1] * taa_last_camera_[1][1] +
                        forward[2] * taa_last_camera_[1][2];
    float forward_length2 = forward[0] * forward[0] + forward[1] * forward[1] +
                            forward[2] * forward[2];
    double cut = REXCVAR_GET(temporal_aa_cut_distance);
    if (std::sqrt(dx * dx + dy * dy + dz * dz) > cut ||
        forward_dot < 0.866f * forward_length2 ||
        std::abs(camera.fov_vertical - taa_last_fov_) > 0.05f * taa_last_fov_) {
      camera.reset = true;
    }
  }
  taa_last_fov_ = camera.fov_vertical;
  std::memcpy(taa_last_camera_[0], position, sizeof(position));
  std::memcpy(taa_last_camera_[1], forward, sizeof(forward));
  taa_have_last_camera_ = true;

  uint64_t now = rex::chrono::Clock::QueryHostTickCount();
  if (taa_last_time_) {
    double ms = double(now - taa_last_time_) * 1000.0 /
                double(rex::chrono::Clock::QueryHostTickFrequency());
    taa_frame_time_ms_ = float(std::clamp(ms, 1.0, 100.0));
  }
  taa_last_time_ = now;
  taa_frame_.hook = true;
  return true;
}

void CommandProcessor::TaaEndFrame() {
  uint32_t debug = TaaDebug();
  if (debug == 4 && ++taa_log_frames_ >= 120) {
    taa_log_frames_ = 0;
    double gpu_ms;
    uint32_t gpu_count;
    TaaTakeGpuTime(gpu_ms, gpu_count);
    REXGPU_INFO(
        "Temporal AA: mode {}, {} of {} scene draws jittered, pass {} ({}), jitter {:.3f} {:.3f}, "
        "GPU {:.3f} ms (mean of {})",
        uint32_t(taa_frame_.mode), taa_frame_.jittered_draws, taa_frame_.scene_draws,
        taa_frame_.done ? "ran" : "didn't run", taa_frame_.status,
        taa_frame_.jitter[0], taa_frame_.jitter[1], gpu_count ? gpu_ms / gpu_count : 0.0,
        gpu_count);
  }
  if (!taa_availability_checked_) {
    taa_availability_checked_ = true;
    bool available = TaaCheckAvailable();
    bool next_start = !available && TaaAvailableAtNextStart();
    rex::cvar::SetFlagByName("temporal_aa_available",
                             available ? "yes" : (next_start ? "next_start" : "no"));
    REXGPU_INFO("Temporal AA: FSR {}", available    ? "available"
                                       : next_start ? "available from the next start (the device "
                                                      "was created without its features)"
                                                    : "unavailable");
    rex::cvar::SetFlagByName("temporal_aa_upscale_available",
                             available && TaaUpscaleSupported() ? "yes" : "no");
  }
  taa_last_done_ = taa_frame_.done;
  taa_last_hook_ = taa_frame_.hook;
  taa_last_squeezed_ = taa_frame_.up_state == 1;
  ++taa_up_frames_;
  if (debug == 7 && taa_frame_.mode != TaaMode::kOff &&
      (taa_up_frames_ % 120 == 1 || (taa_frame_.up_state == 1 && taa_up_squeezed_logs_++ < 12))) {
    REXGPU_INFO(
        "UPS: wanted {} armed {} state {} hook {} done {} ({}), scene draws {} squeezed {}, "
        "jittered {}, resolves stretched {} other {}, render {}x{} output {}x{}",
        taa_frame_.up_wanted, taa_frame_.up_armed, uint32_t(taa_frame_.up_state), taa_frame_.hook,
        taa_frame_.done, taa_frame_.status, taa_frame_.scene_draws, taa_frame_.up_squeezed_draws,
        taa_frame_.jittered_draws, taa_frame_.up_stretched_resolves, taa_frame_.up_other_resolves,
        taa_up_.render_width, taa_up_.render_height, taa_up_.out_width, taa_up_.out_height);
  }
  // A squeezed frame in which the anti-aliasing pass didn't run shows the scene stretched
  // (blocky) for that one frame; the next isn't squeezed.
  if (taa_frame_.up_state == 1 && !taa_frame_.done) {
    static std::atomic<uint32_t> unfinished_logged{0};
    if (unfinished_logged.fetch_add(1) < 5) {
      REXGPU_WARN("FSR upscaling: a squeezed frame ended without the FSR pass ({})",
                  taa_frame_.status);
    }
  }
  // A release the frame asked for (the submission is closed now).
  if (taa_release_pending_) {
    taa_release_pending_ = false;
    taa_last_done_ = false;
    taa_last_squeezed_ = false;
    TaaRelease();
  }
  TaaFrameEnd();
  TaaFrame frame;
  // Under the option registry's lock: a title may set it from another thread.
  frame.mode = rex::cvar::GetFlagByName("temporal_aa") == "fsr" ? TaaMode::kFsr : TaaMode::kOff;
  // Frame generation needs the motion vectors without FSR too.
  if (frame.mode == TaaMode::kOff && frame_generation_inputs_given_) {
    frame.mode = TaaMode::kVectors;
  }
  if (frame.mode == TaaMode::kOff) {
    taa_last_done_ = false;
    taa_have_last_camera_ = false;
    taa_last_time_ = 0;
    // The upscaler (about 500 MB at 4K) isn't kept while it stays off for
    // 10 seconds (switching back and forth doesn't make it again each time);
    // released once the GPU is done with it.
    if (taa_off_since_ != UINT64_MAX) {
      uint64_t now = rex::chrono::Clock::QueryHostTickCount();
      if (!taa_off_since_) {
        taa_off_since_ = now;
      } else if (now - taa_off_since_ > 10 * rex::chrono::Clock::QueryHostTickFrequency()) {
        TaaRelease();
        taa_off_since_ = UINT64_MAX;
      }
    }
  } else {
    taa_off_since_ = 0;
    // The size FSR is made for, with the ratio asked for now (TaaReady compares).
    // Read once: the frame is squeezed and finished with this ratio even if the setting changes.
    frame.up_ratio = REXCVAR_GET(temporal_aa_upscale);
    TaaUpscaleSizes(frame.mode == TaaMode::kFsr, frame.up_ratio);
    frame.up_wanted = frame.mode == TaaMode::kFsr && !taa_up_.failed && frame.up_ratio > 1.0 &&
                      TaaUpscaleSupported();
    if (frame.up_wanted) {
      // Squeezed (and jittered) when FSR exists for the render size and the last frame
      // had the anti-aliasing draw, which FSR then runs at: not after a squeezed frame
      // the pass didn't run in (the frame wasn't what it was thought to be); three of those
      // in a row give upscaling up.
      if (taa_last_squeezed_ && !taa_last_done_) {
        if (++taa_up_misses_ >= 3) {
          TaaUpscaleFail("squeezed frames without the FSR pass");
          taa_up_.failed = true;
          frame.up_wanted = false;
        }
      } else {
        frame.up_armed = taa_last_hook_ && TaaReady() && debug != 2;
        if (taa_last_done_) {
          taa_up_misses_ = 0;
        }
      }
      frame.armed = frame.up_armed;
    } else {
      // Jittered only after a frame the pass ran in, so a frame without it (no
      // scene, the upscaler not ready yet) never shows the shake.
      frame.armed = frame.mode == TaaMode::kFsr && taa_last_done_ && TaaReady() && debug != 2;
    }
    if (frame.armed) {
      // FSR's phase count: 8 x (output / render)^2.
      float scale = taa_up_.render_width ? float(taa_up_.out_width) / float(taa_up_.render_width)
                                         : 1.0f;
      uint32_t phases = std::max(kTaaJitterPhases, uint32_t(std::ceil(8.0f * scale * scale)));
      uint32_t phase = taa_jitter_index_++ % phases + 1;
      frame.jitter[0] = TaaHalton(phase, 2) - 0.5f;
      frame.jitter[1] = TaaHalton(phase, 3) - 0.5f;
    }
  }
  taa_frame_ = frame;
}

}  // namespace rex::graphics

#if defined(REX_HAS_FSR) && REX_HAS_FSR

#include <string>

#include <rex/filesystem.h>
#if !(defined(REX_FSR_STATIC) && REX_FSR_STATIC)
#include <rex/platform/dynlib.h>
#endif

#include "temporal_aa_fsr.h"

#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
// Weak: the game links FidelityFX's static libraries when they were built
// (ps5/game/build.sh); without them these are null and FSR is unavailable.
#pragma weak ffxCreateContext
#pragma weak ffxDestroyContext
#pragma weak ffxConfigure
#pragma weak ffxQuery
#pragma weak ffxDispatch
#endif

namespace rex::graphics {

#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
bool FsrRuntime::Linked() {
  return &ffxCreateContext && &ffxDestroyContext && &ffxConfigure && &ffxQuery && &ffxDispatch;
}
#endif

bool FsrRuntime::Load(const char* api) {
  if (tried_) {
    return create != nullptr;
  }
  tried_ = true;
#if defined(REX_FSR_STATIC) && REX_FSR_STATIC
  // Linked into the executable (the PS5 can't load modules), if the game's
  // link had FidelityFX's static libraries (weak references otherwise).
  (void)api;
  if (!Linked()) {
    REXGPU_WARN("Temporal AA: FidelityFX isn't linked into the executable; FSR is unavailable");
    return false;
  }
  create = &ffxCreateContext;
  destroy = &ffxDestroyContext;
  configure = &ffxConfigure;
  query = &ffxQuery;
  dispatch = &ffxDispatch;
  REXGPU_INFO("Temporal AA: FidelityFX linked in");
  return true;
#else
#if REX_PLATFORM_WIN32
  std::string name = std::string("amd_fidelityfx_") + api + ".dll";
#else
  std::string name = std::string("libamd_fidelityfx_") + api + ".so";
#endif
  std::filesystem::path path = rex::filesystem::GetExecutableFolder() / name;
  auto* library = new rex::platform::DynamicLibrary();
  if (!library->Load(path, rex::platform::SymbolResolution::kImmediate)) {
    REXGPU_WARN("Temporal AA: {} isn't next to the executable; FSR is unavailable", name);
    delete library;
    return false;
  }
  create = library->GetSymbol<PfnFfxCreateContext>("ffxCreateContext");
  destroy = library->GetSymbol<PfnFfxDestroyContext>("ffxDestroyContext");
  configure = library->GetSymbol<PfnFfxConfigure>("ffxConfigure");
  query = library->GetSymbol<PfnFfxQuery>("ffxQuery");
  dispatch = library->GetSymbol<PfnFfxDispatch>("ffxDispatch");
  if (!create || !destroy || !configure || !query || !dispatch) {
    REXGPU_WARN("Temporal AA: {} lacks the ffx-api entry points; FSR is unavailable", name);
    create = nullptr;
    delete library;
    return false;
  }
  // Kept loaded for the process's lifetime (contexts may outlive a backend).
  library_ = library;
  REXGPU_INFO("Temporal AA: loaded {}", name);
  return true;
#endif  // REX_FSR_STATIC
}

void FsrRuntime::Message(uint32_t type, const wchar_t* message) {
  std::string text;
  for (const wchar_t* c = message; c && *c && text.size() < 1000; ++c) {
    text.push_back(*c < 0x80 ? char(*c) : '?');
  }
  if (type == FFX_API_MESSAGE_TYPE_ERROR) {
    REXGPU_ERROR("FSR: {}", text);
  } else {
    REXGPU_WARN("FSR: {}", text);
  }
}

}  // namespace rex::graphics

#endif  // REX_HAS_FSR
