/**
 * Direct3D 12 low latency (rexglue-low-latency.patch): NVIDIA Reflex through NVAPI and AMD
 * Anti-Lag 2 through the driver extension. See include/rex/ui/low_latency.h.
 *
 * NVAPI is not linked and has no SDK to download: nvapi64.dll comes with the NVIDIA driver, and
 * the functions are found with nvapi_QueryInterface by the ids in NVAPI's public nvapi_interface.h
 * (github.com/NVIDIA/nvapi, MIT, Copyright (c) NVIDIA CORPORATION & AFFILIATES). The structures
 * and enums below are the ones of its nvapi.h that Reflex uses, with the same layouts (packed as
 * NVAPI packs them, 8; their sizes are checked).
 */

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <rex/cvar.h>
#include <rex/logging.h>
#include <rex/ui/d3d12/d3d12_low_latency.h>

#include <d3d12.h>

#include <rex/ui/d3d12/amd_antilag2_dx12.h>

REXCVAR_DECLARE(std::string, low_latency_debug_backend);
REXCVAR_DECLARE(int32_t, low_latency_debug);

namespace rex {
namespace ui {
namespace d3d12 {

namespace {

// --- NVAPI ---------------------------------------------------------------------------------

#pragma pack(push, 8)
using NvU8 = uint8_t;
using NvU32 = uint32_t;
using NvU64 = uint64_t;
using NvBool = NvU8;
using NvAPI_Status = int32_t;
constexpr NvAPI_Status kNvApiOk = 0;

enum NvLatencyMarkerType : uint32_t {
  SIMULATION_START = 0,
  SIMULATION_END = 1,
  RENDERSUBMIT_START = 2,
  RENDERSUBMIT_END = 3,
  PRESENT_START = 4,
  PRESENT_END = 5,
  INPUT_SAMPLE = 6,
  TRIGGER_FLASH = 7,
  PC_LATENCY_PING = 8,
  OUT_OF_BAND_RENDERSUBMIT_START = 9,
  OUT_OF_BAND_RENDERSUBMIT_END = 10,
  OUT_OF_BAND_PRESENT_START = 11,
  OUT_OF_BAND_PRESENT_END = 12,
};

struct NvSetSleepModeParams {
  NvU32 version;
  NvBool bLowLatencyMode;
  NvBool bLowLatencyBoost;
  NvU32 minimumIntervalUs;
  NvBool bUseMarkersToOptimize;
  NvBool bUseMinQueueTime;
  NvU8 rsvd[30];
};

struct NvLatencyMarkerParams {
  NvU32 version;
  NvU64 frameID;
  NvLatencyMarkerType markerType;
  NvU64 rsvd0;
  NvU8 rsvd[56];
};

struct NvLatencyFrameReport {
  NvU64 frameID;
  NvU64 inputSampleTime;
  NvU64 simStartTime;
  NvU64 simEndTime;
  NvU64 renderSubmitStartTime;
  NvU64 renderSubmitEndTime;
  NvU64 presentStartTime;
  NvU64 presentEndTime;
  NvU64 driverStartTime;
  NvU64 driverEndTime;
  NvU64 osRenderQueueStartTime;
  NvU64 osRenderQueueEndTime;
  NvU64 gpuRenderStartTime;
  NvU64 gpuRenderEndTime;
  NvU32 gpuActiveRenderTimeUs;
  NvU32 gpuFrameTimeUs;
  NvU64 cameraConstructedTime;
  NvU32 crossAdapterCopyTimeUs;
  NvU32 aiFrameTimeUs;
  NvU8 rsvd[104];
};

struct NvLatencyResultParams {
  NvU32 version;
  NvLatencyFrameReport frameReport[64];
  NvU8 rsvd[32];
};

struct NvGetSleepStatusParams {
  NvU32 version;
  NvBool bLowLatencyMode;
  NvBool bFsVrr;
  NvBool bCplVsyncOn;
  NvU32 sleepIntervalUs;
  NvBool bUseGameSleep;
  NvBool bFullscreenIFlip;
  NvU8 fgMultiplier;
  NvBool bDfgControl;
  NvU32 dfgFrameTimeTargetUs;
  NvU8 rsvd[114];
};
#pragma pack(pop)

// MAKE_NVAPI_VERSION(type, 1).
template <typename T>
constexpr NvU32 NvVersion1() {
  return NvU32(sizeof(T) | (1u << 16));
}

constexpr uint32_t kIdInitialize = 0x0150e828;
constexpr uint32_t kIdSetSleepMode = 0xac1ca9e0;
constexpr uint32_t kIdSleep = 0x852cd1d2;
constexpr uint32_t kIdSetLatencyMarker = 0xd9984c05;
constexpr uint32_t kIdGetLatency = 0x1a587f9c;
constexpr uint32_t kIdGetSleepStatus = 0xaef96ca1;

// Reflex's NvAPI_D3D_* take the device as an IUnknown.
using PfnQueryInterface = void*(__cdecl*)(uint32_t id);
using PfnInitialize = NvAPI_Status(__cdecl*)();
using PfnSetSleepMode = NvAPI_Status(__cdecl*)(IUnknown*, NvSetSleepModeParams*);
using PfnSleep = NvAPI_Status(__cdecl*)(IUnknown*);
using PfnSetLatencyMarker = NvAPI_Status(__cdecl*)(IUnknown*, NvLatencyMarkerParams*);
using PfnGetLatency = NvAPI_Status(__cdecl*)(IUnknown*, NvLatencyResultParams*);
using PfnGetSleepStatus = NvAPI_Status(__cdecl*)(IUnknown*, NvGetSleepStatusParams*);

static_assert(sizeof(NvSetSleepModeParams) == 44, "NV_SET_SLEEP_MODE_PARAMS_V1");
static_assert(sizeof(NvLatencyMarkerParams) == 88, "NV_LATENCY_MARKER_PARAMS_V1");
static_assert(sizeof(NvLatencyFrameReport) == 240, "NV_LATENCY_RESULT_PARAMS_V1::FrameReport");
static_assert(sizeof(NvLatencyResultParams) == 15400, "NV_LATENCY_RESULT_PARAMS_V1");
static_assert(sizeof(NvGetSleepStatusParams) == 136, "NV_GET_SLEEP_STATUS_PARAMS_V1");

class NvapiReflex final : public LowLatencyBackend {
 public:
  static std::shared_ptr<NvapiReflex> Create(ID3D12Device* device, const char** why) {
    // The driver's own NVAPI, from the system folder only (not one beside the executable).
    HMODULE module = LoadLibraryExW(L"nvapi64.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!module) {
      *why = "NO NVAPI";
      return nullptr;
    }
    auto query =
        reinterpret_cast<PfnQueryInterface>(GetProcAddress(module, "nvapi_QueryInterface"));
    if (!query) {
      *why = "NO NVAPI";
      return nullptr;
    }
    auto initialize = reinterpret_cast<PfnInitialize>(query(kIdInitialize));
    if (!initialize || initialize() != kNvApiOk) {
      *why = "NVAPI FAILED";
      return nullptr;
    }
    std::shared_ptr<NvapiReflex> reflex(new NvapiReflex(device));
    reflex->set_sleep_mode_ = reinterpret_cast<PfnSetSleepMode>(query(kIdSetSleepMode));
    reflex->sleep_ = reinterpret_cast<PfnSleep>(query(kIdSleep));
    reflex->set_latency_marker_ = reinterpret_cast<PfnSetLatencyMarker>(query(kIdSetLatencyMarker));
    reflex->get_latency_ = reinterpret_cast<PfnGetLatency>(query(kIdGetLatency));
    reflex->get_sleep_status_ = reinterpret_cast<PfnGetSleepStatus>(query(kIdGetSleepStatus));
    if (!reflex->set_sleep_mode_ || !reflex->sleep_ || !reflex->set_latency_marker_) {
      *why = "NEEDS A NEWER DRIVER";
      return nullptr;
    }
    // (Whether the driver takes the calls for this GPU is found out when the mode is first set.)
    return reflex;
  }

  const char* Name() const override { return "NVIDIA REFLEX"; }
  bool SupportsBoost() const override { return true; }
  bool OnByDefault() const override { return kOnByDefault; }
  const char* FailureReason() const override { return "NOT SUPPORTED"; }

  bool SetMode(bool on, bool boost, uint32_t minimum_interval_us) override {
    NvSetSleepModeParams params = {};
    params.version = NvVersion1<NvSetSleepModeParams>();
    params.bLowLatencyMode = on ? 1 : 0;
    params.bLowLatencyBoost = boost ? 1 : 0;
    params.minimumIntervalUs = minimum_interval_us;
    params.bUseMarkersToOptimize = 1;
    const NvAPI_Status status = set_sleep_mode_(device_.Get(), &params);
    if (status != kNvApiOk) {
      REXLOG_WARN("Low latency: NvAPI_D3D_SetSleepMode failed ({})", status);
      return false;
    }
    if (get_sleep_status_) {
      NvGetSleepStatusParams sleep_status = {};
      sleep_status.version = NvVersion1<NvGetSleepStatusParams>();
      if (get_sleep_status_(device_.Get(), &sleep_status) == kNvApiOk) {
        REXLOG_INFO(
            "Low latency: the driver's sleep status: low latency mode {}, interval {} us, "
            "game sleep {}",
            sleep_status.bLowLatencyMode ? "on" : "off", sleep_status.sleepIntervalUs,
            sleep_status.bUseGameSleep ? "used" : "not used");
      }
    }
    return true;
  }

  // NvAPI_D3D_Sleep waits for the moment the driver picks and can't be cancelled, so it has no
  // bound as Vulkan's wait has: the core times it when it returns, and gives the reducer up (for
  // a while) when it takes too long, three times in eight. A call that never returns is not
  // covered.
  bool Sleep(uint64_t) override { return sleep_(device_.Get()) == kNvApiOk; }

  void Marker(LatencyMarker marker, uint64_t frame_id) override {
    NvLatencyMarkerType type;
    switch (marker) {
      case LatencyMarker::kSimulationStart:
        type = SIMULATION_START;
        break;
      case LatencyMarker::kSimulationEnd:
        type = SIMULATION_END;
        break;
      case LatencyMarker::kRenderSubmitStart:
        type = RENDERSUBMIT_START;
        break;
      case LatencyMarker::kRenderSubmitEnd:
        type = RENDERSUBMIT_END;
        break;
      case LatencyMarker::kPresentStart:
        type = PRESENT_START;
        break;
      case LatencyMarker::kPresentEnd:
        type = PRESENT_END;
        break;
      case LatencyMarker::kInputSample:
        type = INPUT_SAMPLE;
        break;
      case LatencyMarker::kOutOfBandRenderSubmitStart:
        type = OUT_OF_BAND_RENDERSUBMIT_START;
        break;
      case LatencyMarker::kOutOfBandRenderSubmitEnd:
        type = OUT_OF_BAND_RENDERSUBMIT_END;
        break;
      case LatencyMarker::kOutOfBandPresentStart:
        type = OUT_OF_BAND_PRESENT_START;
        break;
      case LatencyMarker::kOutOfBandPresentEnd:
        type = OUT_OF_BAND_PRESENT_END;
        break;
      default:
        return;
    }
    NvLatencyMarkerParams params = {};
    params.version = NvVersion1<NvLatencyMarkerParams>();
    params.frameID = frame_id;
    params.markerType = type;
    set_latency_marker_(device_.Get(), &params);
  }

  std::string TimingReport() override {
    if (!get_latency_) {
      return std::string();
    }
    auto result = std::make_unique<NvLatencyResultParams>();
    std::memset(result.get(), 0, sizeof(*result));
    result->version = NvVersion1<NvLatencyResultParams>();
    if (get_latency_(device_.Get(), result.get()) != kNvApiOk) {
      return std::string();
    }
    // The newest frames the driver has a whole report for (the last few are still open).
    double input_to_render_end = 0.0, sim_to_render_end = 0.0, gpu_active = 0.0;
    double input_to_present_end = 0.0;
    double stage_guest = 0.0, stage_submit = 0.0, stage_to_gpu = 0.0;
    int count = 0;
    for (int i = 63; i >= 0 && count < 32; --i) {
      const NvLatencyFrameReport& f = result->frameReport[i];
      if (!f.frameID || !f.gpuRenderEndTime || !f.inputSampleTime || !f.simStartTime ||
          !f.presentEndTime) {
        continue;
      }
      input_to_render_end += double(int64_t(f.gpuRenderEndTime - f.inputSampleTime));
      input_to_present_end += double(int64_t(f.presentEndTime - f.inputSampleTime));
      sim_to_render_end += double(int64_t(f.gpuRenderEndTime - f.simStartTime));
      gpu_active += double(f.gpuActiveRenderTimeUs);
      stage_guest += double(int64_t(f.renderSubmitStartTime - f.simStartTime));
      stage_submit += double(int64_t(f.renderSubmitEndTime - f.renderSubmitStartTime));
      stage_to_gpu += double(int64_t(f.gpuRenderStartTime - f.renderSubmitEndTime));
      ++count;
    }
    if (!count) {
      return "no complete frame report yet";
    }
    std::string frames;
    if (REXCVAR_GET(low_latency_debug) & 8) {
      // The newest frames' times from each one's simulation start, in ms.
      int shown = 0;
      for (int i = 63; i >= 0 && shown < 4; --i) {
        const NvLatencyFrameReport& f = result->frameReport[i];
        if (!f.frameID || !f.gpuRenderEndTime || !f.simStartTime || !f.presentEndTime) {
          continue;
        }
        auto at = [&f](uint64_t time) { return double(int64_t(time - f.simStartTime)) / 1000.0; };
        char frame[320];
        std::snprintf(
            frame, sizeof frame,
            " [%llu: sim end %.1f, submit %.1f-%.1f, present %.1f-%.1f, driver %.1f-%.1f, "
            "gpu %.1f-%.1f]",
            (unsigned long long)f.frameID, at(f.simEndTime), at(f.renderSubmitStartTime),
            at(f.renderSubmitEndTime), at(f.presentStartTime), at(f.presentEndTime),
            at(f.driverStartTime), at(f.driverEndTime), at(f.gpuRenderStartTime),
            at(f.gpuRenderEndTime));
        frames += frame;
        ++shown;
      }
    }
    char text[480];
    int length = std::snprintf(
        text, sizeof text,
        "driver's report over %d frames: input sample to GPU render end %.2f ms, to present end "
        "%.2f ms, simulation start to GPU render end %.2f ms, GPU active %.2f ms; stages: "
        "simulation start to render submit start %.2f ms, render submit %.2f ms, render submit "
        "end to GPU start %.2f ms",
        count, input_to_render_end / count / 1000.0, input_to_present_end / count / 1000.0,
        sim_to_render_end / count / 1000.0, gpu_active / count / 1000.0,
        stage_guest / count / 1000.0, stage_submit / count / 1000.0, stage_to_gpu / count / 1000.0);
    if (get_sleep_status_ && length > 0 && size_t(length) < sizeof text) {
      NvGetSleepStatusParams sleep_status = {};
      sleep_status.version = NvVersion1<NvGetSleepStatusParams>();
      if (get_sleep_status_(device_.Get(), &sleep_status) == kNvApiOk) {
        std::snprintf(text + length, sizeof text - size_t(length),
                      "; the driver: low latency mode %s, game sleep %s, interval %u us, frame "
                      "generation multiplier %u, variable refresh %s",
                      sleep_status.bLowLatencyMode ? "on" : "off",
                      sleep_status.bUseGameSleep ? "used" : "not used",
                      unsigned(sleep_status.sleepIntervalUs), unsigned(sleep_status.fgMultiplier),
                      sleep_status.bFsVrr ? "yes" : "no");
      }
    }
    return text + frames;
  }

 private:
  explicit NvapiReflex(ID3D12Device* device) : device_(device) {}

  // low_latency = auto: on for NVIDIA Reflex (patches/README.md has what it costs and gains).
  static constexpr bool kOnByDefault = true;

  Microsoft::WRL::ComPtr<ID3D12Device> device_;
  PfnSetSleepMode set_sleep_mode_ = nullptr;
  PfnSleep sleep_ = nullptr;
  PfnSetLatencyMarker set_latency_marker_ = nullptr;
  PfnGetLatency get_latency_ = nullptr;
  PfnGetSleepStatus get_sleep_status_ = nullptr;
};

// --- AMD Anti-Lag 2 --------------------------------------------------------------------------

// AMD's SDK is built for its calls to run on different threads without a lock of the game's:
// Update (the update thread, which sleeps in it), MarkEndOfFrameRendering (the render thread),
// SetFrameGenFrameType (FidelityFX's presenter thread). The context's pointer is set once, by
// Initialize, which is made when the reducer is first wanted: Initialize turns the driver's
// Anti-Lag off, which is not for a user who never chose it here (their Adrenalin setting stays).
class AmdAntiLag2 final : public LowLatencyBackend {
 public:
  static std::shared_ptr<AmdAntiLag2> Create(ID3D12Device* device, const char** why) {
    // The driver's extension library, loaded by the Direct3D 12 driver of an AMD GPU; nothing is
    // called yet.
    HMODULE module = GetModuleHandleA("amdxc64.dll");
    if (!module || !GetProcAddress(module, "AmdExtD3DCreateInterface")) {
      *why = "NO AMD DRIVER";
      return nullptr;
    }
    std::shared_ptr<AmdAntiLag2> anti_lag(new AmdAntiLag2(device));
    return anti_lag;
  }

  ~AmdAntiLag2() override {
    if (initialized_.load(std::memory_order_acquire)) {
      AMD::AntiLag2DX12::DeInitialize(&context_);
    }
  }

  const char* Name() const override { return "AMD ANTI LAG 2"; }
  bool Untested() const override { return true; }
  const char* FailureReason() const override { return failure_reason_; }

  bool SetMode(bool on, bool, uint32_t minimum_interval_us) override {
    if (!on) {
      if (initialized_.load(std::memory_order_acquire)) {
        // Told off once (a disabled Update has no wait).
        enabled_ = false;
        max_fps_ = 0;
        AMD::AntiLag2DX12::Update(&context_, false, 0);
      }
      return true;
    }
    if (!EnsureInitialized()) {
      return false;
    }
    // The state goes to the driver with the frame's Update (Sleep, just after this).
    enabled_ = true;
    max_fps_ = minimum_interval_us ? uint32_t(1000000u / minimum_interval_us) : 0;
    return true;
  }

  // The per-frame call goes just before the input is polled: it waits where the driver wants.
  bool Sleep(uint64_t) override {
    return initialized_.load(std::memory_order_acquire) &&
           SUCCEEDED(AMD::AntiLag2DX12::Update(&context_, enabled_, max_fps_));
  }

  void Marker(LatencyMarker marker, uint64_t) override {
    // Once the frame's main rendering has been submitted, before the FSR 3 Present (needed with
    // frame generation, harmless otherwise): the submission is made before the present is
    // called, so this is where it is sent from. (Untested.)
    if (marker == LatencyMarker::kPresentStart && initialized_.load(std::memory_order_acquire)) {
      AMD::AntiLag2DX12::MarkEndOfFrameRendering(&context_);
    }
  }

  // The frame generation swap chain AMD's proxy makes (null: it is going): its private data holds
  // the context, which the proxy's thread calls SetFrameGenFrameType through, and is given only
  // once Initialize has succeeded (a failed Initialize releases the interface, which that thread
  // must not find). The pointer is not owned: the presenter clears it before the swap chain goes.
  void SetSwapChain(IDXGISwapChain* swap_chain) {
    std::lock_guard lock(swap_chain_mutex_);
    swap_chain_ = swap_chain;
    PublishToSwapChain();
  }

 private:
  explicit AmdAntiLag2(ID3D12Device* device) : device_(device) {}

  void PublishToSwapChain() {
    if (!swap_chain_ || !initialized_.load(std::memory_order_acquire)) {
      return;
    }
    // {5083ae5b-8070-4fca-8ee5-3582dd367d13}: the proxy's key
    // (FrameInterpolationSwapchainDX12.cpp).
    static const GUID kIidAntiLag2Data = {
        0x5083ae5b, 0x8070, 0x4fca, {0x8e, 0xe5, 0x35, 0x82, 0xdd, 0x36, 0x7d, 0x13}};
    struct AntiLag2Data {
      AMD::AntiLag2DX12::Context* context;
      bool enabled;
    } data = {&context_, true};
    swap_chain_->SetPrivateData(kIidAntiLag2Data, sizeof(data), &data);
  }

  bool EnsureInitialized() {
    if (initialized_.load(std::memory_order_acquire)) {
      return true;
    }
    if (initialize_failed_) {
      return false;
    }
    const HRESULT result = AMD::AntiLag2DX12::Initialize(&context_, device_.Get());
    if (result != S_OK) {
      REXLOG_INFO("Low latency: Anti-Lag 2 isn't available on this device (0x{:08X})",
                  uint32_t(result));
      initialize_failed_ = true;
      failure_reason_ = result == E_HANDLE ? "NO AMD DRIVER" : "NOT SUPPORTED";
      return false;
    }
    initialized_.store(true, std::memory_order_release);
    std::lock_guard lock(swap_chain_mutex_);
    PublishToSwapChain();
    return true;
  }

  Microsoft::WRL::ComPtr<ID3D12Device> device_;
  AMD::AntiLag2DX12::Context context_;
  // Set by the update thread, read by the others.
  std::atomic<bool> initialized_{false};
  std::mutex swap_chain_mutex_;
  IDXGISwapChain* swap_chain_ = nullptr;
  // (The update thread's.)
  bool initialize_failed_ = false;
  const char* failure_reason_ = "NOT SUPPORTED";
  bool enabled_ = false;
  uint32_t max_fps_ = 0;
};

}  // namespace

void SetAntiLagPrivateData(IDXGISwapChain* swap_chain, LowLatencyBackend* backend) {
  AmdAntiLag2* anti_lag = dynamic_cast<AmdAntiLag2*>(backend);
  if (!anti_lag) {
    return;
  }
  anti_lag->SetSwapChain(swap_chain);
}

std::shared_ptr<LowLatencyBackend> CreateLowLatencyBackend(ID3D12Device* device,
                                                           GraphicsProvider::GpuVendorID vendor,
                                                           const char** why) {
  // Development (low_latency_debug_backend): another vendor's calls, whatever the GPU.
  const std::string forced = REXCVAR_GET(low_latency_debug_backend);
  if (forced == "none") {
    if (why) {
      *why = "TURNED OFF";
    }
    return nullptr;
  }
  if (forced == "nvidia") {
    vendor = GraphicsProvider::GpuVendorID::kNvidia;
  } else if (forced == "amd") {
    vendor = GraphicsProvider::GpuVendorID::kAMD;
  }
  const char* reason = "NOT ON THIS GPU";
  std::shared_ptr<LowLatencyBackend> backend;
  switch (vendor) {
    case GraphicsProvider::GpuVendorID::kNvidia:
      backend = NvapiReflex::Create(device, &reason);
      break;
    case GraphicsProvider::GpuVendorID::kAMD:
      backend = AmdAntiLag2::Create(device, &reason);
      break;
    default:
      break;
  }
  if (!backend && why) {
    *why = reason;
  }
  return backend;
}

}  // namespace d3d12
}  // namespace ui
}  // namespace rex
