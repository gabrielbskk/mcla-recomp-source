/**
 * Frame generation on Direct3D 12 (rexglue-frame-generation.patch).
 *
 * AMD's frame interpolation swap chain (ffx-api's, "the proxy", from
 * amd_fidelityfx_dx12.dll next to the executable) presents and paces: it has
 * its own swap chain on a present queue of its own, and threads that present
 * the generated frame and then the real one, half a frame apart. Everything it
 * presents is composed by the presenter's present callback, from images of its
 * own: the real frame from the guest output image (hdr_refresh's HDR10 output,
 * as without generation), the generated one from its compose (the refresher's
 * owner, from the generated code values and the frame's UI). The proxy's back
 * buffers are left unused while generating.
 *
 * Per guest frame, on the guest output thread right after the frame's work:
 * the overlay is copied (the present callback runs later on the proxy's
 * thread), generation is prepared from the frame's depth and motion vectors,
 * ffxConfigure gives the frame's ID and the callbacks, and the proxy's Present
 * runs the generation callback on this thread: frame generation from the
 * previous frame's HUD-less image to this one's, then the generated frame's
 * compose, both on the proxy's command list for the game queue. Frame IDs go
 * up by one at every present through the proxy; paints that don't generate (the
 * UI thread's, while the guest output thread is silent) turn generation off
 * and have their back buffer copied.
 */

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <string>
#include <thread>
#include <vector>

#include <rex/cvar.h>
#include <rex/filesystem.h>
#include <rex/logging.h>
#include <rex/platform/dynlib.h>
#include <rex/ui/d3d12/d3d12_low_latency.h>
#include <rex/ui/d3d12/d3d12_presenter.h>
#include <rex/ui/d3d12/d3d12_util.h>

#if defined(REX_HAS_FRAME_GENERATION_DX12) && REX_HAS_FRAME_GENERATION_DX12
#include <ffx_api/dx12/ffx_api_dx12.h>
#include <ffx_api/ffx_api.h>
#include <ffx_api/ffx_framegeneration.h>
#endif

REXCVAR_DECLARE(std::string, frame_generation_present);
REXCVAR_DECLARE(int32_t, frame_generation_debug);
REXCVAR_DECLARE(int32_t, frame_generation_debug_fail);
REXCVAR_DECLARE(bool, frame_generation_timing);
REXCVAR_DECLARE(int32_t, frame_generation_dump);
REXCVAR_DECLARE(std::string, frame_generation_dump_path);

namespace rex::ui::d3d12 {

#if defined(REX_HAS_FRAME_GENERATION_DX12) && REX_HAS_FRAME_GENERATION_DX12

namespace {

FfxApiResource FfxResource(ID3D12Resource* resource, uint32_t format, uint32_t state) {
  FfxApiResource result = ffxApiGetResourceDX12(resource, state);
  result.description.format = format;
  return result;
}

void Transition(ID3D12GraphicsCommandList* command_list, ID3D12Resource* resource,
                D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after) {
  if (before == after) {
    return;
  }
  D3D12_RESOURCE_BARRIER barrier = {};
  barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
  barrier.Transition.pResource = resource;
  barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
  barrier.Transition.StateBefore = before;
  barrier.Transition.StateAfter = after;
  command_list->ResourceBarrier(1, &barrier);
}

D3D12_RESOURCE_STATES StateFromFfx(uint32_t state) {
  switch (state) {
    case FFX_API_RESOURCE_STATE_UNORDERED_ACCESS:
      return D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    case FFX_API_RESOURCE_STATE_COPY_SRC:
      return D3D12_RESOURCE_STATE_COPY_SOURCE;
    case FFX_API_RESOURCE_STATE_COPY_DEST:
      return D3D12_RESOURCE_STATE_COPY_DEST;
    case FFX_API_RESOURCE_STATE_RENDER_TARGET:
      return D3D12_RESOURCE_STATE_RENDER_TARGET;
    case FFX_API_RESOURCE_STATE_PRESENT:
      return D3D12_RESOURCE_STATE_PRESENT;
    default:
      return D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE |
             D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
  }
}

}  // namespace

struct D3D12Presenter::FrameGeneration {
  // ffx-api.
  PfnFfxCreateContext create = nullptr;
  PfnFfxDestroyContext destroy = nullptr;
  PfnFfxConfigure configure = nullptr;
  PfnFfxDispatch dispatch = nullptr;
  rex::platform::DynamicLibrary library;

  // The proxy's ffx-api context, while the swap chain is the proxy.
  ffxContext swap_chain_context = nullptr;
  Microsoft::WRL::ComPtr<IDXGISwapChain4> swap_chain;

  // The frame generation context, made on a worker thread (it takes a while),
  // for a size: the guest output's (generation's) and the render's.
  enum class ContextState { kNone, kCreating, kReady, kFailed };
  std::atomic<ContextState> context_state{ContextState::kNone};
  std::thread context_thread;
  ffxContext context = nullptr;
  uint32_t context_width = 0;
  uint32_t context_height = 0;
  uint32_t context_render_width = 0;
  uint32_t context_render_height = 0;

  // Whether the presenter's callbacks are on the proxy (from then on, every
  // present through it is configured, with the next frame ID), and whether
  // generation is on there.
  bool callbacks_configured = false;
  bool generation_enabled = false;
  uint64_t next_frame_id = 1;
  // The next generation has no history (the first, after one skipped).
  bool reset_next = true;
  uint64_t last_generated_refresh = 0;

  // Generated frames, per frame ID % 2: their code values (R16G16B16A16_FLOAT,
  // UAV) and their compose (kGuestOutputFormat, kGuestOutputInternalState), both
  // at the generation size.
  static constexpr uint32_t kGeneratedCount = 2;
  std::array<Microsoft::WRL::ComPtr<ID3D12Resource>, kGeneratedCount> generated;
  std::array<Microsoft::WRL::ComPtr<ID3D12Resource>, kGeneratedCount> generated_display;
  uint32_t generated_width = 0;
  uint32_t generated_height = 0;
  uint32_t generated_display_width = 0;
  uint32_t generated_display_height = 0;

  // The overlay, copied for the present callback (B8G8R8A8, the swap chain's
  // size, PIXEL_SHADER_RESOURCE): the UI thread may draw into its layers again
  // before the proxy's thread composes.
  std::array<Microsoft::WRL::ComPtr<ID3D12Resource>, 2> overlay_snapshots;
  uint32_t overlay_snapshot_width = 0;
  uint32_t overlay_snapshot_height = 0;
  uint32_t next_overlay_snapshot = 0;

  // What the present callback composes for a frame ID (% kRecordCount). Written
  // by the painting thread before the proxy's Present; the proxy's
  // synchronization orders the callback's reads after it.
  static constexpr uint32_t kRecordCount = 8;
  struct Record {
    uint64_t frame_id = 0;
    // The app drew into the proxy's back buffer (a paint without generation):
    // copied.
    bool back_buffer = true;
    Microsoft::WRL::ComPtr<ID3D12Resource> real;
    Microsoft::WRL::ComPtr<ID3D12Resource> generated;
    Microsoft::WRL::ComPtr<ID3D12Resource> overlay;
    // Set by the generation callback if generation failed: the real frame is
    // shown in its place.
    std::atomic<bool> generation_failed{false};
    GuestOutputPaintFlow flow;
    GuestOutputPaintFlow generated_flow;
    uint64_t refresh_number = 0;
    float ui_levels[4] = {};
  };
  std::array<Record, kRecordCount> records;
  // Shader-visible: per record, the real frame's, the generated frame's and the
  // overlay's SRVs.
  Microsoft::WRL::ComPtr<ID3D12DescriptorHeap> view_heap;
  // The proxy's real buffer for each callback (generated, real), written at
  // the callback (RTVs are read when bound).
  Microsoft::WRL::ComPtr<ID3D12DescriptorHeap> rtv_heap;

  // For the generation callback, inside the proxy's Present on the painting
  // thread.
  FrameGenerationInputs* current_inputs = nullptr;
  uint64_t current_frame_id = 0;
  bool current_generate = false;
  bool current_reset = false;

  // Each failure logged once.
  bool prepare_failure_logged = false;
  bool configure_failure_logged = false;
  bool dispatch_failure_logged = false;
  // The present interval last logged (UINT32_MAX: none yet), and the
  // tearing choice taken at connection (frame_generation_present, read on the
  // UI thread).
  uint32_t logged_sync_interval = UINT32_MAX;
  bool tearing = false;
  // Guest frames in a row painted without generation; after many, the context
  // (hundreds of MB at 4K) is released until generation can run again.
  uint32_t frames_without_generation = 0;
  // Development (frame_generation_timing): GPU timestamps around generation
  // and its compose, per frame ID % kTimingSlots, read back two frames later.
  static constexpr uint32_t kTimingSlots = 4;
  Microsoft::WRL::ComPtr<ID3D12QueryHeap> timing_heap;
  Microsoft::WRL::ComPtr<ID3D12Resource> timing_readback;
  std::array<bool, kTimingSlots> timing_pending = {};
  double timing_sum_ms = 0.0;
  uint32_t timing_count = 0;

  // frame_generation_dump (development): the next frames' real and generated
  // images (the guest output's size, HDR10 codes), read back after the GPU is
  // done with them.
  struct Dump {
    std::array<Microsoft::WRL::ComPtr<ID3D12Resource>, 2> buffers;  // real, generated
    std::array<D3D12_PLACED_SUBRESOURCE_FOOTPRINT, 2> footprints = {};
    std::array<UINT64, 2> sizes = {};
    uint64_t submission = 0;
    uint64_t frame_id = 0;
    uint64_t refresh_number = 0;
    bool generated = false;
    bool pending = false;
  };
  std::array<Dump, 4> dumps;
  int32_t dump_last_request = 0;
  int32_t dump_left = 0;
  // The dump the generation callback copies into, or UINT32_MAX.
  uint32_t current_dump = UINT32_MAX;

  bool Load() {
    std::filesystem::path path =
        rex::filesystem::GetExecutableFolder() / "amd_fidelityfx_dx12.dll";
    if (!library.Load(path, rex::platform::SymbolResolution::kImmediate)) {
      REXLOG_WARN("D3D12Presenter: frame generation: amd_fidelityfx_dx12.dll isn't next to the "
                  "executable");
      return false;
    }
    create = library.GetSymbol<PfnFfxCreateContext>("ffxCreateContext");
    destroy = library.GetSymbol<PfnFfxDestroyContext>("ffxDestroyContext");
    configure = library.GetSymbol<PfnFfxConfigure>("ffxConfigure");
    dispatch = library.GetSymbol<PfnFfxDispatch>("ffxDispatch");
    if (!create || !destroy || !configure || !dispatch) {
      REXLOG_WARN("D3D12Presenter: frame generation: amd_fidelityfx_dx12.dll lacks the ffx-api "
                  "entry points");
      create = nullptr;
      return false;
    }
    return true;
  }

  void JoinContextThread() {
    if (context_thread.joinable()) {
      context_thread.join();
    }
  }

  void DestroyContext() {
    JoinContextThread();
    if (context) {
      destroy(&context, nullptr);
      context = nullptr;
    }
    context_state.store(ContextState::kNone, std::memory_order_relaxed);
    context_width = context_height = 0;
    context_render_width = context_render_height = 0;
  }
};

void D3D12Presenter::FrameGenerationDeleter::operator()(FrameGeneration* frame_generation) const {
  delete frame_generation;
}

bool D3D12Presenter::CreateFrameGenerationSwapChain(
    HWND hwnd, DXGI_SWAP_CHAIN_DESC1& desc,
    Microsoft::WRL::ComPtr<IDXGISwapChain1>& swap_chain_out) {
  if (!frame_generation_wanted()) {
    // The connection is as without frame generation: UI overlay painting isn't
    // forced.
    SetFrameGenerationPresentingFromUIThread(false);
    return false;
  }
  if (!frame_generation_) {
    std::unique_ptr<FrameGeneration, FrameGenerationDeleter> frame_generation(
        new FrameGeneration);
    if (!frame_generation->Load()) {
      SetFrameGenerationUnavailable("FidelityFX's Direct3D 12 runtime can't be loaded");
      SetFrameGenerationPresentingFromUIThread(false);
      return false;
    }
    ID3D12Device* device = provider_.GetDevice();
    D3D12_DESCRIPTOR_HEAP_DESC heap_desc = {};
    heap_desc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    heap_desc.NumDescriptors = FrameGeneration::kRecordCount * 3;
    heap_desc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    D3D12_DESCRIPTOR_HEAP_DESC rtv_heap_desc = {};
    rtv_heap_desc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    rtv_heap_desc.NumDescriptors = 2;
    if (FAILED(device->CreateDescriptorHeap(&heap_desc,
                                            IID_PPV_ARGS(&frame_generation->view_heap))) ||
        FAILED(device->CreateDescriptorHeap(&rtv_heap_desc,
                                            IID_PPV_ARGS(&frame_generation->rtv_heap)))) {
      REXLOG_ERROR("D3D12Presenter: frame generation: couldn't create its descriptor heaps");
      SetFrameGenerationUnavailable("its descriptor heaps couldn't be created");
      SetFrameGenerationPresentingFromUIThread(false);
      return false;
    }
    frame_generation_ = std::move(frame_generation);
  }
  FrameGeneration& fg = *frame_generation_;
  IDXGISwapChain4* swap_chain = nullptr;
  ffxCreateContextDescFrameGenerationSwapChainForHwndDX12 create_desc = {};
  create_desc.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_FRAMEGENERATIONSWAPCHAIN_FOR_HWND_DX12;
  create_desc.swapchain = &swap_chain;
  create_desc.hwnd = hwnd;
  create_desc.desc = &desc;
  create_desc.fullscreenDesc = nullptr;
  create_desc.dxgiFactory = provider_.GetDXGIFactory();
  create_desc.gameQueue = provider_.GetDirectQueue();
  ffxReturnCode_t result = fg.create(&fg.swap_chain_context, &create_desc.header, nullptr);
  if (result != FFX_API_RETURN_OK || !swap_chain) {
    REXLOG_ERROR("D3D12Presenter: frame generation: AMD's swap chain couldn't be created ({}); "
                 "presenting without it",
                 result);
    fg.swap_chain_context = nullptr;
    SetFrameGenerationUnavailable("AMD's swap chain couldn't be created");
    SetFrameGenerationPresentingFromUIThread(false);
    return false;
  }
  fg.swap_chain.Attach(swap_chain);
  // AMD's Anti-Lag 2 (untested): its proxy tells the driver which presents are generated.
  SetAntiLagPrivateData(swap_chain, low_latency_.get());
  // The guest's UI separated in SDR too (generation needs the scene without it).
  SetFrameGenerationUiSeparation(true);
  // Read here, on the UI thread (it takes effect at the next connection).
  fg.tearing = REXCVAR_GET(frame_generation_present) == "tearing";
  if (!fg.timing_heap) {
    ID3D12Device* timing_device = provider_.GetDevice();
    D3D12_QUERY_HEAP_DESC query_desc = {};
    query_desc.Type = D3D12_QUERY_HEAP_TYPE_TIMESTAMP;
    query_desc.Count = FrameGeneration::kTimingSlots * 2;
    D3D12_RESOURCE_DESC readback_desc = {};
    readback_desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
    readback_desc.Width = FrameGeneration::kTimingSlots * 2 * sizeof(uint64_t);
    readback_desc.Height = 1;
    readback_desc.DepthOrArraySize = 1;
    readback_desc.MipLevels = 1;
    readback_desc.SampleDesc.Count = 1;
    readback_desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    if (FAILED(timing_device->CreateQueryHeap(&query_desc, IID_PPV_ARGS(&fg.timing_heap))) ||
        FAILED(timing_device->CreateCommittedResource(
            &util::kHeapPropertiesReadback, D3D12_HEAP_FLAG_NONE, &readback_desc,
            D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&fg.timing_readback)))) {
      fg.timing_heap.Reset();
      fg.timing_readback.Reset();
    }
  }
  fg.callbacks_configured = false;
  fg.generation_enabled = false;
  fg.reset_next = true;
  if (FAILED(fg.swap_chain.As(&swap_chain_out))) {
    DestroyFrameGenerationSwapChain();
    SetFrameGenerationUnavailable("AMD's swap chain isn't usable");
    SetFrameGenerationPresentingFromUIThread(false);
    return false;
  }
  // AMD's pacing: sleeping in its spin wait, and waiting on its fence with
  // WaitForSingleObject when far from the target.
  FfxApiSwapchainFramePacingTuning pacing = {};
  pacing.safetyMarginInMs = 0.1f;
  pacing.varianceFactor = 0.1f;
  pacing.allowHybridSpin = true;
  pacing.hybridSpinTime = 2;
  pacing.allowWaitForSingleObjectOnFence = true;
  ffxConfigureDescFrameGenerationSwapChainKeyValueDX12 pacing_desc = {};
  pacing_desc.header.type = FFX_API_CONFIGURE_DESC_TYPE_FRAMEGENERATIONSWAPCHAIN_KEYVALUE_DX12;
  pacing_desc.key = FFX_API_CONFIGURE_FG_SWAPCHAIN_KEY_FRAMEPACINGTUNING;
  pacing_desc.ptr = &pacing;
  fg.configure(&fg.swap_chain_context, &pacing_desc.header);
  REXLOG_INFO("D3D12Presenter: frame generation: presenting through AMD's frame interpolation "
              "swap chain");
  SetFrameGenerationPresentingFromUIThread(true);
  return true;
}

bool D3D12Presenter::SupportsFrameGeneration() const {
  // Loaded (and kept), not only looked for: a DLL whose imports fail (the Visual C++ runtime
  // missing) is there and unusable.
  std::string error;
  switch (rex::platform::CheckLoadable(
      rex::filesystem::GetExecutableFolder() / "amd_fidelityfx_dx12.dll", &error)) {
    case rex::platform::LibraryCheck::kLoads:
      return true;
    case rex::platform::LibraryCheck::kFailed:
      REXLOG_WARN(
          "D3D12Presenter: frame generation: amd_fidelityfx_dx12.dll is there but doesn't "
          "load ({})",
          error);
      frame_generation_unsupported_reason_ = "RUNTIME NOT LOADED";
      return false;
    default:
      frame_generation_unsupported_reason_ = "NO FIDELITYFX RUNTIME";
      return false;
  }
}

const char* D3D12Presenter::FrameGenerationUnsupportedReason() const {
  return frame_generation_unsupported_reason_;
}

void D3D12Presenter::AwaitFrameGenerationPresents() {
  if (!frame_generation_ || !frame_generation_->swap_chain_context) {
    return;
  }
  FrameGeneration& fg = *frame_generation_;
  ffxDispatchDescFrameGenerationSwapChainWaitForPresentsDX12 wait_desc = {};
  wait_desc.header.type = FFX_API_DISPATCH_DESC_TYPE_FRAMEGENERATIONSWAPCHAIN_WAIT_FOR_PRESENTS_DX12;
  fg.dispatch(&fg.swap_chain_context, &wait_desc.header);
}

void D3D12Presenter::DestroyFrameGenerationSwapChain() {
  if (!frame_generation_ || !frame_generation_->swap_chain_context) {
    return;
  }
  FrameGeneration& fg = *frame_generation_;
  AwaitFrameGenerationPresents();
  if (fg.callbacks_configured && fg.context) {
    // Generation off and the callbacks dropped before the proxy goes.
    ffxConfigureDescFrameGeneration config = {};
    config.header.type = FFX_API_CONFIGURE_DESC_TYPE_FRAMEGENERATION;
    config.swapChain = fg.swap_chain.Get();
    config.frameGenerationEnabled = false;
    config.frameID = fg.next_frame_id++;
    fg.configure(&fg.context, &config.header);
  }
  fg.callbacks_configured = false;
  fg.generation_enabled = false;
  for (FrameGeneration::Record& record : fg.records) {
    record.frame_id = 0;
    record.real.Reset();
    record.generated.Reset();
    record.overlay.Reset();
  }
  // Low latency: the Anti-Lag 2 context goes no more to the swap chain that is going.
  SetAntiLagPrivateData(nullptr, low_latency_.get());
  fg.swap_chain.Reset();
  fg.destroy(&fg.swap_chain_context, nullptr);
  fg.swap_chain_context = nullptr;
  SetFrameGenerationUiSeparation(false);
}

void D3D12Presenter::ShutdownFrameGeneration() {
  if (!frame_generation_) {
    return;
  }
  // The swap chain (the paint context's reference) is released by the caller
  // first.
  DestroyFrameGenerationSwapChain();
  frame_generation_->DestroyContext();
  frame_generation_.reset();
}

bool D3D12Presenter::FrameGenerationSwapChainActive() const {
  return frame_generation_ && frame_generation_->swap_chain_context;
}

D3D12Presenter::FrameGenerationInputs* D3D12Presenter::GetFrameGenerationInputs(
    uint32_t mailbox_index, uint32_t width, uint32_t height) {
  // Where generation can't run (its context, a failed dispatch), no inputs: the
  // depth copy, the vectors, the HUD-less writes and the UI separation stop.
  if (!frame_generation_wanted() || !frame_generation_ || !frame_generation_->swap_chain_context ||
      mailbox_index >= frame_generation_inputs_.size() || !width || !height) {
    return nullptr;
  }
  FrameGenerationInputs& inputs = frame_generation_inputs_[mailbox_index];
  inputs = FrameGenerationInputs();
  inputs.generation_width = width;
  inputs.generation_height = height;
  // Where the frame is shown smaller than the guest output (the window is
  // smaller), generated at exactly the size it's shown at, so the generated
  // frame is presented 1:1 and the real one is scaled to the same size. (The
  // swap chain's size is the UI thread's; a reconnect racing with this takes
  // effect a frame later.)
  if (paint_context_.swap_chain_width && paint_context_.swap_chain_height) {
    GuestOutputPaintConfig config;
    config.SetEffect(GuestOutputPaintConfig::Effect::kBilinear);
    const GuestOutputPaintFlow flow = GetGuestOutputPaintFlow(
        GetRefreshingGuestOutputProperties(mailbox_index), paint_context_.swap_chain_width,
        paint_context_.swap_chain_height, D3D12_REQ_TEXTURE2D_U_OR_V_DIMENSION,
        D3D12_REQ_TEXTURE2D_U_OR_V_DIMENSION, config);
    if (flow.effect_count) {
      const std::pair<uint32_t, uint32_t>& shown = flow.effect_output_sizes[flow.effect_count - 1];
      if (shown.first < width && shown.second < height) {
        inputs.generation_width = shown.first;
        inputs.generation_height = shown.second;
      }
    }
  }
  return &inputs;
}

void D3D12Presenter::PrepareBackBufferPresentForFrameGeneration() {
  if (!frame_generation_ || !frame_generation_->swap_chain_context) {
    return;
  }
  FrameGeneration& fg = *frame_generation_;
  if (!fg.callbacks_configured ||
      fg.context_state.load(std::memory_order_acquire) != FrameGeneration::ContextState::kReady ||
      !fg.context) {
    // The proxy's own callback copies the back buffer.
    return;
  }
  const uint64_t frame_id = fg.next_frame_id++;
  FrameGeneration::Record& record = fg.records[frame_id % FrameGeneration::kRecordCount];
  record.back_buffer = true;
  record.real.Reset();
  record.generated.Reset();
  record.overlay.Reset();
  record.frame_id = frame_id;
  fg.current_generate = false;
  ffxConfigureDescFrameGeneration config = {};
  config.header.type = FFX_API_CONFIGURE_DESC_TYPE_FRAMEGENERATION;
  config.swapChain = fg.swap_chain.Get();
  config.presentCallback = [](ffxCallbackDescFrameGenerationPresent* params,
                              void* user_context) -> ffxReturnCode_t {
    return static_cast<D3D12Presenter*>(user_context)->FrameGenerationPresentCallback(params);
  };
  config.presentCallbackUserContext = this;
  config.frameGenerationCallback = [](ffxDispatchDescFrameGeneration* params,
                                      void* user_context) -> ffxReturnCode_t {
    return static_cast<D3D12Presenter*>(user_context)->FrameGenerationDispatchCallback(params);
  };
  config.frameGenerationCallbackUserContext = this;
  config.frameGenerationEnabled = false;
  config.frameID = frame_id;
  fg.configure(&fg.context, &config.header);
  fg.generation_enabled = false;
  fg.reset_next = true;
}

void D3D12Presenter::DropFrameGenerationCallbacks() {
  FrameGeneration& fg = *frame_generation_;
  if (!fg.callbacks_configured || !fg.context || !fg.swap_chain) {
    fg.callbacks_configured = false;
    fg.generation_enabled = false;
    return;
  }
  // Generation off, the proxy's own callback back (it drains its presents).
  ffxConfigureDescFrameGeneration config = {};
  config.header.type = FFX_API_CONFIGURE_DESC_TYPE_FRAMEGENERATION;
  config.swapChain = fg.swap_chain.Get();
  config.frameGenerationEnabled = false;
  config.frameID = fg.next_frame_id++;
  fg.configure(&fg.context, &config.header);
  fg.callbacks_configured = false;
  fg.generation_enabled = false;
  fg.reset_next = true;
}

bool D3D12Presenter::EnsureFrameGenerationContext(uint32_t width, uint32_t height,
                                                  uint32_t render_width, uint32_t render_height) {
  FrameGeneration& fg = *frame_generation_;
  FrameGeneration::ContextState state = fg.context_state.load(std::memory_order_acquire);
  const bool same_size = fg.context_width == width && fg.context_height == height &&
                         fg.context_render_width == render_width &&
                         fg.context_render_height == render_height;
  if (same_size) {
    if (state == FrameGeneration::ContextState::kReady) {
      fg.JoinContextThread();
      return true;
    }
    if (state != FrameGeneration::ContextState::kNone) {
      // Being made, or failed for this size.
      return false;
    }
  }
  if (state == FrameGeneration::ContextState::kCreating) {
    return false;
  }
  // A new size: the old context goes first.
  if (fg.context) {
    DropFrameGenerationCallbacks();
    AwaitFrameGenerationPresents();
    paint_context_.paint_submission_tracker.AwaitAllSubmissionsCompletion();
  }
  fg.DestroyContext();
  fg.context_width = width;
  fg.context_height = height;
  fg.context_render_width = render_width;
  fg.context_render_height = render_height;
  if (REXCVAR_GET(frame_generation_debug_fail) == 1) {
    REXLOG_ERROR(
        "D3D12Presenter: frame generation: its context was made to fail "
        "(frame_generation_debug_fail)");
    fg.context_state.store(FrameGeneration::ContextState::kFailed, std::memory_order_release);
    SetFrameGenerationUnavailable("its context couldn't be created");
    return false;
  }
  fg.context_state.store(FrameGeneration::ContextState::kCreating, std::memory_order_relaxed);
  ID3D12Device* device = provider_.GetDevice();
  FrameGeneration* fg_pointer = &fg;
  fg.context_thread = std::thread([this, fg_pointer, device, width, height, render_width,
                                   render_height]() {
    ffxCreateBackendDX12Desc backend = {};
    backend.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_BACKEND_DX12;
    backend.device = device;
    ffxCreateContextDescFrameGeneration create_desc = {};
    create_desc.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_FRAMEGENERATION;
    create_desc.header.pNext = &backend.header;
    // As the vectors and depth are (src/graphics/frame_generation_fsr.h).
    create_desc.flags = FFX_FRAMEGENERATION_ENABLE_DEPTH_INVERTED;
    create_desc.displaySize = {width, height};
    create_desc.maxRenderSize = {render_width, render_height};
    // The code values the refresher writes (hdr_refresh_fg.cs.xesl).
    create_desc.backBufferFormat = FFX_API_SURFACE_FORMAT_R16G16B16A16_FLOAT;
    const auto start = std::chrono::steady_clock::now();
    ffxContext context = nullptr;
    ffxReturnCode_t result = fg_pointer->create(&context, &create_desc.header, nullptr);
    const double ms = std::chrono::duration<double, std::milli>(
                          std::chrono::steady_clock::now() - start)
                          .count();
    if (result != FFX_API_RETURN_OK || !context) {
      REXLOG_ERROR("D3D12Presenter: frame generation: its context couldn't be created for {}x{} "
                   "(render {}x{}): {}",
                   width, height, render_width, render_height, result);
      fg_pointer->context_state.store(FrameGeneration::ContextState::kFailed,
                                      std::memory_order_release);
      SetFrameGenerationUnavailable("its context couldn't be created");
      return;
    }
    fg_pointer->context = context;
    REXLOG_INFO("D3D12Presenter: frame generation: ready for {}x{} (render {}x{}) after {:.0f} ms",
                width, height, render_width, render_height, ms);
    fg_pointer->context_state.store(FrameGeneration::ContextState::kReady,
                                    std::memory_order_release);
  });
  return false;
}

bool D3D12Presenter::EnsureFrameGenerationImages(uint32_t width, uint32_t height,
                                                 uint32_t generation_width,
                                                 uint32_t generation_height) {
  FrameGeneration& fg = *frame_generation_;
  if (fg.generated[0] && fg.generated_width == generation_width &&
      fg.generated_height == generation_height && fg.generated_display_width == width &&
      fg.generated_display_height == height) {
    return true;
  }
  // Nothing may still be reading the old ones.
  AwaitFrameGenerationPresents();
  paint_context_.paint_submission_tracker.AwaitAllSubmissionsCompletion();
  for (uint32_t i = 0; i < FrameGeneration::kGeneratedCount; ++i) {
    fg.generated[i].Reset();
    fg.generated_display[i].Reset();
  }
  for (FrameGeneration::Record& record : fg.records) {
    record.generated.Reset();
  }
  fg.generated_width = fg.generated_height = 0;
  fg.generated_display_width = fg.generated_display_height = 0;
  ID3D12Device* device = provider_.GetDevice();
  D3D12_RESOURCE_DESC desc = {};
  desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
  desc.Width = generation_width;
  desc.Height = generation_height;
  desc.DepthOrArraySize = 1;
  desc.MipLevels = 1;
  desc.SampleDesc.Count = 1;
  desc.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
  desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
  for (uint32_t i = 0; i < FrameGeneration::kGeneratedCount; ++i) {
    desc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    if (FAILED(device->CreateCommittedResource(
            &util::kHeapPropertiesDefault, provider_.GetHeapFlagCreateNotZeroed(), &desc,
            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&fg.generated[i])))) {
      REXLOG_ERROR("D3D12Presenter: frame generation: couldn't create its {}x{} images",
                   generation_width, generation_height);
      return false;
    }
    desc.Format = kGuestOutputFormat;
    if (FAILED(device->CreateCommittedResource(
            &util::kHeapPropertiesDefault, provider_.GetHeapFlagCreateNotZeroed(), &desc,
            kGuestOutputInternalState, nullptr, IID_PPV_ARGS(&fg.generated_display[i])))) {
      REXLOG_ERROR("D3D12Presenter: frame generation: couldn't create its {}x{} images",
                   generation_width, generation_height);
      fg.generated[i].Reset();
      return false;
    }
  }
  fg.generated_width = generation_width;
  fg.generated_height = generation_height;
  fg.generated_display_width = width;
  fg.generated_display_height = height;
  return true;
}

bool D3D12Presenter::PaintWithFrameGeneration(bool execute_ui_drawers, PaintResult& result_out) {
  FrameGeneration& fg = *frame_generation_;
  if (!fg.swap_chain_context || execute_ui_drawers) {
    return false;
  }

  // The guest frame (a paint as without generation takes the same one again).
  GuestOutputProperties properties;
  GuestOutputPaintConfig paint_config;
  uint32_t mailbox_index = UINT32_MAX;
  Microsoft::WRL::ComPtr<ID3D12Resource> real;
  {
    std::unique_lock<std::mutex> consumer_lock(
        ConsumeGuestOutput(mailbox_index, &properties, &paint_config));
    if (mailbox_index != UINT32_MAX) {
      real = guest_output_resources_[mailbox_index].second;
    }
  }
  if (!real || properties.hdr.is_pq != paint_context_.swap_chain_hdr) {
    return false;
  }
  const D3D12_RESOURCE_DESC real_desc = real->GetDesc();
  const uint32_t width = uint32_t(real_desc.Width);
  const uint32_t height = real_desc.Height;
  FrameGenerationInputs& inputs = frame_generation_inputs_[mailbox_index];
  // Generated only right after the frame's own work (its inputs are then
  // current), once per guest frame.
  bool generate = InGuestOutputThreadPaint() && inputs.valid && inputs.hudless &&
                  inputs.depth && inputs.motion_vectors && inputs.compose_generated &&
                  properties.refresh_number != fg.last_generated_refresh;
  uint32_t render_width = fg.context_render_width;
  uint32_t render_height = fg.context_render_height;
  uint32_t generation_width = fg.context_width;
  uint32_t generation_height = fg.context_height;
  if (inputs.valid && inputs.depth) {
    render_width = inputs.render_width;
    render_height = inputs.render_height;
    generation_width = inputs.generation_width;
    generation_height = inputs.generation_height;
  }
  // Many frames in a row with nothing to generate from (FXAA or the PWL ramp in
  // SDR, menus drawn alone): the context goes until generation can run again.
  if (generate) {
    fg.frames_without_generation = 0;
  } else if (fg.context && ++fg.frames_without_generation >= 1200) {
    DropFrameGenerationCallbacks();
    AwaitFrameGenerationPresents();
    paint_context_.paint_submission_tracker.AwaitAllSubmissionsCompletion();
    fg.DestroyContext();
    fg.frames_without_generation = 0;
    REXLOG_INFO("D3D12Presenter: frame generation: its context released (nothing to generate "
                "from for 1200 frames)");
    return false;
  }
  if (!generate && !fg.context) {
    return false;
  }
  if (!render_width || !render_height || !generation_width || !generation_height ||
      !EnsureFrameGenerationContext(generation_width, generation_height, render_width,
                                    render_height)) {
    // Until the context is there, presented as without generation.
    return false;
  }
  if (generate && !EnsureFrameGenerationImages(width, height, generation_width,
                                               generation_height)) {
    generate = false;
  }
  WriteFrameGenerationDumps(false);
  fg.current_dump = UINT32_MAX;
  ReadFrameGenerationTimings();
  {
    const int32_t request = REXCVAR_GET(frame_generation_dump);
    if (request != fg.dump_last_request) {
      fg.dump_last_request = request;
      fg.dump_left = std::max(int32_t(0), request);
    }
    if (fg.dump_left > 0 && InGuestOutputThreadPaint()) {
      for (uint32_t i = 0; i < uint32_t(fg.dumps.size()); ++i) {
        if (!fg.dumps[i].pending) {
          fg.current_dump = i;
          break;
        }
      }
    }
  }

  const uint64_t frame_id = fg.next_frame_id++;
  const uint32_t record_index = uint32_t(frame_id % FrameGeneration::kRecordCount);
  FrameGeneration::Record& record = fg.records[record_index];
  const uint32_t generated_index = uint32_t(frame_id % FrameGeneration::kGeneratedCount);
  record.back_buffer = false;
  record.real = real;
  record.generated = generate ? fg.generated_display[generated_index] : real;
  record.generation_failed.store(false, std::memory_order_relaxed);
  record.refresh_number = properties.refresh_number;
  // Bilinear (the effects with intermediate images aren't done in the present
  // callback); in SDR with the dither as set.
  paint_config.SetEffect(GuestOutputPaintConfig::Effect::kBilinear);
  if (paint_context_.swap_chain_hdr) {
    paint_config.SetDither(false);
  }
  record.flow = GetGuestOutputPaintFlow(properties, paint_context_.swap_chain_width,
                                        paint_context_.swap_chain_height,
                                        D3D12_REQ_TEXTURE2D_U_OR_V_DIMENSION,
                                        D3D12_REQ_TEXTURE2D_U_OR_V_DIMENSION, paint_config);
  // The generated frame is at the generation size.
  GuestOutputProperties generated_properties = properties;
  generated_properties.frontbuffer_width = generation_width;
  generated_properties.frontbuffer_height = generation_height;
  record.generated_flow = GetGuestOutputPaintFlow(
      generated_properties, paint_context_.swap_chain_width, paint_context_.swap_chain_height,
      D3D12_REQ_TEXTURE2D_U_OR_V_DIMENSION, D3D12_REQ_TEXTURE2D_U_OR_V_DIMENSION, paint_config);
  HdrOutputState hdr_state = GetHdrOutputState();
  record.ui_levels[0] = hdr_state.sdr_white_nits;
  record.ui_levels[1] = hdr_state.sdr_pure_gamma_2_2 ? 1.0f : 0.0f;

  ID3D12Device* device = provider_.GetDevice();
  D3D12_CPU_DESCRIPTOR_HANDLE view_heap_cpu = fg.view_heap->GetCPUDescriptorHandleForHeapStart();
  D3D12_SHADER_RESOURCE_VIEW_DESC srv_desc = {};
  srv_desc.Format = kGuestOutputFormat;
  srv_desc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
  srv_desc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
  srv_desc.Texture2D.MipLevels = 1;
  device->CreateShaderResourceView(
      record.real.Get(), &srv_desc, provider_.OffsetViewDescriptor(view_heap_cpu, record_index * 3));
  device->CreateShaderResourceView(record.generated.Get(), &srv_desc,
                                   provider_.OffsetViewDescriptor(view_heap_cpu,
                                                                  record_index * 3 + 1));

  // The paint's command list: the overlay's copy and generation's
  // preparation.
  UINT64 current_paint_submission = paint_context_.paint_submission_tracker.GetCurrentSubmission();
  UINT64 command_allocator_count = UINT64(paint_context_.command_allocators.size());
  if (current_paint_submission >= command_allocator_count) {
    paint_context_.paint_submission_tracker.AwaitSubmissionCompletion(current_paint_submission -
                                                                      command_allocator_count);
  }
  ID3D12CommandAllocator* command_allocator =
      paint_context_.command_allocators[current_paint_submission % command_allocator_count].Get();
  command_allocator->Reset();
  ID3D12GraphicsCommandList* command_list = paint_context_.command_list.Get();
  command_list->Reset(command_allocator, nullptr);

  record.overlay.Reset();
  const uint32_t overlay_layer = ui_overlay_published_.load(std::memory_order_acquire);
  if (IsUIOverlayActive() && overlay_layer < UIOverlay::kLayerCount &&
      ui_overlay_.layers[overlay_layer] && ui_overlay_.width == paint_context_.swap_chain_width &&
      ui_overlay_.height == paint_context_.swap_chain_height) {
    if (fg.overlay_snapshot_width != ui_overlay_.width ||
        fg.overlay_snapshot_height != ui_overlay_.height || !fg.overlay_snapshots[0]) {
      AwaitFrameGenerationPresents();
      paint_context_.paint_submission_tracker.AwaitAllSubmissionsCompletion();
      for (FrameGeneration::Record& other : fg.records) {
        other.overlay.Reset();
      }
      D3D12_RESOURCE_DESC snapshot_desc = ui_overlay_.layers[overlay_layer]->GetDesc();
      snapshot_desc.Flags = D3D12_RESOURCE_FLAG_NONE;
      fg.overlay_snapshot_width = fg.overlay_snapshot_height = 0;
      bool created = true;
      for (Microsoft::WRL::ComPtr<ID3D12Resource>& snapshot : fg.overlay_snapshots) {
        snapshot.Reset();
        created = created && SUCCEEDED(device->CreateCommittedResource(
                                 &util::kHeapPropertiesDefault,
                                 provider_.GetHeapFlagCreateNotZeroed(), &snapshot_desc,
                                 D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, nullptr,
                                 IID_PPV_ARGS(&snapshot)));
      }
      if (created) {
        fg.overlay_snapshot_width = ui_overlay_.width;
        fg.overlay_snapshot_height = ui_overlay_.height;
      }
    }
    if (fg.overlay_snapshot_width) {
      ID3D12Resource* layer = ui_overlay_.layers[overlay_layer].Get();
      ID3D12Resource* snapshot = fg.overlay_snapshots[fg.next_overlay_snapshot].Get();
      fg.next_overlay_snapshot = (fg.next_overlay_snapshot + 1) % uint32_t(fg.overlay_snapshots.size());
      Transition(command_list, layer, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,
                 D3D12_RESOURCE_STATE_COPY_SOURCE);
      Transition(command_list, snapshot, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,
                 D3D12_RESOURCE_STATE_COPY_DEST);
      command_list->CopyResource(snapshot, layer);
      Transition(command_list, layer, D3D12_RESOURCE_STATE_COPY_SOURCE,
                 D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
      Transition(command_list, snapshot, D3D12_RESOURCE_STATE_COPY_DEST,
                 D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
      record.overlay = snapshot;
      D3D12_SHADER_RESOURCE_VIEW_DESC overlay_srv_desc = srv_desc;
      overlay_srv_desc.Format = snapshot->GetDesc().Format;
      device->CreateShaderResourceView(
          snapshot, &overlay_srv_desc,
          provider_.OffsetViewDescriptor(view_heap_cpu, record_index * 3 + 2));
    }
  }

  if (generate) {
    ffxDispatchDescFrameGenerationPrepare prepare = {};
    prepare.header.type = FFX_API_DISPATCH_DESC_TYPE_FRAMEGENERATION_PREPARE;
    prepare.frameID = frame_id;
    prepare.commandList = command_list;
    prepare.renderSize = {inputs.render_width, inputs.render_height};
    prepare.jitterOffset = {inputs.jitter[0], inputs.jitter[1]};
    prepare.motionVectorScale = {1.0f, 1.0f};
    prepare.frameTimeDelta = inputs.frame_time_ms;
    prepare.cameraNear = inputs.camera_near;
    prepare.cameraFar = inputs.camera_far;
    prepare.cameraFovAngleVertical = inputs.camera_fov_vertical;
    prepare.viewSpaceToMetersFactor = 1.0f;
    prepare.depth = FfxResource(inputs.depth, FFX_API_SURFACE_FORMAT_R32_FLOAT,
                                FFX_API_RESOURCE_STATE_COMPUTE_READ);
    prepare.motionVectors = FfxResource(inputs.motion_vectors, FFX_API_SURFACE_FORMAT_R16G16_FLOAT,
                                        FFX_API_RESOURCE_STATE_COMPUTE_READ);
    ffxReturnCode_t prepare_result = fg.dispatch(&fg.context, &prepare.header);
    if (prepare_result != FFX_API_RETURN_OK) {
      if (!fg.prepare_failure_logged) {
        fg.prepare_failure_logged = true;
        REXLOG_ERROR("D3D12Presenter: frame generation: its preparation failed ({})",
                     prepare_result);
      }
      generate = false;
      record.generated = real;
    }
  }
  if (!generate && fg.current_dump != UINT32_MAX) {
    if (RecordFrameGenerationDump(command_list, fg.current_dump, frame_id,
                                  properties.refresh_number, real.Get(), nullptr)) {
      fg.dumps[fg.current_dump].submission =
          paint_context_.paint_submission_tracker.GetCurrentSubmission();
    }
    fg.current_dump = UINT32_MAX;
  }
  command_list->Close();
  ID3D12CommandList* execute_command_list = command_list;
  provider_.GetDirectQueue()->ExecuteCommandLists(1, &execute_command_list);
  paint_context_.paint_submission_tracker.NextSubmission();

  // The frame's configuration, then the proxy's Present (which calls the
  // generation callback on this thread).
  fg.current_inputs = &inputs;
  fg.current_frame_id = frame_id;
  fg.current_generate = generate;
  fg.current_reset = fg.reset_next || inputs.reset;
  record.frame_id = frame_id;
  ffxConfigureDescFrameGeneration config = {};
  config.header.type = FFX_API_CONFIGURE_DESC_TYPE_FRAMEGENERATION;
  config.swapChain = fg.swap_chain.Get();
  config.presentCallback = [](ffxCallbackDescFrameGenerationPresent* params,
                              void* user_context) -> ffxReturnCode_t {
    return static_cast<D3D12Presenter*>(user_context)->FrameGenerationPresentCallback(params);
  };
  config.presentCallbackUserContext = this;
  config.frameGenerationCallback = [](ffxDispatchDescFrameGeneration* params,
                                      void* user_context) -> ffxReturnCode_t {
    return static_cast<D3D12Presenter*>(user_context)->FrameGenerationDispatchCallback(params);
  };
  config.frameGenerationCallbackUserContext = this;
  config.frameGenerationEnabled = true;
  config.allowAsyncWorkloads = false;
  // Development views (changing them makes AMD's swap chain drain).
  const int32_t debug = REXCVAR_GET(frame_generation_debug);
  config.flags = debug == 1   ? FFX_FRAMEGENERATION_FLAG_DRAW_DEBUG_TEAR_LINES
                 : debug == 2 ? FFX_FRAMEGENERATION_FLAG_DRAW_DEBUG_VIEW
                              : 0;
  config.onlyPresentGenerated = debug == 3;
  config.frameID = frame_id;
  ffxReturnCode_t configure_result = fg.configure(&fg.context, &config.header);
  if (configure_result != FFX_API_RETURN_OK) {
    if (!fg.configure_failure_logged) {
      fg.configure_failure_logged = true;
      REXLOG_ERROR("D3D12Presenter: frame generation: ffxConfigure failed ({})",
                   configure_result);
    }
  } else {
    fg.callbacks_configured = true;
    fg.generation_enabled = true;
  }
  // Vertical sync unless tearing was chosen: AMD's swap chain presents with
  // SyncInterval 1 and no flags then, or 0 and DXGI_PRESENT_ALLOW_TEARING. (A
  // driver setting that forces vertical sync off overrides it.)
  const UINT sync_interval = fg.tearing ? 0 : 1;
  if (sync_interval != fg.logged_sync_interval) {
    fg.logged_sync_interval = sync_interval;
    REXLOG_INFO("D3D12Presenter: frame generation: presenting with {}",
                sync_interval ? "vertical sync (SyncInterval 1, no flags)"
                              : "tearing (SyncInterval 0, DXGI_PRESENT_ALLOW_TEARING)");
  }
  // Low latency: the guest frame's present is the call into AMD's swap chain (the presents it
  // makes itself, its generated ones too, are on a queue of its own).
  const uint64_t low_latency_frame = LowLatency::CurrentFrameId();
  LowLatency::Marker(LatencyMarker::kPresentStart, low_latency_frame);
  HRESULT present_result = paint_context_.swap_chain->Present(sync_interval, 0);
  LowLatency::Marker(LatencyMarker::kPresentEnd, low_latency_frame);
  paint_context_.present_submission_tracker.NextSubmission();
  fg.current_inputs = nullptr;
  if (generate) {
    fg.last_generated_refresh = properties.refresh_number;
    fg.reset_next = false;
  } else {
    fg.reset_next = true;
  }
  // AMD's Present returns S_OK whatever happened to the device.
  HRESULT removed_reason = device->GetDeviceRemovedReason();
  if (present_result == DXGI_ERROR_DEVICE_RESET || removed_reason == DXGI_ERROR_DEVICE_RESET) {
    result_out = PaintResult::kGpuLostResponsible;
  } else if (present_result == DXGI_ERROR_DEVICE_REMOVED || FAILED(removed_reason)) {
    result_out = PaintResult::kGpuLostExternally;
  } else {
    result_out = SUCCEEDED(present_result) ? PaintResult::kPresented : PaintResult::kNotPresented;
  }
  return true;
}

uint32_t D3D12Presenter::FrameGenerationDispatchCallback(void* params_untyped) {
  auto* params = static_cast<ffxDispatchDescFrameGeneration*>(params_untyped);
  FrameGeneration& fg = *frame_generation_;
  if (!fg.current_generate || !fg.current_inputs || params->frameID != fg.current_frame_id) {
    // Nothing generated for this frame: the present callback shows the real
    // frame in its place.
    FrameGeneration::Record& skipped =
        fg.records[params->frameID % FrameGeneration::kRecordCount];
    if (skipped.frame_id == params->frameID && skipped.generated != skipped.real) {
      skipped.generation_failed.store(true, std::memory_order_release);
    }
    return FFX_API_RETURN_OK;
  }
  FrameGenerationInputs& inputs = *fg.current_inputs;
  FrameGeneration::Record& record = fg.records[params->frameID % FrameGeneration::kRecordCount];
  const uint32_t index = uint32_t(params->frameID % FrameGeneration::kGeneratedCount);
  ID3D12Resource* generated = fg.generated[index].Get();
  ID3D12Resource* display = fg.generated_display[index].Get();
  auto* command_list = static_cast<ID3D12GraphicsCommandList*>(params->commandList);
  ffxDispatchDescFrameGeneration desc = {};
  desc.header.type = FFX_API_DISPATCH_DESC_TYPE_FRAMEGENERATION;
  desc.commandList = command_list;
  desc.presentColor = FfxResource(inputs.hudless, FFX_API_SURFACE_FORMAT_R16G16B16A16_FLOAT,
                                  FFX_API_RESOURCE_STATE_COMPUTE_READ);
  desc.outputs[0] = FfxResource(generated, FFX_API_SURFACE_FORMAT_R16G16B16A16_FLOAT,
                                FFX_API_RESOURCE_STATE_UNORDERED_ACCESS);
  desc.numGeneratedFrames = 1;
  desc.reset = params->reset || fg.current_reset;
  // Code values: the transfer function only steers its luminance heuristics.
  desc.backbufferTransferFunction = FFX_API_BACKBUFFER_TRANSFER_FUNCTION_SRGB;
  desc.minMaxLuminance[0] = 0.0f;
  desc.minMaxLuminance[1] = 1.0f;
  desc.generationRect = {0, 0, int32_t(fg.generated_width), int32_t(fg.generated_height)};
  desc.frameID = params->frameID;
  const uint32_t timing_slot = uint32_t(params->frameID % FrameGeneration::kTimingSlots);
  const bool timing = REXCVAR_GET(frame_generation_timing) && fg.timing_heap &&
                      !fg.timing_pending[timing_slot];
  if (timing) {
    command_list->EndQuery(fg.timing_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, timing_slot * 2);
  }
  ffxReturnCode_t result = REXCVAR_GET(frame_generation_debug_fail) == 2
                               ? FFX_API_RETURN_ERROR
                               : fg.dispatch(&fg.context, &desc.header);
  if (result != FFX_API_RETURN_OK) {
    record.generation_failed.store(true, std::memory_order_release);
    if (!fg.dispatch_failure_logged) {
      fg.dispatch_failure_logged = true;
      REXLOG_ERROR("D3D12Presenter: frame generation: its dispatch failed ({})", result);
    }
    // Not again in this session: no inputs from the next frame, and the next
    // connection is AMD's swap chain's no more.
    SetFrameGenerationUnavailable("a generation failed on the GPU's queue");
    return FFX_API_RETURN_OK;
  }
  Transition(command_list, generated, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
             D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
  const bool composed =
      inputs.compose_generated(inputs.compose_generated_context, command_list, generated, display);
  Transition(command_list, generated, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
             D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
  if (timing) {
    command_list->EndQuery(fg.timing_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP, timing_slot * 2 + 1);
    command_list->ResolveQueryData(fg.timing_heap.Get(), D3D12_QUERY_TYPE_TIMESTAMP,
                                   timing_slot * 2, 2, fg.timing_readback.Get(),
                                   timing_slot * 2 * sizeof(uint64_t));
    fg.timing_pending[timing_slot] = true;
  }
  if (!composed) {
    record.generation_failed.store(true, std::memory_order_release);
  } else if (fg.current_dump != UINT32_MAX) {
    // Copied before the proxy's present queue reads them (it waits for this
    // list); complete once the next paint's submission is (after this list
    // in the queue).
    if (RecordFrameGenerationDump(command_list, fg.current_dump, params->frameID,
                                  record.refresh_number, record.real.Get(), display)) {
      fg.dumps[fg.current_dump].submission =
          paint_context_.paint_submission_tracker.GetCurrentSubmission();
    }
    fg.current_dump = UINT32_MAX;
  }
  return FFX_API_RETURN_OK;
}

void D3D12Presenter::ReadFrameGenerationTimings() {
  FrameGeneration& fg = *frame_generation_;
  if (!fg.timing_readback) {
    return;
  }
  // Two frames back is done: the proxy's Present waits for the previous
  // frame's generation before running this frame's.
  const uint32_t slot = uint32_t((fg.next_frame_id + FrameGeneration::kTimingSlots - 2) %
                                 FrameGeneration::kTimingSlots);
  if (!fg.timing_pending[slot]) {
    return;
  }
  fg.timing_pending[slot] = false;
  uint64_t* timestamps = nullptr;
  D3D12_RANGE range = {slot * 2 * sizeof(uint64_t), (slot * 2 + 2) * sizeof(uint64_t)};
  if (FAILED(fg.timing_readback->Map(0, &range, reinterpret_cast<void**>(&timestamps)))) {
    return;
  }
  const uint64_t begin = timestamps[slot * 2];
  const uint64_t end = timestamps[slot * 2 + 1];
  D3D12_RANGE written = {0, 0};
  fg.timing_readback->Unmap(0, &written);
  UINT64 frequency = 0;
  if (end <= begin || FAILED(provider_.GetDirectQueue()->GetTimestampFrequency(&frequency)) ||
      !frequency) {
    return;
  }
  fg.timing_sum_ms += double(end - begin) * 1000.0 / double(frequency);
  if (++fg.timing_count >= 300) {
    REXLOG_INFO("D3D12Presenter: frame generation: GPU {:.3f} ms per generated frame "
                "(generation and its compose, {}x{}, mean of {})",
                fg.timing_sum_ms / fg.timing_count, fg.generated_width, fg.generated_height,
                fg.timing_count);
    fg.timing_sum_ms = 0.0;
    fg.timing_count = 0;
  }
}

bool D3D12Presenter::RecordFrameGenerationDump(ID3D12GraphicsCommandList* command_list,
                                               uint32_t dump_index, uint64_t frame_id,
                                               uint64_t refresh_number, ID3D12Resource* real,
                                               ID3D12Resource* generated) {
  FrameGeneration& fg = *frame_generation_;
  FrameGeneration::Dump& dump = fg.dumps[dump_index];
  ID3D12Device* device = provider_.GetDevice();
  ID3D12Resource* sources[] = {real, generated};
  for (uint32_t i = 0; i < 2; ++i) {
    if (!sources[i]) {
      continue;
    }
    const D3D12_RESOURCE_DESC desc = sources[i]->GetDesc();
    UINT64 size = 0;
    device->GetCopyableFootprints(&desc, 0, 1, 0, &dump.footprints[i], nullptr, nullptr, &size);
    if (size != dump.sizes[i] || !dump.buffers[i]) {
      D3D12_RESOURCE_DESC buffer_desc = {};
      buffer_desc.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER;
      buffer_desc.Width = size;
      buffer_desc.Height = 1;
      buffer_desc.DepthOrArraySize = 1;
      buffer_desc.MipLevels = 1;
      buffer_desc.SampleDesc.Count = 1;
      buffer_desc.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
      dump.sizes[i] = 0;
      dump.buffers[i].Reset();
      if (FAILED(device->CreateCommittedResource(&util::kHeapPropertiesReadback,
                                                 D3D12_HEAP_FLAG_NONE, &buffer_desc,
                                                 D3D12_RESOURCE_STATE_COPY_DEST, nullptr,
                                                 IID_PPV_ARGS(&dump.buffers[i])))) {
        REXLOG_ERROR("D3D12Presenter: frame_generation_dump: no readback buffer");
        fg.dump_left = 0;
        return false;
      }
      dump.sizes[i] = size;
    }
  }
  for (uint32_t i = 0; i < 2; ++i) {
    if (!sources[i]) {
      continue;
    }
    const D3D12_PLACED_SUBRESOURCE_FOOTPRINT& footprint = dump.footprints[i];
    Transition(command_list, sources[i], kGuestOutputInternalState,
               D3D12_RESOURCE_STATE_COPY_SOURCE);
    D3D12_TEXTURE_COPY_LOCATION dest = {};
    dest.pResource = dump.buffers[i].Get();
    dest.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
    dest.PlacedFootprint = footprint;
    D3D12_TEXTURE_COPY_LOCATION source = {};
    source.pResource = sources[i];
    source.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    command_list->CopyTextureRegion(&dest, 0, 0, 0, &source, nullptr);
    Transition(command_list, sources[i], D3D12_RESOURCE_STATE_COPY_SOURCE,
               kGuestOutputInternalState);
  }
  dump.frame_id = frame_id;
  dump.refresh_number = refresh_number;
  dump.generated = generated != nullptr;
  dump.pending = true;
  --fg.dump_left;
  return true;
}

void D3D12Presenter::WriteFrameGenerationDumps(bool all) {
  FrameGeneration& fg = *frame_generation_;
  for (FrameGeneration::Dump& dump : fg.dumps) {
    if (!dump.pending) {
      continue;
    }
    if (all) {
      paint_context_.paint_submission_tracker.AwaitSubmissionCompletion(dump.submission);
    } else if (paint_context_.paint_submission_tracker.GetCompletedSubmission() < dump.submission) {
      continue;
    }
    dump.pending = false;
    for (uint32_t i = 0; i < 2; ++i) {
      if (i && !dump.generated) {
        continue;
      }
      const D3D12_PLACED_SUBRESOURCE_FOOTPRINT& footprint = dump.footprints[i];
      const uint32_t width = footprint.Footprint.Width;
      const uint32_t height = footprint.Footprint.Height;
      const UINT row_pitch = footprint.Footprint.RowPitch;
      const std::string path = REXCVAR_GET(frame_generation_dump_path) + "/fg_dump_d3d12_" +
                               std::to_string(dump.frame_id) + "_r" +
                               std::to_string(dump.refresh_number) +
                               (i ? "_generated" : (dump.generated ? "_real" : "_real_only")) +
                               "_" + std::to_string(width) + "x" + std::to_string(height) +
                               ".ppm";
      void* mapping = nullptr;
      D3D12_RANGE read_range = {0, SIZE_T(dump.sizes[i])};
      if (FAILED(dump.buffers[i]->Map(0, &read_range, &mapping))) {
        continue;
      }
      FILE* file = nullptr;
      if (fopen_s(&file, path.c_str(), "wb")) {
        file = nullptr;
      }
      if (file) {
        // HDR10 codes, R in the low bits.
        std::fprintf(file, "P6 %u %u 1023\n", width, height);
        std::vector<uint8_t> row(size_t(width) * 6);
        for (uint32_t y = 0; y < height; ++y) {
          const uint32_t* pixels = reinterpret_cast<const uint32_t*>(
              static_cast<const uint8_t*>(mapping) + footprint.Offset + size_t(y) * row_pitch);
          for (uint32_t x = 0; x < width; ++x) {
            const uint32_t p = pixels[x];
            const uint32_t c[] = {p & 1023, (p >> 10) & 1023, (p >> 20) & 1023};
            for (uint32_t k = 0; k < 3; ++k) {
              row[size_t(x) * 6 + k * 2] = uint8_t(c[k] >> 8);
              row[size_t(x) * 6 + k * 2 + 1] = uint8_t(c[k]);
            }
          }
          std::fwrite(row.data(), 1, row.size(), file);
        }
        std::fclose(file);
        REXLOG_INFO("D3D12Presenter: frame_generation_dump: {}", path);
      } else {
        REXLOG_ERROR("D3D12Presenter: frame_generation_dump: can't write {}", path);
      }
      D3D12_RANGE written_range = {0, 0};
      dump.buffers[i]->Unmap(0, &written_range);
    }
  }
}

uint32_t D3D12Presenter::FrameGenerationPresentCallback(void* params_untyped) {
  auto* params = static_cast<ffxCallbackDescFrameGenerationPresent*>(params_untyped);
  FrameGeneration& fg = *frame_generation_;
  auto* command_list = static_cast<ID3D12GraphicsCommandList*>(params->commandList);
  auto* output = static_cast<ID3D12Resource*>(params->outputSwapChainBuffer.resource);
  const D3D12_RESOURCE_STATES output_state = StateFromFfx(params->outputSwapChainBuffer.state);
  const uint32_t record_index = uint32_t(params->frameID % FrameGeneration::kRecordCount);
  FrameGeneration::Record& record = fg.records[record_index];
  bool from_back_buffer = record.frame_id != params->frameID || record.back_buffer ||
                          !record.real || !record.flow.effect_count;
  bool show_generated = false;
  if (!from_back_buffer) {
    show_generated = params->isGeneratedFrame &&
                     !record.generation_failed.load(std::memory_order_acquire) &&
                     record.generated;
  }
  if (from_back_buffer && !(record.frame_id == params->frameID && record.back_buffer)) {
    // No record for this present (shouldn't happen): black, as a paint without
    // the guest output clears to, rather than a back buffer nothing drew into.
    D3D12_CPU_DESCRIPTOR_HANDLE clear_rtv = provider_.OffsetRTVDescriptor(
        fg.rtv_heap->GetCPUDescriptorHandleForHeapStart(), params->isGeneratedFrame ? 0 : 1);
    D3D12_RENDER_TARGET_VIEW_DESC clear_rtv_desc = {};
    clear_rtv_desc.Format = output->GetDesc().Format;
    clear_rtv_desc.ViewDimension = D3D12_RTV_DIMENSION_TEXTURE2D;
    provider_.GetDevice()->CreateRenderTargetView(output, &clear_rtv_desc, clear_rtv);
    Transition(command_list, output, output_state, D3D12_RESOURCE_STATE_RENDER_TARGET);
    const float black[] = {0.0f, 0.0f, 0.0f, 1.0f};
    command_list->ClearRenderTargetView(clear_rtv, black, 0, nullptr);
    Transition(command_list, output, D3D12_RESOURCE_STATE_RENDER_TARGET, output_state);
    return FFX_API_RETURN_OK;
  }
  if (from_back_buffer) {
    // A paint without generation: the back buffer the app drew.
    auto* back_buffer = static_cast<ID3D12Resource*>(params->currentBackBuffer.resource);
    const D3D12_RESOURCE_STATES back_buffer_state = StateFromFfx(params->currentBackBuffer.state);
    Transition(command_list, back_buffer, back_buffer_state, D3D12_RESOURCE_STATE_COPY_SOURCE);
    Transition(command_list, output, output_state, D3D12_RESOURCE_STATE_COPY_DEST);
    command_list->CopyResource(output, back_buffer);
    Transition(command_list, back_buffer, D3D12_RESOURCE_STATE_COPY_SOURCE, back_buffer_state);
    Transition(command_list, output, D3D12_RESOURCE_STATE_COPY_DEST, output_state);
    return FFX_API_RETURN_OK;
  }

  const D3D12_RESOURCE_DESC output_desc = output->GetDesc();
  Transition(command_list, output, output_state, D3D12_RESOURCE_STATE_RENDER_TARGET);
  D3D12_CPU_DESCRIPTOR_HANDLE rtv = provider_.OffsetRTVDescriptor(
      fg.rtv_heap->GetCPUDescriptorHandleForHeapStart(), params->isGeneratedFrame ? 0 : 1);
  D3D12_RENDER_TARGET_VIEW_DESC rtv_desc = {};
  rtv_desc.Format = output_desc.Format;
  rtv_desc.ViewDimension = D3D12_RTV_DIMENSION_TEXTURE2D;
  provider_.GetDevice()->CreateRenderTargetView(output, &rtv_desc, rtv);
  command_list->OMSetRenderTargets(1, &rtv, TRUE, nullptr);
  D3D12_VIEWPORT viewport = {0.0f, 0.0f, float(output_desc.Width), float(output_desc.Height),
                             0.0f, 1.0f};
  command_list->RSSetViewports(1, &viewport);
  D3D12_RECT scissor = {0, 0, LONG(output_desc.Width), LONG(output_desc.Height)};
  command_list->RSSetScissorRects(1, &scissor);
  ID3D12DescriptorHeap* view_heap = fg.view_heap.Get();
  command_list->SetDescriptorHeaps(1, &view_heap);
  const D3D12_GPU_DESCRIPTOR_HANDLE view_heap_gpu = view_heap->GetGPUDescriptorHandleForHeapStart();

  // The frame, scaled bilinearly as without generation (a generated frame
  // from the generation size, which is the window's or the guest output's).
  const bool hdr = output_desc.Format == kSwapChainFormatHdr10;
  const bool generated_size = show_generated && record.generated != record.real &&
                              record.generated_flow.effect_count;
  if (show_generated && record.generated != record.real && !generated_size) {
    show_generated = false;
  }
  const GuestOutputPaintFlow& flow = generated_size ? record.generated_flow : record.flow;
  const size_t effect = flow.effect_count - 1;
  ID3D12PipelineState* final_pipeline =
      hdr ? guest_output_paint_final_hdr10_pipeline_.Get()
          : guest_output_paint_final_pipelines_[size_t(flow.effects[effect])].Get();
  if (!final_pipeline) {
    final_pipeline = guest_output_paint_final_pipelines_[size_t(
                                                            GuestOutputPaintEffect::kBilinear)]
                         .Get();
  }
  command_list->SetPipelineState(final_pipeline);
  command_list->SetGraphicsRootSignature(
      guest_output_paint_root_signatures_[kGuestOutputPaintRootSignatureIndexBilinear].Get());
  command_list->SetGraphicsRootDescriptorTable(
      UINT(GuestOutputPaintRootParameter::kSource),
      provider_.OffsetViewDescriptor(view_heap_gpu, record_index * 3 + (show_generated ? 1 : 0)));
  GuestOutputPaintRectangleConstants rect;
  const float x_to_ndc = 2.0f / viewport.Width;
  const float y_to_ndc = 2.0f / viewport.Height;
  rect.x = -1.0f + float(flow.output_x) * x_to_ndc;
  rect.y = 1.0f - float(flow.output_y) * y_to_ndc;
  rect.width = float(flow.effect_output_sizes[effect].first) * x_to_ndc;
  rect.height = -float(flow.effect_output_sizes[effect].second) * y_to_ndc;
  command_list->SetGraphicsRoot32BitConstants(UINT(GuestOutputPaintRootParameter::kRectangle),
                                              sizeof(rect) / sizeof(uint32_t), &rect, 0);
  BilinearConstants bilinear;
  bilinear.Initialize(flow, effect);
  command_list->SetGraphicsRoot32BitConstants(UINT(GuestOutputPaintRootParameter::kEffectConstants),
                                              sizeof(bilinear) / sizeof(uint32_t), &bilinear, 0);
  command_list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
  command_list->DrawInstanced(4, 1, 0, 0);
  if (flow.letterbox_clear_rectangle_count) {
    D3D12_RECT clear_rects[GuestOutputPaintFlow::kMaxClearRectangles];
    for (size_t i = 0; i < flow.letterbox_clear_rectangle_count; ++i) {
      const GuestOutputPaintFlow::ClearRectangle& clear = flow.letterbox_clear_rectangles[i];
      clear_rects[i] = {LONG(clear.x), LONG(clear.y), LONG(clear.x + clear.width),
                        LONG(clear.y + clear.height)};
    }
    const float black[] = {0.0f, 0.0f, 0.0f, 1.0f};
    command_list->ClearRenderTargetView(rtv, black, UINT(flow.letterbox_clear_rectangle_count),
                                        clear_rects);
  }

  // The presenter's UI, as copied at the frame's paint.
  if (record.overlay) {
    command_list->SetPipelineState(hdr ? hdr_ui_composite_pipeline_.Get()
                                       : ui_overlay_composite_pipeline_.Get());
    command_list->SetGraphicsRootDescriptorTable(
        UINT(GuestOutputPaintRootParameter::kSource),
        provider_.OffsetViewDescriptor(view_heap_gpu, record_index * 3 + 2));
    GuestOutputPaintRectangleConstants whole = {};
    whole.x = -1.0f;
    whole.y = 1.0f;
    whole.width = 2.0f;
    whole.height = -2.0f;
    command_list->SetGraphicsRoot32BitConstants(UINT(GuestOutputPaintRootParameter::kRectangle),
                                                sizeof(whole) / sizeof(uint32_t), &whole, 0);
    if (hdr) {
      command_list->SetGraphicsRoot32BitConstants(
          UINT(GuestOutputPaintRootParameter::kEffectConstants), 4, record.ui_levels, 0);
    }
    command_list->DrawInstanced(4, 1, 0, 0);
  }
  Transition(command_list, output, D3D12_RESOURCE_STATE_RENDER_TARGET, output_state);
  if (!params->isGeneratedFrame) {
    LogPresentFromCallback(record.refresh_number);
  }
  return FFX_API_RETURN_OK;
}

#else  // REX_HAS_FRAME_GENERATION_DX12

struct D3D12Presenter::FrameGeneration {};

void D3D12Presenter::FrameGenerationDeleter::operator()(FrameGeneration* frame_generation) const {
  delete frame_generation;
}
bool D3D12Presenter::CreateFrameGenerationSwapChain(HWND, DXGI_SWAP_CHAIN_DESC1&,
                                                    Microsoft::WRL::ComPtr<IDXGISwapChain1>&) {
  return false;
}
bool D3D12Presenter::SupportsFrameGeneration() const {
  return false;
}
const char* D3D12Presenter::FrameGenerationUnsupportedReason() const {
  return "NOT BUILT";
}
void D3D12Presenter::AwaitFrameGenerationPresents() {}
bool D3D12Presenter::FrameGenerationSwapChainActive() const {
  return false;
}
void D3D12Presenter::DestroyFrameGenerationSwapChain() {}
void D3D12Presenter::ShutdownFrameGeneration() {}
bool D3D12Presenter::PaintWithFrameGeneration(bool, PaintResult&) { return false; }
void D3D12Presenter::PrepareBackBufferPresentForFrameGeneration() {}
D3D12Presenter::FrameGenerationInputs* D3D12Presenter::GetFrameGenerationInputs(uint32_t,
                                                                                 uint32_t,
                                                                                 uint32_t) {
  return nullptr;
}

#endif  // REX_HAS_FRAME_GENERATION_DX12

}  // namespace rex::ui::d3d12
