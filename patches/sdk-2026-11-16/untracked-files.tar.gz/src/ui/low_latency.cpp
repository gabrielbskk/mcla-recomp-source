/**
 * Low latency: the frame bookkeeping, the policy and the cvars; the vendors' calls are the
 * backends' (d3d12/d3d12_low_latency.cpp, vulkan/vulkan_low_latency.cpp).
 * See include/rex/ui/low_latency.h.
 */

#include <array>
#include <atomic>
#include <bit>
#include <chrono>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <utility>

#include <rex/cvar.h>
#include <rex/logging.h>
#include <rex/platform.h>
#include <rex/ui/low_latency.h>
#include <rex/ui/presenter.h>

REXCVAR_DEFINE_STRING(low_latency, "auto", "UI/Presenter",
                      "The GPU vendor's latency reducer (NVIDIA Reflex, AMD Anti-Lag 2) while the "
                      "game runs: off, on, or boost (Reflex's On + Boost: the GPU clocks stay "
                      "high); auto is on for NVIDIA Reflex and off for AMD Anti-Lag 2 "
                      "(untested; rexglue-low-latency.patch). Frame generation turns it on "
                      "whatever this says (low_latency_frame_generation)")
    .allowed({"auto", "off", "on", "boost"})
    .lifecycle(rex::cvar::Lifecycle::kHotReload);

REXCVAR_DEFINE_STRING(low_latency_frame_generation, "auto", "UI/Presenter",
                      "auto: the reducer is on whenever frame generation is on (most games do "
                      "this; the delay frame generation adds is the one it takes back); off: "
                      "low_latency alone decides, for troubleshooting (config file only)")
    .allowed({"auto", "off"})
    .lifecycle(rex::cvar::Lifecycle::kHotReload);

REXCVAR_DEFINE_STRING(low_latency_limiter, "auto", "UI/Presenter",
                      "Who holds the frame rate to the game's limit while the reducer is on: "
                      "fork: the game's own limiter, which waits at the end of the frame; driver: "
                      "the driver (the reducer's minimum frame interval), which waits before the "
                      "frame's input is read, so the input is that much newer when the frame is "
                      "shown; auto: the driver, where its reducer has been tested and frame "
                      "generation is off (with it on the game's own is as good or better), else "
                      "the game's own")
    .allowed({"auto", "fork", "driver"})
    .lifecycle(rex::cvar::Lifecycle::kHotReload);

REXCVAR_DEFINE_BOOL(low_latency_device_extensions, !REX_PLATFORM_PS5, "UI/Presenter",
                    "Vulkan: ask for the vendor's low latency extensions (VK_NV_low_latency2 and "
                    "its dependency VK_KHR_present_id on an NVIDIA GPU, VK_AMD_anti_lag on an AMD "
                    "one) when the device is created, if the device has them. Off by default on "
                    "the PS5, whose host turns it on when the game starts with low_latency on or "
                    "boost, or with frame generation chosen, so that the console's device stays as "
                    "it was otherwise")
    .lifecycle(rex::cvar::Lifecycle::kInitOnly);

REXCVAR_DEFINE_STRING(low_latency_debug_backend, "auto", "UI/Presenter",
                      "Development: auto chooses the reducer from the GPU's vendor and what its "
                      "driver offers; nvidia or amd tries that one's calls whatever the GPU "
                      "(on the other vendor's GPU they find no driver, which is how the guards "
                      "are tested); none turns it off")
    .allowed({"auto", "nvidia", "amd", "none"})
    .lifecycle(rex::cvar::Lifecycle::kRequiresRestart);

REXCVAR_DEFINE_INT32(
    low_latency_debug, 0, "UI/Presenter",
    "Development, bits: 1 sends the markers even while the reducer is off (a "
    "latency tool such as PresentMon then reads them), 2 logs the driver's own "
    "report of the latest frames every 300 frames (and sends the markers), 4 "
    "leaves the frame of each Vulkan submission to the driver's own rules (no "
    "explicit attribution), 8 adds the driver's times of the newest frames, "
    "from each one's simulation start, to the report, 16 logs every 300 frames "
    "how the frames' ids were paired (timer passes with no swap between, swaps "
    "with no frame, written-off frames), 32 makes the driver refuse the mode twice "
    "and 64 always (to test the retry and the fall back to the game's limiter), 128 "
    "makes every wait before a frame 300 ms longer (to test giving the reducer up and "
    "trying again), 256 with 128 only two of every three (long, long, short)")
    .range(0, 511)
    .lifecycle(rex::cvar::Lifecycle::kHotReload);

namespace rex {
namespace ui {

namespace {

// Ids of the frames that got an engine timer pass (are marked): the id at id & mask. The
// update thread sets it, the GPU command thread and the presenters read it.
constexpr size_t kMarkedFrames = 256;
std::array<std::atomic<uint64_t>, kMarkedFrames> g_marked_frames;

// The swap packets written so far (VdSwap, the render thread; the high 32 bits) and the frames
// the update thread started that have no swap yet (the low 32), in one word: a frame's id is
// both plus one, read at once.
constexpr uint64_t kSwapUnit = uint64_t(1) << 32;
constexpr uint64_t kPendingMask = kSwapUnit - 1;
std::atomic<uint64_t> g_frame_counts{0};
// A frame that has no swap for this long was lost (the render thread stalled, or the update ran
// without a frame): the count of such frames is written off, so ids don't stay shifted.
constexpr int64_t kStaleFrameNs = 250'000'000;
// A frame still waiting at every timer pass for this long is written off too (see
// OnFrameStart): an update thread that is a frame ahead of the swaps (the usual state while the
// game is CPU-bound) looks the same, so that takes longer to call a loss.
constexpr int64_t kLeadHeldNs = 500'000'000;
// The first passes after the driver took the mode make no wait: it has seen no markers of the
// frames before (none were sent while the reducer was off), and on Vulkan its first wait then
// took about 100 ms, once or twice (4 of 7 re-arms after a give-up; none of 6 with two passes).
constexpr uint32_t kWarmupPasses = 2;
std::atomic<int64_t> g_last_swap_ns{0};
std::atomic<uint64_t> g_swaps_executed{0};  // the GPU command thread's swap packets
std::atomic<uint32_t> g_frame_limit{0};

int64_t SteadyNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
             std::chrono::steady_clock::now().time_since_epoch())
      .count();
}

// How the ids were paired (low_latency_debug 16): the update thread counts the first three, the
// render thread the last.
std::atomic<int64_t> g_last_frame_start_ns{0};
std::atomic<uint64_t> g_stat_passes_without_swap{0};  // a pass with no swap since the last one
std::atomic<uint64_t> g_stat_healed{0};               // a pending frame written off after a swap
std::atomic<uint64_t> g_stat_stale{0};                // pending frames written off after a stall
std::atomic<uint64_t> g_stat_swaps_without_frame{0};  // a swap in play (not a logo) with no frame
std::atomic<uint64_t> g_stat_duplicate_ids{0};        // an id that was already started
// The swaps written when the previous timer pass started, and the thread that makes the passes
// (the one the game's hook found); the swaps' thread, to check it is another one.
uint64_t g_swaps_at_previous_pass = ~uint64_t(0);
// The update thread's, for telling a lost frame from a lead: bit 0 of the history is set when
// the latest pass found no frame waiting; the first pass of the run of passes that have found
// one waiting (0: none now), and whether the 32 passes before it found one waiting at most once.
uint32_t g_pass_idle_history = ~uint32_t(0);
int64_t g_pending_since_ns = 0;
bool g_pending_run_idle = false;
std::atomic<uint64_t> g_stat_held{0};  // of the written-off frames, those after a held lead
std::atomic<size_t> g_frame_thread_hash{0};
std::atomic<uint32_t> g_swaps_on_frame_thread{0};

std::mutex g_mutex;
std::shared_ptr<LowLatencyBackend> g_backend;
std::string g_unavailable_why;
std::atomic<bool> g_have_backend{false};

// What the driver has been told, and what the policy asks now. The driver is told nothing until
// the policy has turned the reducer on (a user's own driver-level setting stays as it is).
struct Applied {
  bool on = false;
  bool boost = false;
  uint32_t interval_us = 0;
  bool failed = false;  // given up for now: no calls, the game's own limiter
  // A refused mode is asked for again a second later, twice more, before it counts as refused.
  uint32_t refusals = 0;
  int64_t retry_after_ns = 0;
  // A reducer given up on because its waits took too long (a window that isn't presenting, a
  // driver that blocks) is tried again after a pause that doubles with each failure: 5 s, 10 s,
  // 20 s, 40 s, at most a minute. Three long waits among the last eight give it up; for 5 s
  // after a new start one is enough; the pause starts again at 5 s after 30 s without a
  // give-up.
  int64_t rearm_at_ns = 0;  // 0: not coming back
  int64_t rearmed_at_ns = 0;
  uint32_t give_ups = 0;
  uint32_t warmup = 0;             // passes left before the first wait after the mode went on
  uint32_t long_wait_history = 0;  // bit set: the wait (the latest in bit 0) was a long one
  // The warning for a long wait is given at most every 5 s, with the count of the ones since.
  int64_t long_wait_logged_ns = 0;
  uint32_t long_waits_unlogged = 0;
};
Applied g_applied;                         // the update thread's
std::string g_failed_why;                  // (g_mutex)
std::atomic<uint32_t> g_backend_epoch{0};  // changes with the backend: the mode is told again
std::atomic<bool> g_active{false};         // on, with the driver told
std::atomic<bool> g_driver_limits{false};
std::atomic<bool> g_forced{false};
std::atomic<bool> g_markers{false};              // markers go out (active, or low_latency_debug)
std::atomic<bool> g_explicit_attribution{true};  // submissions carry their frame (Vulkan)

thread_local uint64_t t_render_frame = 0;    // the frame the GPU command thread is in (marked)
thread_local bool t_render_started = false;  // its RENDERSUBMIT_START was sent
thread_local uint64_t t_swap_frame = 0;      // the frame it is swapping now (CurrentFrameId)

std::shared_ptr<LowLatencyBackend> Backend() {
  if (!g_have_backend.load(std::memory_order_acquire)) {
    return nullptr;
  }
  std::lock_guard lock(g_mutex);
  return g_backend;
}

bool IsMarked(uint64_t id) {
  return id && g_marked_frames[id % kMarkedFrames].load(std::memory_order_acquire) == id;
}

bool FrameGenerationOn() {
  return rex::cvar::GetFlagByName("frame_generation") != "off" &&
         Presenter::GetFrameGenerationStatus().state !=
             Presenter::FrameGenerationState::kUnavailable;
}

struct Policy {
  bool on = false;
  bool boost = false;
  uint32_t interval_us = 0;
  bool forced = false;
};

// (The settings are read with GetFlagByName, which holds the cvar lock: the menu thread writes
// them.)
Policy Evaluate(const LowLatencyBackend& backend) {
  Policy policy;
  const std::string setting = rex::cvar::GetFlagByName("low_latency");
  bool setting_on = setting == "on" || setting == "boost";
  if (setting == "auto") {
    setting_on = backend.OnByDefault();
  }
  policy.on = setting_on;
  policy.boost = setting == "boost" && backend.SupportsBoost();
  const bool frame_generation_on = FrameGenerationOn();
  if (!policy.on && frame_generation_on &&
      rex::cvar::GetFlagByName("low_latency_frame_generation") == "auto") {
    policy.on = true;
    policy.forced = true;
  }
  const uint32_t limit = g_frame_limit.load(std::memory_order_relaxed);
  if (policy.on && limit && backend.SupportsLimit()) {
    const std::string limiter = rex::cvar::GetFlagByName("low_latency_limiter");
    if (limiter == "driver" || (limiter == "auto" && !backend.Untested() && !frame_generation_on)) {
      policy.interval_us = uint32_t(1000000u / limit);
    }
  }
  return policy;
}

}  // namespace

LowLatency::Status LowLatency::GetStatus() {
  Status status;
  std::shared_ptr<LowLatencyBackend> backend = Backend();
  if (!backend) {
    std::lock_guard lock(g_mutex);
    if (!g_unavailable_why.empty()) {
      status.state = State::kUnavailable;
      status.why = g_unavailable_why;
    }
    return status;
  }
  {
    // The driver refused the mode: unavailable, as if there were no backend.
    std::lock_guard lock(g_mutex);
    if (!g_failed_why.empty()) {
      status.state = State::kUnavailable;
      status.name = backend->Name();
      status.why = g_failed_why;
      status.untested = backend->Untested();
      return status;
    }
  }
  status.state = State::kAvailable;
  status.name = backend->Name();
  status.active = g_active.load(std::memory_order_relaxed);
  status.forced_by_frame_generation = g_forced.load(std::memory_order_relaxed);
  status.boost_available = backend->SupportsBoost();
  status.untested = backend->Untested();
  status.on_by_default = backend->OnByDefault();
  return status;
}

void LowLatency::Attach(std::shared_ptr<LowLatencyBackend> backend) {
  {
    std::lock_guard lock(g_mutex);
    g_backend = std::move(backend);
    g_unavailable_why.clear();
    g_failed_why.clear();
    g_have_backend.store(g_backend != nullptr, std::memory_order_release);
  }
  // The next frame tells the new driver objects the mode.
  g_backend_epoch.fetch_add(1, std::memory_order_acq_rel);
  g_active.store(false, std::memory_order_relaxed);
}

void LowLatency::Detach(const LowLatencyBackend* backend) {
  std::lock_guard lock(g_mutex);
  if (g_backend.get() == backend) {
    g_backend.reset();
    g_have_backend.store(false, std::memory_order_release);
    g_active.store(false, std::memory_order_relaxed);
    g_driver_limits.store(false, std::memory_order_relaxed);
    g_markers.store(false, std::memory_order_relaxed);
  }
}

void LowLatency::SetUnavailable(const char* why) {
  std::lock_guard lock(g_mutex);
  if (!g_backend) {
    g_unavailable_why = why ? why : "";
  }
}

void LowLatency::SetFrameLimit(uint32_t fps) {
  g_frame_limit.store(fps, std::memory_order_relaxed);
}

bool LowLatency::DriverLimits() {
  return g_driver_limits.load(std::memory_order_relaxed);
}

bool LowLatency::WantsVulkanExtensions(uint32_t vendor_id, bool* nvidia, bool* amd) {
  bool want_nvidia = false, want_amd = false;
  if (REXCVAR_GET(low_latency_device_extensions)) {
    const std::string choice = rex::cvar::GetFlagByName("low_latency_debug_backend");
    if (choice != "none") {
      want_nvidia = choice == "nvidia" || (choice == "auto" && vendor_id == 0x10DE);
      want_amd = choice == "amd" || (choice == "auto" && vendor_id == 0x1002);
    }
  }
  if (nvidia) {
    *nvidia = want_nvidia;
  }
  if (amd) {
    *amd = want_amd;
  }
  return want_nvidia || want_amd;
}

namespace {

// Gives the reducer up for now: the driver is told to leave the mode (once, as well as it can),
// the status says why, and the game's own limiter holds the frame rate. With retry, it is asked
// again after a pause (Applied).
void GiveUp(LowLatencyBackend& backend, const char* why, int64_t now_ns, bool retry) {
  g_applied.failed = true;
  g_applied.long_wait_history = 0;
  g_applied.refusals = 0;
  g_applied.retry_after_ns = 0;
  g_applied.rearm_at_ns = 0;
  {
    std::lock_guard lock(g_mutex);
    g_failed_why = why;
  }
  if (g_applied.on) {
    backend.SetMode(false, false, 0);
    g_applied.on = false;
  }
  if (retry) {
    const int64_t pause_s =
        std::min<int64_t>(60, int64_t(5) << std::min<uint32_t>(g_applied.give_ups, 4));
    ++g_applied.give_ups;
    g_applied.rearm_at_ns = now_ns + pause_s * 1'000'000'000;
    REXLOG_WARN("Low latency: {} can't work ({}); asking again in {} s", backend.Name(), why,
                pause_s);
  } else {
    REXLOG_WARN("Low latency: {} can't work ({})", backend.Name(), why);
  }
}

}  // namespace

void LowLatency::OnFrameStart() {
  const size_t thread_hash = std::hash<std::thread::id>()(std::this_thread::get_id());
  if (!g_frame_thread_hash.load(std::memory_order_relaxed)) {
    g_frame_thread_hash.store(thread_hash, std::memory_order_relaxed);
    REXLOG_INFO("Low latency: the frames start on thread {}", thread_hash);
  } else if (g_frame_thread_hash.load(std::memory_order_relaxed) != thread_hash) {
    static bool logged = false;
    if (!logged) {
      logged = true;
      REXLOG_WARN(
          "Low latency: a timer pass from a second thread; the game's hook should pass "
          "one thread's only");
    }
  }
  // The frame's id: the swap packets written so far, the frames started that have no swap yet,
  // and this one. A frame that was lost (an update the render thread merged into the next one,
  // or a stall) is written off, so that the ids don't stay shifted by one. A frame with no swap
  // for a quarter of a second was lost. A frame still waiting after a swap that came since the
  // previous pass may be, but is also what an update thread a frame ahead of the swaps looks
  // like (the usual state when the game is CPU-bound: 85% of the passes at native resolution,
  // uncapped; frames and swaps were one to one), and writing that off shifted the ids instead
  // (11% of the frames lost their markers, and most had another's id): it is written off at
  // once only where frames are normally not waiting (all but one of the 32 passes before the
  // wait began found none: the GPU-bound and capped runs, where it is a merge), and after half a
  // second of waiting at every pass otherwise.
  const int64_t now_ns = SteadyNs();
  uint64_t counts = g_frame_counts.load(std::memory_order_relaxed);
  uint64_t base;
  bool healed, stale, lead_held, no_swap_between, pending_seen;
  int64_t run_start;
  bool run_idle;
  do {
    base = counts;
    healed = stale = lead_held = false;
    const uint64_t swaps = base >> 32;
    pending_seen = (base & kPendingMask) != 0;
    no_swap_between = pending_seen && swaps == g_swaps_at_previous_pass;
    run_start = g_pending_since_ns;
    run_idle = g_pending_run_idle;
    if (!pending_seen) {
      run_start = 0;
    } else if (!run_start) {
      run_start = now_ns;
      // (A merge's own two passes count against it, so a second one within 32 passes is
      // written off after the half second, not at once.)
      run_idle = std::popcount(g_pass_idle_history) >= 31;
    }
    if (pending_seen) {
      if (now_ns - g_last_swap_ns.load(std::memory_order_relaxed) > kStaleFrameNs) {
        base &= ~kPendingMask;
        stale = true;
      } else if (g_swaps_at_previous_pass != ~uint64_t(0) && swaps != g_swaps_at_previous_pass &&
                 run_idle) {
        base &= ~kPendingMask;
        healed = true;
      } else if (now_ns - run_start >= kLeadHeldNs) {
        base &= ~kPendingMask;
        healed = lead_held = true;
      }
    }
  } while (!g_frame_counts.compare_exchange_weak(counts, base + 1, std::memory_order_acq_rel,
                                                 std::memory_order_relaxed));
  g_pass_idle_history = (g_pass_idle_history << 1) | (pending_seen ? 0u : 1u);
  g_pending_since_ns = (healed || stale) ? 0 : run_start;
  g_pending_run_idle = run_idle;
  g_swaps_at_previous_pass = base >> 32;
  g_last_frame_start_ns.store(now_ns, std::memory_order_relaxed);
  g_stat_stale.fetch_add(stale ? 1 : 0, std::memory_order_relaxed);
  g_stat_healed.fetch_add(healed ? 1 : 0, std::memory_order_relaxed);
  g_stat_held.fetch_add(lead_held ? 1 : 0, std::memory_order_relaxed);
  g_stat_passes_without_swap.fetch_add(no_swap_between ? 1 : 0, std::memory_order_relaxed);
  const uint64_t id = (base >> 32) + (base & kPendingMask) + 1;
  // An id that is already started (the pending frames written off: its swap is the next one's):
  // its markers were sent, and are not sent twice.
  const bool duplicate_id = IsMarked(id);
  g_stat_duplicate_ids.fetch_add(duplicate_id ? 1 : 0, std::memory_order_relaxed);
  g_marked_frames[id % kMarkedFrames].store(id, std::memory_order_release);
  std::shared_ptr<LowLatencyBackend> backend = Backend();
  if (!backend) {
    return;
  }
  static uint32_t epoch_seen = 0;
  const uint32_t epoch = g_backend_epoch.load(std::memory_order_acquire);
  if (epoch != epoch_seen) {
    epoch_seen = epoch;
    g_applied = Applied();
    // (A give-up that was under way on the old backend's last pass can have written its reason
    // after Attach cleared it.)
    std::lock_guard lock(g_mutex);
    g_failed_why.clear();
  }
  const Policy policy = Evaluate(*backend);
  const int32_t debug = REXCVAR_GET(low_latency_debug);
  // A reducer given up on for its long waits is tried again after its pause, unless the backend
  // has given up in the meantime (that one is for good, and the status says so).
  if (g_applied.failed && g_applied.rearm_at_ns && now_ns >= g_applied.rearm_at_ns) {
    g_applied.rearm_at_ns = 0;
    if (const char* why = backend->Failed()) {
      GiveUp(*backend, why, now_ns, false);
    } else {
      g_applied.failed = false;
      g_applied.rearmed_at_ns = now_ns;
      g_applied.long_wait_history = 0;
      g_applied.refusals = 0;
      g_applied.retry_after_ns = 0;
      {
        std::lock_guard lock(g_mutex);
        g_failed_why.clear();
      }
      REXLOG_INFO("Low latency: {} tries again", backend->Name());
    }
  }
  if (g_applied.give_ups && !g_applied.failed &&
      now_ns - g_applied.rearmed_at_ns > 30'000'000'000) {
    g_applied.give_ups = 0;
  }
  // The backend itself can have given up (a swapchain made without the latency mode):
  // unavailable, as for a refused mode.
  if (!g_applied.failed) {
    if (const char* why = backend->Failed()) {
      GiveUp(*backend, why, now_ns, false);
    }
  }
  // The policy came back to what the driver has while a refusal was waiting to be asked again
  // (the row was turned off): nothing to ask, and the next refusal counts from one.
  if (g_applied.refusals && g_applied.on == policy.on &&
      (!policy.on ||
       (g_applied.boost == policy.boost && g_applied.interval_us == policy.interval_us))) {
    g_applied.refusals = 0;
    g_applied.retry_after_ns = 0;
  }
  // The driver hears of the mode only once the policy has turned the reducer on (and of every
  // change after that). A refusal is asked again a second later, twice, before it counts.
  if (!g_applied.failed && now_ns >= g_applied.retry_after_ns &&
      (g_applied.on != policy.on || (policy.on && (g_applied.boost != policy.boost ||
                                                   g_applied.interval_us != policy.interval_us)))) {
    if (policy.on != g_applied.on && !g_applied.refusals) {
      REXLOG_INFO("Low latency: {} {}{}{}", backend->Name(), policy.on ? "on" : "off",
                  policy.boost ? ", boost" : "", policy.forced ? " (frame generation)" : "");
    }
    const bool refused_for_test = (debug & 64) || ((debug & 32) && g_applied.refusals < 2);
    if (!refused_for_test && backend->SetMode(policy.on, policy.boost, policy.interval_us)) {
      if (policy.on && !g_applied.on) {
        g_applied.warmup = kWarmupPasses;
      }
      g_applied.on = policy.on;
      g_applied.boost = policy.boost;
      g_applied.interval_us = policy.interval_us;
      if (g_applied.refusals) {
        REXLOG_INFO("Low latency: {} took the mode after {} refusals", backend->Name(),
                    g_applied.refusals);
      }
      g_applied.refusals = 0;
    } else if (++g_applied.refusals < 3) {
      g_applied.retry_after_ns = now_ns + 1'000'000'000;
      REXLOG_WARN("Low latency: {} refused the mode ({}); asking again in a second",
                  backend->Name(), backend->FailureReason());
    } else {
      // Refused three times: the reducer is unavailable (the menu says why) and the game's own
      // limiter holds the frame rate.
      REXLOG_WARN("Low latency: {} refused the mode ({})", backend->Name(),
                  backend->FailureReason());
      GiveUp(*backend, backend->FailureReason(), now_ns, false);
    }
  }
  // Working: asked for, and the driver has the mode (not while a refusal is waiting to be tried
  // again).
  const bool working = policy.on && g_applied.on && !g_applied.failed;
  if (!working) {
    g_applied.long_wait_history = 0;  // (the long waits of an earlier time don't count)
  }
  g_active.store(working, std::memory_order_relaxed);
  g_forced.store(working && policy.forced, std::memory_order_relaxed);
  g_explicit_attribution.store(!(debug & 4), std::memory_order_relaxed);
  const bool markers = working || (debug & 3) != 0;
  g_markers.store(markers, std::memory_order_relaxed);
  static uint64_t sleep_us_total = 0;  // the update thread's: the debug log's average
  static uint32_t sleep_count = 0;
  bool held = false;
  if (working && g_applied.warmup) {
    --g_applied.warmup;
  } else if (working) {
    const auto sleep_start = std::chrono::steady_clock::now();
    held = backend->Sleep(id);
    if (debug & 128) {
      static uint32_t test_wait = 0;
      if (!(debug & 256) || ++test_wait % 3 != 0) {
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
      }
    }
    const int64_t sleep_us = std::chrono::duration_cast<std::chrono::microseconds>(
                                 std::chrono::steady_clock::now() - sleep_start)
                                 .count();
    sleep_us_total += uint64_t(sleep_us);
    ++sleep_count;
    // The driver waits for the moment it picks. A wait over a quarter of a second (or four
    // frame intervals of the frame-rate limit), three of the last eight, is not pacing: the
    // window isn't presenting, or the driver blocks. The reducer is given up, and the game's
    // own limiter holds the frame rate until it is tried again. (Measured when the call
    // returns: Vulkan's wait is bounded, so it does; Reflex's NvAPI_D3D_Sleep can't be
    // cancelled, and one that never returns is not covered.)
    const int64_t limit_us = std::max<int64_t>(250'000, 4 * int64_t(g_applied.interval_us));
    const bool long_wait = sleep_us > limit_us;
    g_applied.long_wait_history = (g_applied.long_wait_history << 1) | (long_wait ? 1u : 0u);
    if (long_wait) {
      held = false;
      ++g_applied.long_waits_unlogged;
      if (now_ns - g_applied.long_wait_logged_ns >= 5'000'000'000) {
        REXLOG_WARN(
            "Low latency: {}'s wait before the frame took {} ms{}", backend->Name(),
            sleep_us / 1000,
            g_applied.long_waits_unlogged > 1
                ? fmt::format(" ({} long waits since the last line)", g_applied.long_waits_unlogged)
                : std::string());
        g_applied.long_wait_logged_ns = now_ns;
        g_applied.long_waits_unlogged = 0;
      }
      const bool new_start =
          g_applied.rearmed_at_ns && now_ns - g_applied.rearmed_at_ns < 5'000'000'000;
      if (new_start || std::popcount(g_applied.long_wait_history & 0xFFu) >= 3) {
        GiveUp(*backend, "SLEEP TOO LONG", now_ns, true);
      }
    }
  }
  // The driver holds the frame rate only if it was told the interval and slept this frame; else
  // the game's own limiter does.
  g_driver_limits.store(held && g_applied.interval_us != 0, std::memory_order_relaxed);
  if (markers && !duplicate_id) {
    backend->Marker(LatencyMarker::kSimulationStart, id);
    backend->Marker(LatencyMarker::kInputSample, id);
  }
  if ((debug & 16) && id % 300 == 0) {
    REXLOG_INFO(
        "Low latency: frame ids so far: {} timer passes with no swap since the previous one, {} "
        "pending frames written off after a swap ({} of them after waiting half a second), {} "
        "after a stall, {} swaps in play with no frame, {} ids started twice",
        g_stat_passes_without_swap.load(std::memory_order_relaxed),
        g_stat_healed.load(std::memory_order_relaxed), g_stat_held.load(std::memory_order_relaxed),
        g_stat_stale.load(std::memory_order_relaxed),
        g_stat_swaps_without_frame.load(std::memory_order_relaxed),
        g_stat_duplicate_ids.load(std::memory_order_relaxed));
  }
  if ((debug & 2) && id % 300 == 0) {
    const std::string report = backend->TimingReport();
    if (!report.empty()) {
      REXLOG_INFO("Low latency: {}; the wait before the frame averaged {:.2f} ms over {} frames",
                  report, sleep_count ? double(sleep_us_total) / sleep_count / 1000.0 : 0.0,
                  sleep_count);
    }
    sleep_us_total = 0;
    sleep_count = 0;
  }
}

void LowLatency::OnGuestSwap() {
  // One more swap packet, and the oldest frame the update thread started that has none is
  // this one's (none: an untimed swap, a logo or a loading screen).
  uint64_t counts = g_frame_counts.load(std::memory_order_relaxed);
  uint64_t desired;
  do {
    desired = counts + kSwapUnit - ((counts & kPendingMask) ? 1 : 0);
  } while (!g_frame_counts.compare_exchange_weak(counts, desired, std::memory_order_acq_rel,
                                                 std::memory_order_relaxed));
  const int64_t now_ns = SteadyNs();
  g_last_swap_ns.store(now_ns, std::memory_order_relaxed);
  if (!(counts & kPendingMask) &&
      now_ns - g_last_frame_start_ns.load(std::memory_order_relaxed) < 100'000'000) {
    // A swap with no frame started for it while frames are being started: not a logo or a
    // loading screen.
    g_stat_swaps_without_frame.fetch_add(1, std::memory_order_relaxed);
  }
  // The thread that makes the timer passes must not be the one that swaps (the update thread
  // and the render thread are two).
  // (Only while timer passes are being made: a loading screen's loop can swap on that thread
  // with none.)
  if (std::hash<std::thread::id>()(std::this_thread::get_id()) ==
          g_frame_thread_hash.load(std::memory_order_relaxed) &&
      now_ns - g_last_frame_start_ns.load(std::memory_order_relaxed) < 100'000'000 &&
      g_swaps_on_frame_thread.fetch_add(1, std::memory_order_relaxed) == 20) {
    REXLOG_WARN(
        "Low latency: the thread that makes the timer passes also swaps; the update "
        "thread was probably not found");
  }
  const uint64_t id = (counts >> 32) + 1;
  if ((counts & kPendingMask) && g_markers.load(std::memory_order_relaxed)) {
    Marker(LatencyMarker::kSimulationEnd, id);
  }
}

void LowLatency::OnRenderDraw() {
  if (t_render_started) {
    return;
  }
  t_render_started = true;
  const uint64_t id = g_swaps_executed.load(std::memory_order_relaxed) + 1;
  t_render_frame = IsMarked(id) ? id : 0;
  if (t_render_frame && g_markers.load(std::memory_order_relaxed)) {
    Marker(LatencyMarker::kRenderSubmitStart, t_render_frame);
  }
}

void LowLatency::OnRenderSwap() {
  OnRenderDraw();
  if (!t_render_frame) {
    // (The frame's mark can come after its first draw, if the update thread is late.)
    const uint64_t id = g_swaps_executed.load(std::memory_order_relaxed) + 1;
    t_render_frame = IsMarked(id) ? id : 0;
  }
  // The present code's frame: none while no markers go out, so a default-off game's submissions
  // and presents are as they were.
  t_swap_frame = g_markers.load(std::memory_order_relaxed) ? t_render_frame : 0;
  if (t_swap_frame) {
    Marker(LatencyMarker::kRenderSubmitEnd, t_swap_frame);
  }
}

void LowLatency::OnRenderSwapDone() {
  t_render_started = false;
  t_render_frame = 0;
  t_swap_frame = 0;
  g_swaps_executed.fetch_add(1, std::memory_order_relaxed);
}

uint64_t LowLatency::CurrentFrameId() {
  return t_swap_frame;
}

uint64_t LowLatency::GpuFrameId() {
  if (!g_markers.load(std::memory_order_relaxed) ||
      !g_explicit_attribution.load(std::memory_order_relaxed)) {
    return 0;
  }
  const uint64_t id = g_swaps_executed.load(std::memory_order_relaxed) + 1;
  return IsMarked(id) ? id : 0;
}

void LowLatency::Marker(LatencyMarker marker, uint64_t frame_id) {
  if (!frame_id || !g_markers.load(std::memory_order_relaxed)) {
    return;
  }
  std::shared_ptr<LowLatencyBackend> backend = Backend();
  if (backend) {
    backend->Marker(marker, frame_id);
  }
}

}  // namespace ui
}  // namespace rex
