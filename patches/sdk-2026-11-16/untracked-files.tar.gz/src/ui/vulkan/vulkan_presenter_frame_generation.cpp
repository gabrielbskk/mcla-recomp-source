/**
 ******************************************************************************
 * ReXGlue: frame generation (rexglue-frame-generation.patch), Vulkan side of  *
 * the presenter: the image the refresher composes the generated frame into,  *
 * the present images (a pair per frame) and the pacer thread.                *
 ******************************************************************************
 *
 * On Vulkan the refresher generates (the command processor has FidelityFX's
 * context, gpu vulkan/frame_generation.cpp) in the frame's own submission. The
 * guest output thread's paint right after it puts the generated frame and the
 * real one into the two present images of a pair (as the real frame is
 * painted: bilinear, with the UI overlay) and hands the pair to the pacer,
 * which copies each into a swapchain image and presents it on a queue of its
 * own: the generated frame as soon as it's ready, the real one half a frame
 * later (AMD's pacing).
 */

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>
#include <thread>

#include <rex/cvar.h>
#include <rex/logging.h>
#include <rex/ui/vulkan/presenter.h>
#include <rex/ui/vulkan/util.h>

REXCVAR_DEFINE_INT32(frame_generation_dump, 0, "GPU",
                     "Development: when changed to a positive value, the frame pacer (Vulkan, "
                     "frame generation) writes that many of the next images it presents as "
                     "PPM files into frame_generation_dump_path (HDR10: 10-bit PQ codes)")
    .range(0, 1000);
REXCVAR_DEFINE_STRING(frame_generation_dump_path, "", "GPU",
                      "Development: the folder frame_generation_dump writes into");
REXCVAR_DECLARE(int32_t, frame_generation_debug);
REXCVAR_DECLARE(bool, frame_generation_timing);
REXCVAR_DEFINE_STRING(frame_generation_pacing, "auto", "GPU",
                      "Vulkan frame generation: how the pacer spaces the generated and the real "
                      "frame. timed: by the rendered frames' interval, as AMD's presenter does "
                      "(a variable refresh display, or any whose refresh isn't known); display: "
                      "back to back, the tear-free (FIFO) swapchain spacing them at the "
                      "display's refresh, with the back-pressure that holds the game to half of "
                      "it (a fixed refresh display: the PS5's, 59.94 Hz); auto: display on the "
                      "PS5, timed elsewhere. display needs the tear-free swapchain "
                      "(frame_generation_present = auto). The PS5's pacing is untested on a "
                      "console")
    .allowed({"auto", "timed", "display"});

namespace rex {
namespace ui {
namespace vulkan {

namespace {
// Waits on the pacer's side are cut into these, to see device loss and
// requests to stop.
constexpr uint64_t kFramePacerWaitSliceNs = 100'000'000;
constexpr auto kFramePacerWaitSlice = std::chrono::milliseconds(100);

uint64_t SteadyNs() {
  return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(
                      std::chrono::steady_clock::now().time_since_epoch())
                      .count());
}

// The VkResult in the log, not just its number (the present's failure was
// invisible: the status bit alone, without which one it was).
const char* VkResultName(VkResult result) {
  switch (int32_t(result)) {
    case VK_SUCCESS:
      return "success";
    case VK_NOT_READY:
      return "not ready";
    case VK_TIMEOUT:
      return "timeout";
    case VK_SUBOPTIMAL_KHR:
      return "suboptimal";
    case VK_ERROR_OUT_OF_DATE_KHR:
      return "out of date";
    case VK_ERROR_SURFACE_LOST_KHR:
      return "surface lost";
    case VK_ERROR_DEVICE_LOST:
      return "device lost";
    case VK_ERROR_OUT_OF_HOST_MEMORY:
      return "out of host memory";
    case VK_ERROR_OUT_OF_DEVICE_MEMORY:
      return "out of device memory";
    case VK_ERROR_NATIVE_WINDOW_IN_USE_KHR:
      return "native window in use";
    case VK_ERROR_FULL_SCREEN_EXCLUSIVE_MODE_LOST_EXT:
      return "full screen exclusive mode lost";
    case VK_ERROR_UNKNOWN:
      return "unknown (the copy wasn't submitted)";
    default:
      return "another error";
  }
}

// Per connection, for the diagnostic logs: which one it is, and how many
// presents and outdated paints were logged (the pacer thread, the guest
// output thread and the UI thread respectively; the connection index is stored
// as the UI thread creates it).
std::atomic<uint32_t> g_frame_pacer_connection{0};
std::atomic<uint32_t> g_frame_pacer_presents_logged{0};
std::atomic<uint32_t> g_frame_pacer_paint_outdated_logged{0};
}  // namespace

bool VulkanPresenter::SupportsFrameGeneration() const {
  // Only where generation can run: the device checked FidelityFX's Vulkan
  // runtime (Windows), Vulkan 1.3 with the features it uses, and the timeline
  // semaphores the pacer needs. Linux and the PS5 offer it untested (phase 5).
  return vulkan_device_->frame_generation_supported() &&
         vulkan_device_->properties().timelineSemaphore;
}

const char* VulkanPresenter::FrameGenerationUnsupportedReason() const {
  const char* reason = vulkan_device_->frame_generation_unsupported_reason();
  return reason ? reason : "NO TIMELINE SEMAPHORES";
}

void VulkanPresenter::PrepareGuestOutputThreadPaint() {
  // Back-pressure, before the paint lock is taken: until the pacer has taken
  // the previous frame. Bounded, so a present or acquire blocked in the driver
  // never holds the guest output thread (and through the lock, the UI thread).
  if (!frame_pacer_connected_.load(std::memory_order_acquire) ||
      frame_pacer_stalled_.load(std::memory_order_relaxed)) {
    return;
  }
  std::unique_lock<std::mutex> lock(frame_pacer_mutex_);
  if (!frame_pacer_condition_.wait_for(lock, std::chrono::seconds(1), [this] {
        return frame_pacer_taken_ >= frame_pacer_pushed_ || frame_pacer_paused_ ||
               (frame_pacer_status_.load(std::memory_order_relaxed) &
                kFramePacerStatusDeviceLost);
      })) {
    // The frames after it are dropped without waiting (a second each otherwise)
    // until it takes one.
    frame_pacer_stalled_.store(true, std::memory_order_relaxed);
    REXLOG_WARN(
        "VulkanPresenter: the frame pacer hasn't taken a frame for 1 s (a present or "
        "acquire blocked?); dropping frames until it does");
  }
}

void VulkanPresenter::NoteFramePacerPresent(bool generated, uint64_t present_start_ns) {
  if (!REXCVAR_GET(frame_generation_timing)) {
    return;
  }
  (generated ? frame_pacer_stat_generated_ : frame_pacer_stat_real_) += 1;
  if (frame_pacer_stat_last_ns_ && present_start_ns - frame_pacer_stat_last_ns_ < 1'000'000'000) {
    frame_pacer_stat_intervals_ns_.push_back(present_start_ns - frame_pacer_stat_last_ns_);
  }
  frame_pacer_stat_last_ns_ = present_start_ns;
  if (frame_pacer_stat_real_ < 300) {
    return;
  }
  std::vector<uint64_t>& intervals = frame_pacer_stat_intervals_ns_;
  std::sort(intervals.begin(), intervals.end());
  const auto at = [&intervals](size_t per_cent) {
    return intervals.empty() ? 0.0 : double(intervals[intervals.size() * per_cent / 100]) * 1e-6;
  };
  REXLOG_INFO(
      "VulkanPresenter: frame pacer: {} real and {} generated presents ({:.4f} presents per real "
      "frame); the present calls {:.2f} ms apart (p1 {:.2f}, p99 {:.2f})",
      frame_pacer_stat_real_, frame_pacer_stat_generated_,
      double(frame_pacer_stat_real_ + frame_pacer_stat_generated_) / double(frame_pacer_stat_real_),
      at(50), at(1), at(99));
  frame_pacer_stat_real_ = 0;
  frame_pacer_stat_generated_ = 0;
  intervals.clear();
}

void VulkanPresenter::ResetFramePacerPacing() {
  // UI thread, with the pacer paused or not connected yet.
  frame_pacer_interval_count_ = 0;
  frame_pacer_interval_next_ = 0;
  frame_pacer_last_present_ns_ = 0;
  frame_pacer_last_completion_ns_ = 0;
  frame_pacer_stalled_.store(false, std::memory_order_relaxed);
}

void VulkanPresenter::CreateFramePacerFromUIThread() {
  // Whatever stops this short of a connected pacer leaves the connection as
  // without frame generation: UI overlay painting isn't forced (implicit vsync
  // stays with the UI thread).
  struct NotPresenting {
    VulkanPresenter* presenter;
    bool done = false;
    ~NotPresenting() {
      if (!done) {
        presenter->SetFrameGenerationPresentingFromUIThread(false);
      }
    }
  } not_presenting{this};
  if (!frame_generation_wanted() || paint_context_.swapchain == VK_NULL_HANDLE) {
    return;
  }
  // A connection that keeps going outdated would recreate the swapchain on
  // every paint: the pacer is given a few tries in a row, then frame generation
  // is given up for the session (the frame rate cap goes back to the player's,
  // and the game presents as without it; the switches and the menu stay as they
  // are for the next session). UI thread only.
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  const VkExtent2D extent = paint_context_.swapchain_extent;

  // The pacer: needs a queue of its own that can present to this surface and
  // swapchain images it can copy into. Without them, painting goes as without
  // frame generation on this connection (UI overlay painting isn't forced, so
  // implicit vsync stays with the UI thread, and MAILBOX was allowed).
  if (!paint_context_.swapchain_transfer_dst || paint_context_.pacer_queue_family == UINT32_MAX) {
    REXLOG_WARN(
        "VulkanPresenter: frame generation can't present on this connection (no queue of "
        "its own that can present here and copy into the swapchain); painting as "
        "without it");
    return;
  }
  if (frame_pacer_paint_timeline_ == VK_NULL_HANDLE) {
    VkSemaphoreTypeCreateInfo semaphore_type_info = {};
    semaphore_type_info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO;
    semaphore_type_info.semaphoreType = VK_SEMAPHORE_TYPE_TIMELINE;
    semaphore_type_info.initialValue = 0;
    VkSemaphoreCreateInfo semaphore_create_info = {};
    semaphore_create_info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    semaphore_create_info.pNext = &semaphore_type_info;
    VkFenceCreateInfo fence_create_info = {};
    fence_create_info.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    if (dfn.vkCreateSemaphore(device, &semaphore_create_info, nullptr,
                              &frame_pacer_paint_timeline_) != VK_SUCCESS ||
        dfn.vkCreateSemaphore(device, &semaphore_create_info, nullptr,
                              &frame_pacer_copy_timeline_) != VK_SUCCESS ||
        dfn.vkCreateFence(device, &fence_create_info, nullptr, &frame_pacer_acquire_fence_) !=
            VK_SUCCESS) {
      REXLOG_ERROR("VulkanPresenter: Failed to create the frame pacer's synchronisation objects");
      util::DestroyAndNullHandle(dfn.vkDestroySemaphore, device, frame_pacer_paint_timeline_);
      util::DestroyAndNullHandle(dfn.vkDestroySemaphore, device, frame_pacer_copy_timeline_);
      util::DestroyAndNullHandle(dfn.vkDestroyFence, device, frame_pacer_acquire_fence_);
      return;
    }
  }
  if (!frame_pacer_thread_.joinable()) {
    if (low_latency_) {
      // Low latency: the pacer's queue presents out of the guest frames' cadence.
      const VulkanDevice::Queue::Acquisition queue_acquisition = vulkan_device_->AcquireQueue(
          paint_context_.pacer_queue_family, paint_context_.pacer_queue_index);
      low_latency_->NotifyOutOfBandPresentQueue(queue_acquisition.queue());
    }
    frame_pacer_thread_ = std::thread([this] { FramePacerThread(); });
  }

  // The present images' render pass: the swapchain render pass's, but leaving
  // the image for the copy (compatible with it, so its pipelines are used).
  const VkFormat format = paint_context_.swapchain_render_pass_format;
  if (paint_context_.present_image_render_pass_format != format) {
    util::DestroyAndNullHandle(dfn.vkDestroyRenderPass, device,
                               paint_context_.present_image_render_pass);
    paint_context_.present_image_render_pass_format = VK_FORMAT_UNDEFINED;
  }
  if (paint_context_.present_image_render_pass == VK_NULL_HANDLE) {
    VkAttachmentDescription attachment = {};
    attachment.format = format;
    attachment.samples = VK_SAMPLE_COUNT_1_BIT;
    attachment.loadOp = paint_context_.swapchain_render_pass_clear_load_op
                            ? VK_ATTACHMENT_LOAD_OP_CLEAR
                            : VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    attachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    attachment.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    attachment.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachment.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    attachment.finalLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    VkAttachmentReference color_attachment = {0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkSubpassDescription subpass = {};
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &color_attachment;
    // The dependencies are the swapchain render pass's, so the two are
    // compatible (render pass compatibility includes them).
    VkSubpassDependency dependencies[2] = {};
    // srcStageMask is the stage the wait for the copy timeline is at.
    dependencies[0].srcSubpass = VK_SUBPASS_EXTERNAL;
    dependencies[0].dstSubpass = 0;
    dependencies[0].srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dependencies[0].dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dependencies[0].srcAccessMask = VK_ACCESS_MEMORY_READ_BIT;
    dependencies[0].dstAccessMask =
        VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    dependencies[0].dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;
    // The semaphore signal after the paint makes the writes available.
    dependencies[1].srcSubpass = 0;
    dependencies[1].dstSubpass = VK_SUBPASS_EXTERNAL;
    dependencies[1].srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dependencies[1].dstStageMask = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT;
    dependencies[1].srcAccessMask =
        VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    dependencies[1].dstAccessMask = VK_ACCESS_MEMORY_READ_BIT;
    dependencies[1].dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;
    VkRenderPassCreateInfo render_pass_create_info = {};
    render_pass_create_info.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    render_pass_create_info.attachmentCount = 1;
    render_pass_create_info.pAttachments = &attachment;
    render_pass_create_info.subpassCount = 1;
    render_pass_create_info.pSubpasses = &subpass;
    render_pass_create_info.dependencyCount = 2;
    render_pass_create_info.pDependencies = dependencies;
    if (dfn.vkCreateRenderPass(device, &render_pass_create_info, nullptr,
                               &paint_context_.present_image_render_pass) != VK_SUCCESS) {
      REXLOG_ERROR("VulkanPresenter: Failed to create the present image render pass");
      return;
    }
    paint_context_.present_image_render_pass_format = format;
  }

  // The present images (a pair per slot: the generated frame, the real one),
  // shared by the graphics queue (painting) and the pacer's (copying) without
  // ownership transfers.
  const uint32_t graphics_family = vulkan_device_->queue_family_graphics_compute();
  const uint32_t sharing_families[] = {graphics_family, paint_context_.pacer_queue_family};
  const bool concurrent = graphics_family != paint_context_.pacer_queue_family;
  for (uint32_t i = 0; i < PaintContext::kPresentImageCount; ++i) {
    VkImageCreateInfo image_create_info = {};
    image_create_info.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    image_create_info.imageType = VK_IMAGE_TYPE_2D;
    image_create_info.format = format;
    image_create_info.extent = {extent.width, extent.height, 1};
    image_create_info.mipLevels = 1;
    image_create_info.arrayLayers = 1;
    image_create_info.samples = VK_SAMPLE_COUNT_1_BIT;
    image_create_info.tiling = VK_IMAGE_TILING_OPTIMAL;
    image_create_info.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    image_create_info.sharingMode =
        concurrent ? VK_SHARING_MODE_CONCURRENT : VK_SHARING_MODE_EXCLUSIVE;
    image_create_info.queueFamilyIndexCount = concurrent ? 2 : 0;
    image_create_info.pQueueFamilyIndices = concurrent ? sharing_families : nullptr;
    image_create_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VkImageViewCreateInfo view_create_info = {};
    view_create_info.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    view_create_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
    view_create_info.format = format;
    view_create_info.subresourceRange = util::InitializeSubresourceRange();
    VkFramebufferCreateInfo framebuffer_create_info = {};
    framebuffer_create_info.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    framebuffer_create_info.renderPass = paint_context_.present_image_render_pass;
    framebuffer_create_info.attachmentCount = 1;
    framebuffer_create_info.pAttachments = &paint_context_.present_image_views[i];
    framebuffer_create_info.width = extent.width;
    framebuffer_create_info.height = extent.height;
    framebuffer_create_info.layers = 1;
    if (!util::CreateDedicatedAllocationImage(vulkan_device_, image_create_info,
                                              util::MemoryPurpose::kDeviceLocal,
                                              paint_context_.present_images[i],
                                              paint_context_.present_image_memory[i]) ||
        (view_create_info.image = paint_context_.present_images[i],
         dfn.vkCreateImageView(device, &view_create_info, nullptr,
                               &paint_context_.present_image_views[i]) != VK_SUCCESS) ||
        dfn.vkCreateFramebuffer(device, &framebuffer_create_info, nullptr,
                                &paint_context_.present_image_framebuffers[i]) != VK_SUCCESS) {
      REXLOG_ERROR("VulkanPresenter: Failed to create the frame pacer's present images");
      DestroyFramePacerFromUIThread();
      return;
    }
  }

  // The copy command buffers, on the pacer's family.
  for (uint32_t i = 0; i < kFramePacerCopySlots * 2; ++i) {
    VkCommandPoolCreateInfo pool_create_info = {};
    pool_create_info.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    pool_create_info.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;
    pool_create_info.queueFamilyIndex = paint_context_.pacer_queue_family;
    VkCommandBufferAllocateInfo allocate_info = {};
    allocate_info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    allocate_info.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocate_info.commandBufferCount = 1;
    if (dfn.vkCreateCommandPool(device, &pool_create_info, nullptr,
                                &frame_pacer_command_pools_[i]) != VK_SUCCESS ||
        (allocate_info.commandPool = frame_pacer_command_pools_[i],
         dfn.vkAllocateCommandBuffers(device, &allocate_info,
                                      &frame_pacer_command_buffers_[i]) != VK_SUCCESS)) {
      REXLOG_ERROR("VulkanPresenter: Failed to create the frame pacer's command buffers");
      DestroyFramePacerFromUIThread();
      return;
    }
  }

  // A present semaphore per swapchain image: reused when the image is
  // acquired again, after its previous present.
  frame_pacer_present_semaphores_.resize(paint_context_.swapchain_images.size(), VK_NULL_HANDLE);
  for (VkSemaphore& semaphore : frame_pacer_present_semaphores_) {
    VkSemaphoreCreateInfo semaphore_create_info = {};
    semaphore_create_info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    if (dfn.vkCreateSemaphore(device, &semaphore_create_info, nullptr, &semaphore) !=
        VK_SUCCESS) {
      REXLOG_ERROR("VulkanPresenter: Failed to create the frame pacer's present semaphores");
      DestroyFramePacerFromUIThread();
      return;
    }
  }

  frame_pacer_status_.store(0, std::memory_order_relaxed);
  frame_pacer_dropped_.store(0, std::memory_order_relaxed);
  g_frame_pacer_connection.fetch_add(1, std::memory_order_relaxed);
  g_frame_pacer_presents_logged.store(0, std::memory_order_relaxed);
  g_frame_pacer_paint_outdated_logged.store(0, std::memory_order_relaxed);
  ResetFramePacerPacing();
  // The guest's UI separated in SDR too (generation needs the scene without
  // it).
  SetFrameGenerationUiSeparation(true);
  not_presenting.done = true;
  frame_pacer_connected_.store(true, std::memory_order_release);
  SetFrameGenerationPresentingFromUIThread(true);
  {
    std::lock_guard<std::mutex> lock(frame_pacer_mutex_);
    frame_pacer_paused_ = false;
    frame_pacer_stop_requested_.store(false, std::memory_order_relaxed);
  }
  frame_pacer_condition_.notify_all();
  REXLOG_INFO("VulkanPresenter: frame pacer on queue family {} index {}",
              paint_context_.pacer_queue_family, paint_context_.pacer_queue_index);
}

void VulkanPresenter::PauseFramePacerFromUIThread() {
  if (!frame_pacer_thread_.joinable()) {
    return;
  }
  {
    std::unique_lock<std::mutex> lock(frame_pacer_mutex_);
    frame_pacer_paused_ = true;
    frame_pacer_stop_requested_.store(true, std::memory_order_relaxed);
    // Frames not taken yet are dropped (their present images are released).
    for (const FramePacerFrame& frame : frame_pacer_queue_) {
      NoteFramePacerDrop(frame.id, frame.refresh_number, "reconnect");
    }
    frame_pacer_queue_.clear();
    frame_pacer_taken_ = frame_pacer_pushed_;
    frame_pacer_condition_.notify_all();
    // Every wait of the pacer is cut into slices that see the request; only a
    // present or acquire blocked in the driver keeps it busy. Its objects
    // can't be destroyed before it's done, so this waits on, saying so (the
    // guest output thread doesn't paint meanwhile and the game goes on).
    uint32_t seconds = 0;
    while (!frame_pacer_condition_.wait_for(lock, std::chrono::seconds(1),
                                            [this] { return !frame_pacer_busy_; })) {
      REXLOG_WARN("VulkanPresenter: waiting {} s for the frame pacer to finish a present",
                  ++seconds);
    }
  }
  // The pacer's copies and presents finished, and the copy timeline at the
  // last frame given to it, so the next paints don't wait for dropped frames.
  if (paint_context_.pacer_queue_family != UINT32_MAX) {
    SignalFramePacerCopyTimeline(frame_pacer_pushed_);
    const VulkanDevice::Queue::Acquisition queue_acquisition = vulkan_device_->AcquireQueue(
        paint_context_.pacer_queue_family, paint_context_.pacer_queue_index);
    vulkan_device_->functions().vkQueueWaitIdle(queue_acquisition.queue());
  }
}

void VulkanPresenter::DestroyFramePacerFromUIThread() {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  PauseFramePacerFromUIThread();
  frame_pacer_connected_.store(false, std::memory_order_release);
  SetFrameGenerationUiSeparation(false);
  if (frame_pacer_dropped_.load(std::memory_order_relaxed)) {
    REXLOG_INFO("VulkanPresenter: the frame pacer dropped {} frames on this connection",
                frame_pacer_dropped_.load(std::memory_order_relaxed));
  }
  // The guest output thread's paints into the present images are over.
  paint_context_.submission_tracker.AwaitAllSubmissionsCompletion();
  for (VkSemaphore& semaphore : frame_pacer_present_semaphores_) {
    util::DestroyAndNullHandle(dfn.vkDestroySemaphore, device, semaphore);
  }
  frame_pacer_present_semaphores_.clear();
  for (uint32_t i = 0; i < kFramePacerCopySlots * 2; ++i) {
    // Freed with the pool.
    frame_pacer_command_buffers_[i] = VK_NULL_HANDLE;
    util::DestroyAndNullHandle(dfn.vkDestroyCommandPool, device, frame_pacer_command_pools_[i]);
  }
  for (uint32_t i = 0; i < PaintContext::kPresentImageCount; ++i) {
    util::DestroyAndNullHandle(dfn.vkDestroyFramebuffer, device,
                               paint_context_.present_image_framebuffers[i]);
    util::DestroyAndNullHandle(dfn.vkDestroyImageView, device,
                               paint_context_.present_image_views[i]);
    util::DestroyAndNullHandle(dfn.vkDestroyImage, device, paint_context_.present_images[i]);
    util::DestroyAndNullHandle(dfn.vkFreeMemory, device, paint_context_.present_image_memory[i]);
  }
}

void VulkanPresenter::ShutdownFramePacer() {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  DestroyFramePacerFromUIThread();
  // The paints are done (DestroyFramePacerFromUIThread awaited them), and the
  // guest output thread no longer refreshes.
  for (std::shared_ptr<GuestOutputImage>& ref : frame_generation_image_paint_refs_) {
    ref.reset();
  }
  frame_generation_image_.reset();
  if (frame_pacer_thread_.joinable()) {
    {
      std::lock_guard<std::mutex> lock(frame_pacer_mutex_);
      frame_pacer_exit_ = true;
    }
    frame_pacer_condition_.notify_all();
    frame_pacer_thread_.join();
  }
  util::DestroyAndNullHandle(dfn.vkDestroyRenderPass, device,
                             paint_context_.present_image_render_pass);
  util::DestroyAndNullHandle(dfn.vkDestroySemaphore, device, frame_pacer_paint_timeline_);
  util::DestroyAndNullHandle(dfn.vkDestroySemaphore, device, frame_pacer_copy_timeline_);
  util::DestroyAndNullHandle(dfn.vkDestroyFence, device, frame_pacer_acquire_fence_);
  util::DestroyAndNullHandle(dfn.vkDestroyBuffer, device, frame_pacer_dump_buffer_);
  util::DestroyAndNullHandle(dfn.vkFreeMemory, device, frame_pacer_dump_memory_);
  frame_pacer_dump_mapping_ = nullptr;
}

bool VulkanPresenter::PrepareFramePacerDump() {
  const int32_t request = REXCVAR_GET(frame_generation_dump);
  if (request != frame_pacer_dump_last_request_) {
    frame_pacer_dump_last_request_ = request;
    frame_pacer_dump_left_ = std::max(int32_t(0), request);
  }
  if (frame_pacer_dump_left_ <= 0) {
    return false;
  }
  const VkDeviceSize size = VkDeviceSize(paint_context_.swapchain_extent.width) *
                            paint_context_.swapchain_extent.height * 4;
  if (frame_pacer_dump_size_ < size) {
    // The previous dump's copy was awaited when it was written.
    const VulkanDevice::Functions& dfn = vulkan_device_->functions();
    const VkDevice device = vulkan_device_->device();
    util::DestroyAndNullHandle(dfn.vkDestroyBuffer, device, frame_pacer_dump_buffer_);
    util::DestroyAndNullHandle(dfn.vkFreeMemory, device, frame_pacer_dump_memory_);
    frame_pacer_dump_mapping_ = nullptr;
    frame_pacer_dump_size_ = 0;
    if (!util::CreateDedicatedAllocationBuffer(
            vulkan_device_, size, VK_BUFFER_USAGE_TRANSFER_DST_BIT,
            util::MemoryPurpose::kReadback, frame_pacer_dump_buffer_, frame_pacer_dump_memory_) ||
        dfn.vkMapMemory(device, frame_pacer_dump_memory_, 0, VK_WHOLE_SIZE, 0,
                        &frame_pacer_dump_mapping_) != VK_SUCCESS) {
      REXLOG_ERROR("VulkanPresenter: frame_generation_dump: no readback buffer");
      frame_pacer_dump_left_ = 0;
      return false;
    }
    frame_pacer_dump_size_ = size;
  }
  return true;
}

void VulkanPresenter::WriteFramePacerDump(const FramePacerFrame& frame, bool generated) {
  --frame_pacer_dump_left_;
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  VkMappedMemoryRange range = {};
  range.sType = VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE;
  range.memory = frame_pacer_dump_memory_;
  range.size = VK_WHOLE_SIZE;
  dfn.vkInvalidateMappedMemoryRanges(vulkan_device_->device(), 1, &range);
  const uint32_t width = paint_context_.swapchain_extent.width;
  const uint32_t height = paint_context_.swapchain_extent.height;
  const bool hdr = paint_context_.swapchain_hdr;
  // As Direct3D 12's (launcher/dev/fg/fgcheck.py), at the window's size.
  const std::string path = REXCVAR_GET(frame_generation_dump_path) + "/fg_dump_vulkan_" +
                           std::to_string(frame.id) + "_r" + std::to_string(frame.refresh_number) +
                           (generated         ? "_generated_"
                            : frame.generated ? "_real_"
                                              : "_real_only_") +
                           std::to_string(width) + "x" + std::to_string(height) + ".ppm";
  FILE* file = nullptr;
#if REX_PLATFORM_WIN32
  if (fopen_s(&file, path.c_str(), "wb")) {
    file = nullptr;
  }
#else
  file = std::fopen(path.c_str(), "wb");
#endif
  if (!file) {
    REXLOG_ERROR("VulkanPresenter: frame_generation_dump: can't write {}", path);
    return;
  }
  std::fprintf(file, "P6 %u %u %u\n", width, height, hdr ? 1023u : 255u);
  const uint32_t* pixels = static_cast<const uint32_t*>(frame_pacer_dump_mapping_);
  const VkFormat format = paint_context_.swapchain_render_pass_format;
  std::vector<uint8_t> row(size_t(width) * (hdr ? 6 : 3));
  for (uint32_t y = 0; y < height; ++y) {
    for (uint32_t x = 0; x < width; ++x) {
      const uint32_t p = pixels[size_t(y) * width + x];
      if (hdr) {
        // A2B10G10R10 (R in the low bits) or A2R10G10B10.
        uint32_t r = p & 1023, g = (p >> 10) & 1023, b = (p >> 20) & 1023;
        if (format == VK_FORMAT_A2R10G10B10_UNORM_PACK32) {
          std::swap(r, b);
        }
        const uint32_t c[] = {r, g, b};
        for (uint32_t i = 0; i < 3; ++i) {
          row[size_t(x) * 6 + i * 2] = uint8_t(c[i] >> 8);
          row[size_t(x) * 6 + i * 2 + 1] = uint8_t(c[i]);
        }
      } else {
        uint8_t c0 = uint8_t(p), c1 = uint8_t(p >> 8), c2 = uint8_t(p >> 16);
        // B8G8R8A8 or R8G8B8A8.
        const bool bgra = format == VK_FORMAT_B8G8R8A8_UNORM || format == VK_FORMAT_B8G8R8A8_SRGB;
        row[size_t(x) * 3] = bgra ? c2 : c0;
        row[size_t(x) * 3 + 1] = c1;
        row[size_t(x) * 3 + 2] = bgra ? c0 : c2;
      }
    }
    std::fwrite(row.data(), 1, row.size(), file);
  }
  std::fclose(file);
  REXLOG_INFO("VulkanPresenter: frame_generation_dump: {}", path);
}

bool VulkanPresenter::WaitForTimeline(VkSemaphore semaphore, uint64_t value,
                                      bool stop_on_request) {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  VkSemaphoreWaitInfo wait_info = {};
  wait_info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_WAIT_INFO;
  wait_info.semaphoreCount = 1;
  wait_info.pSemaphores = &semaphore;
  wait_info.pValues = &value;
  for (;;) {
    VkResult result =
        dfn.vkWaitSemaphores(vulkan_device_->device(), &wait_info, kFramePacerWaitSliceNs);
    if (result == VK_SUCCESS) {
      return true;
    }
    if (result != VK_TIMEOUT) {
      frame_pacer_status_.fetch_or(kFramePacerStatusDeviceLost, std::memory_order_relaxed);
      return false;
    }
    if (stop_on_request) {
      if (frame_pacer_stop_requested_.load(std::memory_order_relaxed)) {
        return false;
      }
      std::lock_guard<std::mutex> lock(frame_pacer_mutex_);
      if (frame_pacer_exit_) {
        return false;
      }
    }
  }
}

void VulkanPresenter::SignalFramePacerCopyTimeline(uint64_t value) {
  if (value <= frame_pacer_copy_signalled_) {
    return;
  }
  // An empty batch on the pacer's queue, after its earlier signals.
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  VkTimelineSemaphoreSubmitInfo timeline_info = {};
  timeline_info.sType = VK_STRUCTURE_TYPE_TIMELINE_SEMAPHORE_SUBMIT_INFO;
  timeline_info.signalSemaphoreValueCount = 1;
  timeline_info.pSignalSemaphoreValues = &value;
  VkSubmitInfo submit_info = {};
  submit_info.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
  submit_info.pNext = &timeline_info;
  submit_info.signalSemaphoreCount = 1;
  submit_info.pSignalSemaphores = &frame_pacer_copy_timeline_;
  VkResult result;
  {
    const VulkanDevice::Queue::Acquisition queue_acquisition = vulkan_device_->AcquireQueue(
        paint_context_.pacer_queue_family, paint_context_.pacer_queue_index);
    result = dfn.vkQueueSubmit(queue_acquisition.queue(), 1, &submit_info, VK_NULL_HANDLE);
  }
  if (result != VK_SUCCESS) {
    // From the host instead, once the signals submitted before are done.
    if (WaitForTimeline(frame_pacer_copy_timeline_, frame_pacer_copy_signalled_, false)) {
      VkSemaphoreSignalInfo signal_info = {};
      signal_info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_SIGNAL_INFO;
      signal_info.semaphore = frame_pacer_copy_timeline_;
      signal_info.value = value;
      dfn.vkSignalSemaphore(vulkan_device_->device(), &signal_info);
    }
  }
  frame_pacer_copy_signalled_ = value;
}

Presenter::PaintResult VulkanPresenter::WaitForFramePacerSlot(uint64_t& frame_id_out) {
  std::unique_lock<std::mutex> lock(frame_pacer_mutex_);
  const uint64_t frame = frame_pacer_pushed_;
  frame_id_out = frame;
  // Back-pressure: the pacer has taken every earlier frame (so the present
  // image this one goes into is free once the copy of frame - 2 is done, which
  // the paint's submission waits for on the GPU). Waited for before the paint
  // lock (PrepareGuestOutputThreadPaint), so normally already true; bounded
  // here, as this holds the paint lock.
  const bool taken = frame_pacer_condition_.wait_for(
      lock,
      frame_pacer_stalled_.load(std::memory_order_relaxed) ? std::chrono::milliseconds(0)
                                                           : kFramePacerWaitSlice,
      [this, frame] {
        return frame_pacer_taken_ >= frame ||
               (frame_pacer_status_.load(std::memory_order_relaxed) & kFramePacerStatusDeviceLost);
      });
  if (!taken) {
    lock.unlock();
    NoteFramePacerDrop(frame, 0, "the pacer was busy with the previous frame");
    return PaintResult::kNotPresented;
  }
  lock.unlock();
  const uint32_t status = frame_pacer_status_.load(std::memory_order_relaxed);
  if (status & kFramePacerStatusDeviceLost) {
    return PaintResult::kGpuLostResponsible;
  }
  if (status & kFramePacerStatusOutdated) {
    // Logged for the first paints after the pacer found the connection
    // outdated: what the paint saw, for pairing with the present's log.
    const uint32_t logged =
        g_frame_pacer_paint_outdated_logged.fetch_add(1, std::memory_order_relaxed);
    if (logged < 4) {
      REXLOG_INFO(
          "VulkanPresenter: frame pacer: paint for frame {} found the connection outdated "
          "(status {})",
          frame, status);
    }
    // A pacer whose presents keep failing would recreate the swapchain on every
    // paint (an endless ~10 connections a second, the game unplayable): given
    // up for the session after a few failures in a row, presenting as without
    // it and back to the player's frame rate cap from the next connection.
    static uint64_t outdated_ns[8] = {};
    static uint32_t outdated_count = 0;
    const uint64_t now = SteadyNs();
    outdated_ns[outdated_count % 8] = now;
    ++outdated_count;
    uint32_t recent = 0;
    for (uint32_t i = 1; i <= std::min<uint32_t>(outdated_count, 8); ++i) {
      if (now - outdated_ns[(outdated_count - i) % 8] <= 3'000'000'000ull) {
        ++recent;
      }
    }
    if (recent >= 4) {
      SetFrameGenerationUnavailable("its connection kept going outdated");
    }
    return PaintResult::kNotPresentedConnectionOutdated;
  }
  if (status & kFramePacerStatusSuboptimal) {
    frame_pacer_status_.fetch_and(~uint32_t(kFramePacerStatusSuboptimal),
                                  std::memory_order_relaxed);
    return PaintResult::kPresentedSuboptimal;
  }
  return PaintResult::kPresented;
}

void VulkanPresenter::PushFrameToPacer(uint64_t frame_id, uint64_t refresh_number, bool generated,
                                       uint64_t low_latency_frame) {
  {
    std::lock_guard<std::mutex> lock(frame_pacer_mutex_);
    frame_pacer_queue_.push_back(
        {frame_id, uint32_t(frame_id & 1), refresh_number, low_latency_frame, generated});
    frame_pacer_pushed_ = frame_id + 1;
  }
  frame_pacer_condition_.notify_all();
}

VulkanPresenter::FramePacerIdleResult VulkanPresenter::WaitForFramePacerIdle() {
  std::unique_lock<std::mutex> lock(frame_pacer_mutex_);
  if (!frame_pacer_condition_.wait_for(lock, std::chrono::milliseconds(500), [this] {
        return (frame_pacer_queue_.empty() && !frame_pacer_busy_) ||
               (frame_pacer_status_.load(std::memory_order_relaxed) &
                kFramePacerStatusDeviceLost);
      })) {
    REXLOG_WARN("VulkanPresenter: the frame pacer is still busy; this paint is skipped");
    return FramePacerIdleResult::kTimedOut;
  }
  return (frame_pacer_status_.load(std::memory_order_relaxed) & kFramePacerStatusDeviceLost)
             ? FramePacerIdleResult::kDeviceLost
             : FramePacerIdleResult::kIdle;
}

void VulkanPresenter::NoteFramePacerDrop(uint64_t frame_id, uint64_t refresh_number,
                                         const char* reason) {
  // Logged for the first frames and then every 100th, counted per connection.
  const uint64_t count = frame_pacer_dropped_.fetch_add(1, std::memory_order_relaxed) + 1;
  if (count <= 20 || count % 100 == 0) {
    REXLOG_INFO("VulkanPresenter: frame pacer: frame {} (refresh {}) not presented: {} ({} on "
                "this connection)",
                frame_id, refresh_number, reason, count);
  }
  LogPresentFromPacer(refresh_number, -1, 0);
}

void VulkanPresenter::FramePacerThread() {
#if REX_PLATFORM_WIN32
  // Above the game's threads, as AMD's presenter threads are, so a busy CPU
  // doesn't make a present late; and its own high-resolution timer for the
  // waits (it doesn't depend on the game having raised the system's), or the
  // system's resolution raised for the pacer's life where the timer is missing
  // (before Windows 10 1803).
  SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
  constexpr DWORD kCreateWaitableTimerHighResolution = 0x00000002;
  HANDLE timer = CreateWaitableTimerExW(nullptr, nullptr, kCreateWaitableTimerHighResolution,
                                        TIMER_ALL_ACCESS);
  frame_pacer_timer_ = timer;
  using TimePeriodFunction = UINT(WINAPI*)(UINT);
  TimePeriodFunction time_end_period = nullptr;
  if (!timer) {
    if (HMODULE winmm = LoadLibraryW(L"winmm.dll")) {
      const auto time_begin_period =
          reinterpret_cast<TimePeriodFunction>(GetProcAddress(winmm, "timeBeginPeriod"));
      time_end_period =
          reinterpret_cast<TimePeriodFunction>(GetProcAddress(winmm, "timeEndPeriod"));
      if (time_begin_period && time_end_period) {
        time_begin_period(1);
      } else {
        time_end_period = nullptr;
      }
    }
  }
  struct Cleanup {
    HANDLE timer;
    TimePeriodFunction time_end_period;
    ~Cleanup() {
      if (timer) {
        CloseHandle(timer);
      }
      if (time_end_period) {
        time_end_period(1);
      }
    }
  } cleanup{timer, time_end_period};
#endif
  std::unique_lock<std::mutex> lock(frame_pacer_mutex_);
  for (;;) {
    frame_pacer_condition_.wait(lock, [this] {
      return frame_pacer_exit_ || (!frame_pacer_paused_ && !frame_pacer_queue_.empty());
    });
    if (frame_pacer_exit_) {
      frame_pacer_timer_ = nullptr;
      return;
    }
    const FramePacerFrame frame = frame_pacer_queue_.front();
    frame_pacer_queue_.pop_front();
    ++frame_pacer_taken_;
    // It's taking frames: the guest output thread waits for it again.
    frame_pacer_stalled_.store(false, std::memory_order_relaxed);
    frame_pacer_busy_ = true;
    frame_pacer_condition_.notify_all();
    lock.unlock();
    FramePacerPresent(frame);
    lock.lock();
    frame_pacer_busy_ = false;
    frame_pacer_condition_.notify_all();
  }
}

VulkanPresenter::FrameGenerationInputs* VulkanPresenter::GetFrameGenerationInputs(
    uint32_t mailbox_index, uint32_t width, uint32_t height) {
  // While the pacer presents (frame generation's connection); the guest output
  // thread's.
  if (!frame_pacer_connected_.load(std::memory_order_acquire) || !width || !height) {
    return nullptr;
  }
  FrameGenerationInputs& inputs = frame_generation_inputs_;
  inputs = FrameGenerationInputs();
  inputs.generation_width = width;
  inputs.generation_height = height;
  // Where the frame is shown smaller than the guest output (the window is
  // smaller), generated at exactly the size it's shown at, so the generated
  // frame is painted 1:1 and the real one is scaled to the same size. (The
  // swapchain's size is the UI thread's; a reconnect racing with this takes
  // effect a frame later.)
  const VkExtent2D extent = paint_context_.swapchain_extent;
  if (extent.width && extent.height) {
    GuestOutputPaintConfig config;
    config.SetEffect(GuestOutputPaintConfig::Effect::kBilinear);
    const VkExtent2D max_extent = util::GetMax2DFramebufferExtent(vulkan_device_->properties());
    const GuestOutputPaintFlow flow =
        GetGuestOutputPaintFlow(GetRefreshingGuestOutputProperties(mailbox_index), extent.width,
                                extent.height, max_extent.width, max_extent.height, config);
    if (flow.effect_count) {
      const std::pair<uint32_t, uint32_t>& shown = flow.effect_output_sizes[flow.effect_count - 1];
      if (shown.first < width && shown.second < height) {
        inputs.generation_width = shown.first;
        inputs.generation_height = shown.second;
      }
    }
  }
  // The image the generated frame is composed into, at that size: a new one
  // once the refresher's last use of the old one is done (paints keep their own
  // references).
  if (frame_generation_image_ &&
      (frame_generation_image_->extent().width != inputs.generation_width ||
       frame_generation_image_->extent().height != inputs.generation_height)) {
    guest_output_image_refresher_submission_tracker_.AwaitSubmissionCompletion(
        frame_generation_image_last_refresher_submission_);
    frame_generation_image_.reset();
  }
  if (!frame_generation_image_) {
    frame_generation_image_ =
        GuestOutputImage::Create(vulkan_device_, inputs.generation_width, inputs.generation_height);
    frame_generation_image_ever_written_ = false;
    frame_generation_image_mailbox_ = UINT32_MAX;
    if (!frame_generation_image_) {
      REXLOG_ERROR("VulkanPresenter: frame generation: couldn't create a {}x{} image",
                   inputs.generation_width, inputs.generation_height);
      return nullptr;
    }
  }
  inputs.generated_image = frame_generation_image_->image();
  inputs.generated_view = frame_generation_image_->view();
  inputs.generated_ever_written = frame_generation_image_ever_written_;
  return &inputs;
}

void VulkanPresenter::PaintGeneratedFrame(VkCommandBuffer command_buffer, uint32_t present_image,
                                          const GuestOutputPaintFlow& flow_in,
                                          VkDescriptorSet descriptor_set, bool overlay) {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  const VkExtent2D extent = paint_context_.swapchain_extent;
  GuestOutputPaintFlow flow = flow_in;
  VkClearAttachment clear_attachment = {};
  clear_attachment.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
  clear_attachment.colorAttachment = 0;
  clear_attachment.clearValue.color.float32[3] = 1.0f;
  VkRenderPassBeginInfo begin_info = {};
  begin_info.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
  begin_info.renderPass = paint_context_.present_image_render_pass;
  begin_info.framebuffer = paint_context_.present_image_framebuffers[present_image];
  begin_info.renderArea.extent = extent;
  const bool clear_load_op = paint_context_.swapchain_render_pass_clear_load_op;
  if (clear_load_op) {
    begin_info.clearValueCount = 1;
    begin_info.pClearValues = &clear_attachment.clearValue;
  }
  dfn.vkCmdBeginRenderPass(command_buffer, &begin_info, VK_SUBPASS_CONTENTS_INLINE);
  const VkViewport viewport = {0.0f, 0.0f, float(extent.width), float(extent.height), 0.0f, 1.0f};
  dfn.vkCmdSetViewport(command_buffer, 0, 1, &viewport);
  const VkRect2D scissor = {{0, 0}, extent};
  dfn.vkCmdSetScissor(command_buffer, 0, 1, &scissor);

  // As the real frame's last pass, bilinear (one pass).
  bool drawn = false;
  if (flow.effect_count == 1 &&
      GetGuestOutputPaintPipelineLayoutIndex(flow.effects[0]) ==
          kGuestOutputPaintPipelineLayoutIndexBilinear) {
    const GuestOutputPaintEffect effect = flow.effects[0];
    std::pair<uint32_t, uint32_t>& rect_size = flow.effect_output_sizes[0];
    // As the real frame's: a rectangle at the top left smaller than the image
    // both ways takes all of it.
    if (flow.output_x == 0 && flow.output_y == 0 && rect_size.first < extent.width &&
        rect_size.second < extent.height) {
      rect_size = std::make_pair(extent.width, extent.height);
      flow.letterbox_clear_rectangle_count = 0;
    }
    PaintContext::GuestOutputPaintPipeline& pipeline =
        paint_context_.guest_output_paint_pipelines[size_t(effect)];
    if (pipeline.swapchain_pipeline != VK_NULL_HANDLE &&
        pipeline.swapchain_format != paint_context_.swapchain_render_pass_format) {
      // Not used by this paint (the real frame's last pass would have made it
      // for this format): only the earlier paints may use it.
      const uint64_t current_submission = paint_context_.submission_tracker.GetCurrentSubmission();
      if (current_submission) {
        paint_context_.submission_tracker.AwaitSubmissionCompletion(current_submission - 1);
      }
      util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, pipeline.swapchain_pipeline);
    }
    if (pipeline.swapchain_pipeline == VK_NULL_HANDLE) {
      pipeline.swapchain_pipeline =
          CreateGuestOutputPaintPipeline(effect, paint_context_.swapchain_render_pass);
      pipeline.swapchain_format = paint_context_.swapchain_render_pass_format;
    }
    if (pipeline.swapchain_pipeline != VK_NULL_HANDLE) {
      const VkPipelineLayout layout =
          guest_output_paint_pipeline_layouts_[kGuestOutputPaintPipelineLayoutIndexBilinear];
      dfn.vkCmdBindPipeline(command_buffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                            pipeline.swapchain_pipeline);
      dfn.vkCmdBindDescriptorSets(command_buffer, VK_PIPELINE_BIND_POINT_GRAPHICS, layout, 0, 1,
                                  &descriptor_set, 0, nullptr);
      GuestOutputPaintRectangleConstants rect_constants;
      const float x_to_ndc = 2.0f / viewport.width;
      const float y_to_ndc = 2.0f / viewport.height;
      rect_constants.x = -1.0f + float(flow.output_x) * x_to_ndc;
      rect_constants.y = -1.0f + float(flow.output_y) * y_to_ndc;
      rect_constants.width = float(rect_size.first) * x_to_ndc;
      rect_constants.height = float(rect_size.second) * y_to_ndc;
      dfn.vkCmdPushConstants(command_buffer, layout, VK_SHADER_STAGE_VERTEX_BIT, 0,
                             sizeof(rect_constants), &rect_constants);
      BilinearConstants bilinear_constants;
      bilinear_constants.Initialize(flow, 0);
      dfn.vkCmdPushConstants(command_buffer, layout, VK_SHADER_STAGE_FRAGMENT_BIT,
                             sizeof(rect_constants), sizeof(bilinear_constants),
                             &bilinear_constants);
      dfn.vkCmdDraw(command_buffer, 4, 1, 0, 0);
      drawn = true;
    }
  }
  if (!clear_load_op) {
    if (!drawn) {
      VkClearRect clear_rect = {scissor, 0, 1};
      dfn.vkCmdClearAttachments(command_buffer, 1, &clear_attachment, 1, &clear_rect);
    } else if (flow.letterbox_clear_rectangle_count) {
      VkClearRect clear_rects[GuestOutputPaintFlow::kMaxClearRectangles];
      for (size_t i = 0; i < flow.letterbox_clear_rectangle_count; ++i) {
        const GuestOutputPaintFlow::ClearRectangle& rect = flow.letterbox_clear_rectangles[i];
        clear_rects[i] = {{{int32_t(rect.x), int32_t(rect.y)}, {rect.width, rect.height}}, 0, 1};
      }
      dfn.vkCmdClearAttachments(command_buffer, 1, &clear_attachment,
                                uint32_t(flow.letterbox_clear_rectangle_count), clear_rects);
    }
  }
  if (overlay) {
    CompositeUIOverlay(command_buffer);
  }
  dfn.vkCmdEndRenderPass(command_buffer);
}

bool VulkanPresenter::FramePacerWaitUntil(uint64_t target_ns) {
  // Sleeps to a little before the target, then spins: 0.5 ms on the
  // high-resolution timer (a wake-up is within a few hundred microseconds),
  // 1.5 ms otherwise (as the game's limiter).
#if REX_PLATFORM_WIN32
  HANDLE timer = static_cast<HANDLE>(frame_pacer_timer_);
#else
  void* timer = nullptr;
#endif
  const uint64_t spin_ns = timer ? 500'000 : 1'500'000;
  for (;;) {
    const uint64_t now = SteadyNs();
    if (now >= target_ns) {
      return true;
    }
    if (frame_pacer_stop_requested_.load(std::memory_order_relaxed)) {
      return false;
    }
    const uint64_t left = target_ns - now;
    if (left > spin_ns) {
      const uint64_t sleep_ns = std::min(left - spin_ns, uint64_t(20'000'000));
#if REX_PLATFORM_WIN32
      if (timer) {
        LARGE_INTEGER due_time;
        due_time.QuadPart = -int64_t(sleep_ns / 100);
        if (SetWaitableTimerEx(timer, &due_time, 0, nullptr, nullptr, nullptr, 0)) {
          WaitForSingleObject(timer, DWORD(sleep_ns / 1'000'000) + 2);
          continue;
        }
      }
#endif
      std::this_thread::sleep_for(std::chrono::nanoseconds(sleep_ns));
    } else {
      std::this_thread::yield();
    }
  }
}

void VulkanPresenter::FramePacerPresent(const FramePacerFrame& frame) {
  const uint64_t value = frame.id + 1;
  const auto drop = [this, value, &frame](const char* reason) {
    NoteFramePacerDrop(frame.id, frame.refresh_number, reason);
    SignalFramePacerCopyTimeline(value);
  };

  // The paint finished on the GPU (generation and the compose are in the
  // refresher's submission before it). Whether it already had when the pacer
  // got here: then the pacer, not the game, set this frame's pace.
  uint64_t paint_done = 0;
  const bool pacer_behind =
      vulkan_device_->functions().vkGetSemaphoreCounterValue(
          vulkan_device_->device(), frame_pacer_paint_timeline_, &paint_done) == VK_SUCCESS &&
      paint_done >= value;
  if (!WaitForTimeline(frame_pacer_paint_timeline_, value, true)) {
    drop("stopped or lost waiting for its paint");
    return;
  }
  // The rendered frames' interval, from when their paints are seen done: the
  // last 10 (a pause of over half a second starts them again; a shorter hitch
  // stays in the window and goes with the next ten frames). Where the pacer was
  // behind, the time says only how fast its own presents were, and pacing from
  // it would keep the rate wherever it was (100 a second with tearing instead of
  // 120): the interval taken is 10% shorter than the mean, so the pacer's
  // gaps shrink until it no longer holds the game back.
  {
    const uint64_t completion_ns = SteadyNs();
    if (frame_pacer_last_completion_ns_) {
      uint64_t interval = completion_ns - frame_pacer_last_completion_ns_;
      bool take = true;
      if (interval > 500'000'000) {
        frame_pacer_interval_count_ = 0;
        frame_pacer_interval_next_ = 0;
        take = false;
      } else if (pacer_behind) {
        if (frame_pacer_interval_count_ >= 2) {
          uint64_t sum = 0;
          for (uint32_t i = 0; i < frame_pacer_interval_count_; ++i) {
            sum += frame_pacer_intervals_ns_[i];
          }
          interval = std::min(interval, sum / frame_pacer_interval_count_ * 9 / 10);
        } else {
          take = false;
        }
      }
      if (take) {
        frame_pacer_intervals_ns_[frame_pacer_interval_next_] = interval;
        frame_pacer_interval_next_ =
            (frame_pacer_interval_next_ + 1) % uint32_t(frame_pacer_intervals_ns_.size());
        frame_pacer_interval_count_ =
            std::min(frame_pacer_interval_count_ + 1, uint32_t(frame_pacer_intervals_ns_.size()));
      }
    }
    frame_pacer_last_completion_ns_ = completion_ns;
  }

  // The copies' command buffers, free once the copies kFramePacerCopySlots
  // frames ago are done (the real frame's copy signals the timeline after the
  // generated one's on the same queue).
  if (frame.id >= kFramePacerCopySlots &&
      !WaitForTimeline(frame_pacer_copy_timeline_, value - kFramePacerCopySlots, false)) {
    frame_pacer_status_.fetch_or(kFramePacerStatusOutdated, std::memory_order_relaxed);
    drop("device lost waiting for a copy command buffer");
    return;
  }

  // frame_generation_debug 3: the generated frames only.
  const bool generated_only = frame.generated && REXCVAR_GET(frame_generation_debug) == 3;
  if (frame.generated) {
    // AMD's pacing (FidelityFX's frame interpolation swap chain, MIT): the
    // presents half the rendered interval apart, less a tenth of its variation
    // and a safety margin of 0.1 ms; the generated frame as soon as it's ready
    // but not before the last present plus that, the real one that after the
    // generated one.
    uint64_t gap_ns = 0;
    if (frame_pacer_interval_count_ >= 2) {
      double mean = 0.0;
      for (uint32_t i = 0; i < frame_pacer_interval_count_; ++i) {
        mean += double(frame_pacer_intervals_ns_[i]);
      }
      mean /= double(frame_pacer_interval_count_);
      double variation = 0.0;
      for (uint32_t i = 0; i < frame_pacer_interval_count_; ++i) {
        variation += std::abs(double(frame_pacer_intervals_ns_[i]) - mean);
      }
      variation /= double(frame_pacer_interval_count_);
      const double gap = mean * 0.5 - variation * 0.1 - 100'000.0;
      gap_ns = gap > 0.0 ? uint64_t(gap) : 0;
    }
    // A fixed refresh display (the PS5's VK_KHR_display, FIFO): the swapchain spaces the two
    // presents at the display's refresh, one blocking in its acquire until the display is
    // ready for it, and the pacer's back-pressure holds the game to half of the refresh rate
    // (the limiter, set just above it, never has to).
    if (gap_ns && paint_context_.swapchain_is_fifo) {
      const std::string pacing = rex::cvar::GetFlagByName("frame_generation_pacing");
#if REX_PLATFORM_PS5
      const bool display_paced = pacing != "timed";
#else
      const bool display_paced = pacing == "display";
#endif
      if (display_paced) {
        gap_ns = 0;
      }
    }
    if (gap_ns && frame_pacer_last_present_ns_ &&
        !FramePacerWaitUntil(frame_pacer_last_present_ns_ + gap_ns)) {
      drop("stopped waiting to present its generated frame");
      return;
    }
    if (!FramePacerPresentImage(frame, 2 * frame.slot, generated_only) || generated_only) {
      return;
    }
    if (gap_ns && !FramePacerWaitUntil(frame_pacer_last_present_ns_ + gap_ns)) {
      drop("stopped waiting to present its real frame");
      return;
    }
  }
  FramePacerPresentImage(frame, 2 * frame.slot + 1, true);
}

bool VulkanPresenter::FramePacerPresentImage(const FramePacerFrame& frame,
                                             uint32_t present_image, bool last) {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  const uint64_t value = frame.id + 1;
  const bool generated = !(present_image & 1);
  const auto drop = [this, value, &frame](const char* reason) {
    NoteFramePacerDrop(frame.id, frame.refresh_number, reason);
    SignalFramePacerCopyTimeline(value);
  };

  // A swapchain image, waited for on the CPU, so a wait for the presentation
  // engine never stalls a queue.
  uint32_t image_index = 0;
  VkResult acquire_result;
  for (;;) {
    acquire_result = dfn.vkAcquireNextImageKHR(device, paint_context_.swapchain,
                                               kFramePacerWaitSliceNs, VK_NULL_HANDLE,
                                               frame_pacer_acquire_fence_, &image_index);
    if (acquire_result != VK_TIMEOUT && acquire_result != VK_NOT_READY) {
      break;
    }
    if (frame_pacer_stop_requested_.load(std::memory_order_relaxed)) {
      drop("stopped waiting for a swapchain image");
      return false;
    }
  }
  switch (acquire_result) {
    case VK_SUCCESS:
      break;
    case VK_SUBOPTIMAL_KHR:
      frame_pacer_status_.fetch_or(kFramePacerStatusSuboptimal, std::memory_order_relaxed);
      break;
    case VK_ERROR_DEVICE_LOST:
      frame_pacer_status_.fetch_or(kFramePacerStatusDeviceLost, std::memory_order_relaxed);
      drop("device lost acquiring");
      return false;
    default:
      frame_pacer_status_.fetch_or(kFramePacerStatusOutdated, std::memory_order_relaxed);
      drop("the swapchain is out of date");
      return false;
  }
  for (;;) {
    VkResult fence_result = dfn.vkWaitForFences(device, 1, &frame_pacer_acquire_fence_, VK_TRUE,
                                                kFramePacerWaitSliceNs);
    if (fence_result == VK_SUCCESS) {
      break;
    }
    if (fence_result != VK_TIMEOUT) {
      frame_pacer_status_.fetch_or(kFramePacerStatusDeviceLost, std::memory_order_relaxed);
      drop("device lost waiting for the swapchain image");
      return false;
    }
  }
  dfn.vkResetFences(device, 1, &frame_pacer_acquire_fence_);

  // The copy, in the slot's command buffer for this image of the pair.
  const uint32_t copy_index =
      uint32_t(frame.id % kFramePacerCopySlots) * 2 + (present_image & 1);
  VkCommandBuffer command_buffer = frame_pacer_command_buffers_[copy_index];
  dfn.vkResetCommandPool(device, frame_pacer_command_pools_[copy_index], 0);
  VkCommandBufferBeginInfo begin_info = {};
  begin_info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
  begin_info.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
  dfn.vkBeginCommandBuffer(command_buffer, &begin_info);
  VkImage swapchain_image = paint_context_.swapchain_images[image_index];
  VkImageMemoryBarrier barrier = {};
  barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
  barrier.srcAccessMask = 0;
  barrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
  barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
  barrier.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
  barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
  barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
  barrier.image = swapchain_image;
  barrier.subresourceRange = util::InitializeSubresourceRange();
  dfn.vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                           VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1,
                           &barrier);
  VkImageCopy region = {};
  region.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
  region.dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
  region.extent = {paint_context_.swapchain_extent.width, paint_context_.swapchain_extent.height,
                   1};
  VkImage source = paint_context_.present_images[present_image];
  dfn.vkCmdCopyImage(command_buffer, source, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                     swapchain_image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &region);
  // Development: what is presented, read back.
  const bool dump = PrepareFramePacerDump();
  if (dump) {
    VkBufferImageCopy dump_region = {};
    dump_region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    dump_region.imageExtent = region.extent;
    dfn.vkCmdCopyImageToBuffer(command_buffer, source, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                               frame_pacer_dump_buffer_, 1, &dump_region);
    VkBufferMemoryBarrier dump_barrier = {};
    dump_barrier.sType = VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER;
    dump_barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    dump_barrier.dstAccessMask = VK_ACCESS_HOST_READ_BIT;
    dump_barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    dump_barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    dump_barrier.buffer = frame_pacer_dump_buffer_;
    dump_barrier.size = VK_WHOLE_SIZE;
    dfn.vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_TRANSFER_BIT,
                             VK_PIPELINE_STAGE_HOST_BIT, 0, 0, nullptr, 1, &dump_barrier, 0,
                             nullptr);
  }
  barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
  barrier.dstAccessMask = 0;
  barrier.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
  barrier.newLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
  dfn.vkCmdPipelineBarrier(command_buffer, VK_PIPELINE_STAGE_TRANSFER_BIT,
                           VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, 0, 0, nullptr, 0, nullptr, 1,
                           &barrier);
  dfn.vkEndCommandBuffer(command_buffer);

  // Waits for the frame's paint; the frame's last copy signals the copy
  // timeline (the paint two frames later reuses the pair).
  VkSemaphore present_semaphore = frame_pacer_present_semaphores_[image_index];
  const VkSemaphore signal_semaphores[] = {present_semaphore, frame_pacer_copy_timeline_};
  const uint64_t signal_values[] = {0, value};
  const VkPipelineStageFlags wait_stage = VK_PIPELINE_STAGE_TRANSFER_BIT;
  VkTimelineSemaphoreSubmitInfo timeline_info = {};
  timeline_info.sType = VK_STRUCTURE_TYPE_TIMELINE_SEMAPHORE_SUBMIT_INFO;
  timeline_info.waitSemaphoreValueCount = 1;
  timeline_info.pWaitSemaphoreValues = &value;
  timeline_info.signalSemaphoreValueCount = last ? 2 : 1;
  timeline_info.pSignalSemaphoreValues = signal_values;
  VkSubmitInfo submit_info = {};
  submit_info.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
  submit_info.pNext = &timeline_info;
  submit_info.waitSemaphoreCount = 1;
  submit_info.pWaitSemaphores = &frame_pacer_paint_timeline_;
  submit_info.pWaitDstStageMask = &wait_stage;
  submit_info.commandBufferCount = 1;
  submit_info.pCommandBuffers = &command_buffer;
  submit_info.signalSemaphoreCount = last ? 2 : 1;
  submit_info.pSignalSemaphores = signal_semaphores;
  VkPresentInfoKHR present_info = {};
  present_info.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
  present_info.waitSemaphoreCount = 1;
  present_info.pWaitSemaphores = &present_semaphore;
  present_info.swapchainCount = 1;
  present_info.pSwapchains = &paint_context_.swapchain;
  present_info.pImageIndices = &image_index;
  VkResult submit_result;
  VkResult present_result = VK_ERROR_UNKNOWN;
  const uint64_t present_start = SteadyNs();
  {
    const VulkanDevice::Queue::Acquisition queue_acquisition = vulkan_device_->AcquireQueue(
        paint_context_.pacer_queue_family, paint_context_.pacer_queue_index);
    submit_result = dfn.vkQueueSubmit(queue_acquisition.queue(), 1, &submit_info, VK_NULL_HANDLE);
    if (submit_result == VK_SUCCESS) {
      if (last) {
        frame_pacer_copy_signalled_ = value;
      }
      // Low latency: each of the pacer's presents, the generated ones too, is out of band, with
      // the id of the guest frame it shows.
      LowLatency::Marker(
          generated ? LatencyMarker::kGeneratedPresentStart : LatencyMarker::kOutOfBandPresentStart,
          frame.low_latency_frame);
      present_result = dfn.vkQueuePresentKHR(queue_acquisition.queue(), &present_info);
      LowLatency::Marker(
          generated ? LatencyMarker::kGeneratedPresentEnd : LatencyMarker::kOutOfBandPresentEnd,
          frame.low_latency_frame);
      if (dump && !last) {
        // The generated frame's readback before the real one's copy reuses
        // the buffer (development only).
        dfn.vkQueueWaitIdle(queue_acquisition.queue());
      }
    }
  }
  frame_pacer_last_present_ns_ = present_start;
  {
    const uint32_t present_index =
        g_frame_pacer_presents_logged.fetch_add(1, std::memory_order_relaxed);
    if (present_index < 6) {
      REXLOG_INFO(
          "VulkanPresenter: frame pacer: present {} on connection {}: acquire {} ({}), submit "
          "{} ({}), present {} ({}), swapchain image {}{}",
          present_index + 1, g_frame_pacer_connection.load(std::memory_order_relaxed),
          int32_t(acquire_result), VkResultName(acquire_result), int32_t(submit_result),
          VkResultName(submit_result), int32_t(present_result), VkResultName(present_result),
          image_index, last ? ", the real frame's" : ", a generated frame's");
    }
  }
  if (submit_result != VK_SUCCESS) {
    // The image stays acquired: the swapchain has to be recreated.
    frame_pacer_status_.fetch_or(submit_result == VK_ERROR_DEVICE_LOST
                                     ? kFramePacerStatusDeviceLost
                                     : kFramePacerStatusOutdated,
                                 std::memory_order_relaxed);
    drop("the copy's submission failed");
    return false;
  }
  switch (present_result) {
    case VK_SUCCESS:
      break;
    case VK_SUBOPTIMAL_KHR:
      frame_pacer_status_.fetch_or(kFramePacerStatusSuboptimal, std::memory_order_relaxed);
      break;
    case VK_ERROR_DEVICE_LOST:
      frame_pacer_status_.fetch_or(kFramePacerStatusDeviceLost, std::memory_order_relaxed);
      break;
    default:
      REXLOG_WARN(
          "VulkanPresenter: the frame pacer's present failed ({}); the swapchain has to be "
          "recreated",
          VkResultName(present_result));
      frame_pacer_status_.fetch_or(kFramePacerStatusOutdated, std::memory_order_relaxed);
      break;
  }
  if (present_result == VK_SUCCESS || present_result == VK_SUBOPTIMAL_KHR) {
    NoteFramePacerPresent(generated, present_start);
  }
  // The present log has the real frames' presents (as on Direct3D 12), or the
  // only one.
  if (!generated || last) {
    LogPresentFromPacer(frame.refresh_number, int(present_result), SteadyNs() - present_start);
  }
  if (dump && (!last || WaitForTimeline(frame_pacer_copy_timeline_, value, false))) {
    WriteFramePacerDump(frame, generated);
  }
  if (present_result != VK_SUCCESS && present_result != VK_SUBOPTIMAL_KHR) {
    if (!last) {
      SignalFramePacerCopyTimeline(value);
    }
    return false;
  }
  return true;
}

}  // namespace vulkan
}  // namespace ui
}  // namespace rex
