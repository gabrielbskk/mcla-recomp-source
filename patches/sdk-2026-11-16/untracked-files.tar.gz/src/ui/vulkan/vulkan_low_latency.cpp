/**
 * Vulkan low latency (rexglue-low-latency.patch). See include/rex/ui/low_latency.h and
 * include/rex/ui/vulkan/vulkan_low_latency.h.
 *
 * VK_NV_low_latency2: the swapchain is made with latency mode enabled (vulkan_presenter.cpp),
 * vkSetLatencySleepModeNV sets the mode, vkLatencySleepNV before the frame's input signals a
 * timeline semaphore that is waited for here, vkSetLatencyMarkerNV carries the markers (the
 * frame's id is the marker's presentID, which is not the VkPresentIdKHR's: that extension is only
 * a dependency of this one), and the submissions carry VkLatencySubmissionPresentIdNV (explicit
 * attribution, revision 3), as the submission thread sends a frame's work after the GPU thread
 * has gone on. VK_AMD_anti_lag: vkAntiLagUpdateAMD with the input stage before the frame's input
 * and the present stage before its present.
 */

#include <algorithm>
#include <cstdio>
#include <mutex>
#include <vector>

#include <rex/cvar.h>
#include <rex/logging.h>
#include <rex/platform.h>
#include <rex/ui/vulkan/vulkan_low_latency.h>

REXCVAR_DECLARE(std::string, low_latency_debug_backend);
REXCVAR_DECLARE(bool, low_latency_device_extensions);
REXCVAR_DECLARE(int32_t, low_latency_debug);

namespace rex {
namespace ui {
namespace vulkan {

std::shared_ptr<VulkanLowLatency> VulkanLowLatency::Create(const VulkanDevice* device,
                                                           const char** why) {
  const VulkanDevice::Extensions& extensions = device->extensions();
  const uint32_t vendor = device->properties().vendorID;
  // Development (low_latency_debug_backend): only that one's extension is looked for.
  const std::string forced = REXCVAR_GET(low_latency_debug_backend);
  if (forced == "none") {
    *why = "TURNED OFF";
    return nullptr;
  }
  std::shared_ptr<VulkanLowLatency> backend(new VulkanLowLatency(device));
  if (forced != "amd" && extensions.ext_NV_low_latency2 && extensions.ext_KHR_present_id &&
      device->properties().presentId && device->properties().timelineSemaphore) {
    backend->nvidia_ = true;
    // Reflex on an NVIDIA GPU; another GPU with the extension (a layer) is untested, and so is
    // everything but Windows.
    backend->name_ = vendor == 0x10DE ? "NVIDIA REFLEX" : "LOW LATENCY";
    backend->untested_ = vendor != 0x10DE;
#if !REX_PLATFORM_WIN32
    backend->untested_ = true;
#endif
    const VulkanDevice::Functions& dfn = device->functions();
    VkSemaphoreTypeCreateInfo type_info = {VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO};
    type_info.semaphoreType = VK_SEMAPHORE_TYPE_TIMELINE;
    type_info.initialValue = 0;
    VkSemaphoreCreateInfo create_info = {VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    create_info.pNext = &type_info;
    if (dfn.vkCreateSemaphore(device->device(), &create_info, nullptr,
                              &backend->sleep_semaphore_) != VK_SUCCESS) {
      *why = "NOT AVAILABLE HERE";
      return nullptr;
    }
    return backend;
  }
  if (forced != "nvidia" && extensions.ext_AMD_anti_lag && device->properties().antiLag) {
    // Untested: no AMD GPU where this was written.
    backend->name_ = "AMD ANTI LAG 2";
    backend->untested_ = true;
    return backend;
  }
  if ((vendor == 0x10DE || vendor == 0x1002) && !REXCVAR_GET(low_latency_device_extensions)) {
    // The device was made without the extensions (the PS5's, until the game starts with the
    // reducer asked for).
    *why = "NEXT START";
  } else if (vendor == 0x10DE) {
    *why = "NEEDS A NEWER DRIVER";
  } else if (vendor == 0x1002) {
    *why = "NOT SUPPORTED";
  } else {
    *why = "NOT ON THIS GPU";
  }
  return nullptr;
}

VulkanLowLatency::~VulkanLowLatency() {
  Shutdown();
}

void VulkanLowLatency::Shutdown() {
  // After the calls in progress (the wait for the driver's signal is bounded) and for good.
  std::unique_lock semaphore_lock(semaphore_mutex_);
  std::unique_lock swapchain_lock(swapchain_mutex_);
  shut_down_ = true;
  swapchain_ = VK_NULL_HANDLE;
  if (sleep_semaphore_ != VK_NULL_HANDLE) {
    device_->functions().vkDestroySemaphore(device_->device(), sleep_semaphore_, nullptr);
    sleep_semaphore_ = VK_NULL_HANDLE;
  }
}

bool VulkanLowLatency::ExplicitSubmissionAttribution() const {
  // Revision 3 of the extension is what the RTX 5080's driver advertises (Vulkan header 357 still
  // describes revision 2, which has the structure but whose submission-time attribution is not
  // documented): with an older driver the submissions are left to the driver's own rules.
  return nvidia_ && device_->low_latency2_spec_version() >= 3;
}

void VulkanLowLatency::SetSwapchain(VkSwapchainKHR swapchain, bool latency_mode) {
  std::unique_lock lock(swapchain_mutex_);
  if (shut_down_) {
    return;
  }
  swapchain_ = swapchain;
  swapchain_latency_mode_ = swapchain != VK_NULL_HANDLE && latency_mode;
  if (nvidia_ && swapchain != VK_NULL_HANDLE && !latency_mode) {
    // The driver made the swapchain without the latency mode (the presenter asked again without
    // it): the reducer can't work, whatever the policy has told it.
    swapchain_refused_.store(true, std::memory_order_release);
  }
  if (swapchain_ == VK_NULL_HANDLE || !nvidia_ || !swapchain_latency_mode_ || !mode_set_) {
    return;
  }
  // The mode belongs to the swapchain.
  VkLatencySleepModeInfoNV mode = {VK_STRUCTURE_TYPE_LATENCY_SLEEP_MODE_INFO_NV};
  mode.lowLatencyMode = mode_on_ ? VK_TRUE : VK_FALSE;
  mode.lowLatencyBoost = mode_boost_ ? VK_TRUE : VK_FALSE;
  mode.minimumIntervalUs = mode_interval_us_;
  const VkResult result =
      device_->functions().vkSetLatencySleepModeNV(device_->device(), swapchain_, &mode);
  if (result != VK_SUCCESS) {
    REXLOG_WARN("Low latency: vkSetLatencySleepModeNV failed ({})", int32_t(result));
  }
}

void VulkanLowLatency::NotifyOutOfBandPresentQueue(VkQueue queue) {
  if (!nvidia_ || !queue) {
    return;
  }
  VkOutOfBandQueueTypeInfoNV info = {VK_STRUCTURE_TYPE_OUT_OF_BAND_QUEUE_TYPE_INFO_NV};
  info.queueType = VK_OUT_OF_BAND_QUEUE_TYPE_PRESENT_NV;
  device_->functions().vkQueueNotifyOutOfBandNV(queue, &info);
}

bool VulkanLowLatency::SetMode(bool on, bool boost, uint32_t minimum_interval_us) {
  std::unique_lock lock(swapchain_mutex_);
  if (shut_down_) {
    return true;
  }
  mode_set_ = true;
  mode_on_ = on;
  mode_boost_ = boost;
  mode_interval_us_ = minimum_interval_us;
  if (nvidia_) {
    if (swapchain_ == VK_NULL_HANDLE) {
      // Told to the swapchain when there is one (SetSwapchain).
      return true;
    }
    if (!swapchain_latency_mode_) {
      // The driver made the swapchain without the latency mode (the presenter retried without
      // it): the reducer can't work on it.
      failure_reason_ = "SWAPCHAIN REFUSED IT";
      return false;
    }
    VkLatencySleepModeInfoNV mode = {VK_STRUCTURE_TYPE_LATENCY_SLEEP_MODE_INFO_NV};
    mode.lowLatencyMode = on ? VK_TRUE : VK_FALSE;
    mode.lowLatencyBoost = boost ? VK_TRUE : VK_FALSE;
    mode.minimumIntervalUs = minimum_interval_us;
    const VkResult result =
        device_->functions().vkSetLatencySleepModeNV(device_->device(), swapchain_, &mode);
    if (result != VK_SUCCESS) {
      REXLOG_WARN("Low latency: vkSetLatencySleepModeNV failed ({})", int32_t(result));
      failure_reason_ = "NOT SUPPORTED";
      return false;
    }
    return true;
  }
  anti_lag_on_ = on;
  anti_lag_max_fps_ = minimum_interval_us ? uint32_t(1000000u / minimum_interval_us) : 0;
  VkAntiLagDataAMD data = {VK_STRUCTURE_TYPE_ANTI_LAG_DATA_AMD};
  // Not on: left to the driver's own setting (the user's Adrenalin choice), not forced off.
  data.mode = on ? VK_ANTI_LAG_MODE_ON_AMD : VK_ANTI_LAG_MODE_DRIVER_CONTROL_AMD;
  data.maxFPS = anti_lag_max_fps_;
  device_->functions().vkAntiLagUpdateAMD(device_->device(), &data);
  return true;
}

bool VulkanLowLatency::Sleep(uint64_t frame_id) {
  const VulkanDevice::Functions& dfn = device_->functions();
  if (nvidia_) {
    uint64_t value;
    uint32_t interval_us = 0;
    // The driver call is made under the swapchain's lock (the UI thread retires it under the
    // exclusive one); the wait for its signal is not, so a swapchain change never queues the
    // markers of other threads behind a sleep.
    std::shared_lock semaphore_lock(semaphore_mutex_);
    {
      std::shared_lock lock(swapchain_mutex_);
      if (shut_down_ || swapchain_ == VK_NULL_HANDLE || !swapchain_latency_mode_ ||
          sleep_semaphore_ == VK_NULL_HANDLE) {
        return false;
      }
      value = sleep_value_.fetch_add(1, std::memory_order_relaxed) + 1;
      interval_us = mode_interval_us_;
      VkLatencySleepInfoNV info = {VK_STRUCTURE_TYPE_LATENCY_SLEEP_INFO_NV};
      info.signalSemaphore = sleep_semaphore_;
      info.value = value;
      if (dfn.vkLatencySleepNV(device_->device(), swapchain_, &info) != VK_SUCCESS) {
        return false;
      }
    }
    // Bounded: a driver that never signals it must not hold the game. The bound is a little
    // over what LowLatency::OnFrameStart takes for a wait that is too long (a quarter of a
    // second, or four frame intervals), so that one that times out counts as that.
    const uint64_t timeout_ns = (std::max<uint64_t>(250'000, 4ull * interval_us) + 20'000) * 1000;
    VkSemaphoreWaitInfo wait_info = {VK_STRUCTURE_TYPE_SEMAPHORE_WAIT_INFO};
    wait_info.semaphoreCount = 1;
    wait_info.pSemaphores = &sleep_semaphore_;
    wait_info.pValues = &value;
    const VkResult result = dfn.vkWaitSemaphores(device_->device(), &wait_info, timeout_ns);
    if (result != VK_SUCCESS) {
      if (!sleep_wait_failure_logged_) {
        sleep_wait_failure_logged_ = true;
        REXLOG_WARN("Low latency: the driver's sleep wasn't signalled in {} ms ({})",
                    timeout_ns / 1'000'000, int32_t(result));
      }
      return false;
    }
    return true;
  }
  std::shared_lock lock(swapchain_mutex_);
  if (shut_down_) {
    return false;
  }
  VkAntiLagPresentationInfoAMD presentation = {VK_STRUCTURE_TYPE_ANTI_LAG_PRESENTATION_INFO_AMD};
  presentation.stage = VK_ANTI_LAG_STAGE_INPUT_AMD;
  presentation.frameIndex = frame_id;
  VkAntiLagDataAMD data = {VK_STRUCTURE_TYPE_ANTI_LAG_DATA_AMD};
  data.mode = anti_lag_on_ ? VK_ANTI_LAG_MODE_ON_AMD : VK_ANTI_LAG_MODE_DRIVER_CONTROL_AMD;
  data.maxFPS = anti_lag_max_fps_;
  data.pPresentationInfo = &presentation;
  dfn.vkAntiLagUpdateAMD(device_->device(), &data);
  return true;
}

void VulkanLowLatency::Marker(LatencyMarker marker, uint64_t frame_id) {
  const VulkanDevice::Functions& dfn = device_->functions();
  std::shared_lock lock(swapchain_mutex_);
  if (shut_down_) {
    return;
  }
  if (nvidia_) {
    if (swapchain_ == VK_NULL_HANDLE || !swapchain_latency_mode_) {
      return;
    }
    VkLatencyMarkerNV type;
    switch (marker) {
      case LatencyMarker::kSimulationStart:
        type = VK_LATENCY_MARKER_SIMULATION_START_NV;
        break;
      case LatencyMarker::kSimulationEnd:
        type = VK_LATENCY_MARKER_SIMULATION_END_NV;
        break;
      case LatencyMarker::kRenderSubmitStart:
        type = VK_LATENCY_MARKER_RENDERSUBMIT_START_NV;
        break;
      case LatencyMarker::kRenderSubmitEnd:
        type = VK_LATENCY_MARKER_RENDERSUBMIT_END_NV;
        break;
      case LatencyMarker::kPresentStart:
        type = VK_LATENCY_MARKER_PRESENT_START_NV;
        break;
      case LatencyMarker::kPresentEnd:
        type = VK_LATENCY_MARKER_PRESENT_END_NV;
        break;
      case LatencyMarker::kInputSample:
        type = VK_LATENCY_MARKER_INPUT_SAMPLE_NV;
        break;
      case LatencyMarker::kOutOfBandRenderSubmitStart:
        type = VK_LATENCY_MARKER_OUT_OF_BAND_RENDERSUBMIT_START_NV;
        break;
      case LatencyMarker::kOutOfBandRenderSubmitEnd:
        type = VK_LATENCY_MARKER_OUT_OF_BAND_RENDERSUBMIT_END_NV;
        break;
      case LatencyMarker::kOutOfBandPresentStart:
      case LatencyMarker::kGeneratedPresentStart:
        type = VK_LATENCY_MARKER_OUT_OF_BAND_PRESENT_START_NV;
        break;
      case LatencyMarker::kOutOfBandPresentEnd:
      case LatencyMarker::kGeneratedPresentEnd:
        type = VK_LATENCY_MARKER_OUT_OF_BAND_PRESENT_END_NV;
        break;
      default:
        return;
    }
    VkSetLatencyMarkerInfoNV info = {VK_STRUCTURE_TYPE_SET_LATENCY_MARKER_INFO_NV};
    info.presentID = frame_id;
    info.marker = type;
    dfn.vkSetLatencyMarkerNV(device_->device(), swapchain_, &info);
  } else if (marker == LatencyMarker::kPresentStart ||
             marker == LatencyMarker::kOutOfBandPresentStart) {
    // The present stage, just before the vkQueuePresentKHR of the frame's image (the swapchain's
    // own present, or the pacer's real frame's).
    VkAntiLagPresentationInfoAMD presentation = {VK_STRUCTURE_TYPE_ANTI_LAG_PRESENTATION_INFO_AMD};
    presentation.stage = VK_ANTI_LAG_STAGE_PRESENT_AMD;
    presentation.frameIndex = frame_id;
    VkAntiLagDataAMD data = {VK_STRUCTURE_TYPE_ANTI_LAG_DATA_AMD};
    data.mode = anti_lag_on_ ? VK_ANTI_LAG_MODE_ON_AMD : VK_ANTI_LAG_MODE_DRIVER_CONTROL_AMD;
    data.maxFPS = anti_lag_max_fps_;
    data.pPresentationInfo = &presentation;
    dfn.vkAntiLagUpdateAMD(device_->device(), &data);
  }
}

std::string VulkanLowLatency::TimingReport() {
  if (!nvidia_) {
    return std::string();
  }
  const VulkanDevice::Functions& dfn = device_->functions();
  std::shared_lock lock(swapchain_mutex_);
  if (shut_down_ || swapchain_ == VK_NULL_HANDLE || !swapchain_latency_mode_) {
    return std::string();
  }
  VkGetLatencyMarkerInfoNV info = {VK_STRUCTURE_TYPE_GET_LATENCY_MARKER_INFO_NV};
  dfn.vkGetLatencyTimingsNV(device_->device(), swapchain_, &info);
  const uint32_t count = std::min(info.timingCount, 64u);
  if (!count) {
    return "no frame report yet";
  }
  std::vector<VkLatencyTimingsFrameReportNV> reports(count);
  for (VkLatencyTimingsFrameReportNV& report : reports) {
    report = {VK_STRUCTURE_TYPE_LATENCY_TIMINGS_FRAME_REPORT_NV};
  }
  info.timingCount = count;
  info.pTimings = reports.data();
  dfn.vkGetLatencyTimingsNV(device_->device(), swapchain_, &info);
  double input_to_render_end = 0.0, input_to_present_end = 0.0, sim_to_render_end = 0.0;
  double gpu_span = 0.0;
  // The stages of a frame, for the driver's report: the guest (simulation start to the first
  // render submit), the GPU thread (render submit), the wait to the GPU (render submit end to the
  // GPU's start), the GPU (start to end).
  double stage_guest = 0.0, stage_submit = 0.0, stage_to_gpu = 0.0;
  int used = 0;
  for (uint32_t i = info.timingCount; i-- > 0 && used < 32;) {
    const VkLatencyTimingsFrameReportNV& f = reports[i];
    if (!f.presentID || !f.gpuRenderEndTimeUs || !f.inputSampleTimeUs || !f.simStartTimeUs ||
        !f.presentEndTimeUs) {
      continue;
    }
    input_to_render_end += double(int64_t(f.gpuRenderEndTimeUs - f.inputSampleTimeUs));
    input_to_present_end += double(int64_t(f.presentEndTimeUs - f.inputSampleTimeUs));
    sim_to_render_end += double(int64_t(f.gpuRenderEndTimeUs - f.simStartTimeUs));
    gpu_span += double(int64_t(f.gpuRenderEndTimeUs - f.gpuRenderStartTimeUs));
    stage_guest += double(int64_t(f.renderSubmitStartTimeUs - f.simStartTimeUs));
    stage_submit += double(int64_t(f.renderSubmitEndTimeUs - f.renderSubmitStartTimeUs));
    stage_to_gpu += double(int64_t(f.gpuRenderStartTimeUs - f.renderSubmitEndTimeUs));
    ++used;
  }
  if (!used) {
    return "no complete frame report yet";
  }
  std::string frames;
  if (REXCVAR_GET(low_latency_debug) & 8) {
    // The newest frames' times from each one's simulation start, in ms.
    int shown = 0;
    for (uint32_t i = info.timingCount; i-- > 0 && shown < 4;) {
      const VkLatencyTimingsFrameReportNV& f = reports[i];
      if (!f.presentID || !f.gpuRenderEndTimeUs || !f.simStartTimeUs) {
        continue;
      }
      auto at = [&f](uint64_t time) { return (double(int64_t(time - f.simStartTimeUs))) / 1000.0; };
      char frame[320];
      std::snprintf(frame, sizeof frame,
                    " [%llu: sim end %.1f, submit %.1f-%.1f, present %.1f-%.1f, driver %.1f-%.1f, "
                    "gpu %.1f-%.1f]",
                    (unsigned long long)f.presentID, at(f.simEndTimeUs),
                    at(f.renderSubmitStartTimeUs), at(f.renderSubmitEndTimeUs),
                    at(f.presentStartTimeUs), at(f.presentEndTimeUs), at(f.driverStartTimeUs),
                    at(f.driverEndTimeUs), at(f.gpuRenderStartTimeUs), at(f.gpuRenderEndTimeUs));
      frames += frame;
      ++shown;
    }
  }
  char text[480];
  std::snprintf(text, sizeof text,
                "driver's report over %d frames: input sample to GPU render end %.2f ms, to "
                "present end %.2f ms, simulation start to GPU render end %.2f ms, GPU active "
                "%.2f ms; stages: simulation start to render submit start %.2f ms, render submit "
                "%.2f ms, render submit end to GPU start %.2f ms",
                used, input_to_render_end / used / 1000.0, input_to_present_end / used / 1000.0,
                sim_to_render_end / used / 1000.0, gpu_span / used / 1000.0,
                stage_guest / used / 1000.0, stage_submit / used / 1000.0,
                stage_to_gpu / used / 1000.0);
  return text + frames;
}

}  // namespace vulkan
}  // namespace ui
}  // namespace rex
