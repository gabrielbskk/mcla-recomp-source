/**
 ******************************************************************************
 * ReXGlue: UI overlay painting (rexglue-presenter-ui-overlay.patch), Vulkan    *
 * side of the presenter: the overlay layers the UI thread draws its drawers   *
 * into, and their composite over the image in the guest output's paint.      *
 ******************************************************************************
 */

#include <cstdint>

#include <rex/logging.h>
#include <rex/ui/vulkan/presenter.h>
#include <rex/ui/vulkan/util.h>

namespace rex {
namespace ui {
namespace vulkan {

bool VulkanPresenter::SupportsUIOverlayPaintMode() const { return true; }

void VulkanPresenter::CreateUIOverlayFromUIThread() {
  if (!ui_overlay_paint_mode() || paint_context_.swapchain == VK_NULL_HANDLE) {
    return;
  }
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  const VkExtent2D extent = paint_context_.swapchain_extent;

  // The UI overlay layers.
  bool overlay_created = true;
  for (uint32_t i = 0; i < 2 && overlay_created; ++i) {
    VkImageCreateInfo image_create_info = {};
    image_create_info.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    image_create_info.imageType = VK_IMAGE_TYPE_2D;
    image_create_info.format = kHdrUiLayerFormat;
    image_create_info.extent = {extent.width, extent.height, 1};
    image_create_info.mipLevels = 1;
    image_create_info.arrayLayers = 1;
    image_create_info.samples = VK_SAMPLE_COUNT_1_BIT;
    image_create_info.tiling = VK_IMAGE_TILING_OPTIMAL;
    image_create_info.usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    image_create_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    image_create_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    if (!util::CreateDedicatedAllocationImage(vulkan_device_, image_create_info,
                                              util::MemoryPurpose::kDeviceLocal,
                                              paint_context_.ui_overlay_images[i],
                                              paint_context_.ui_overlay_memory[i])) {
      overlay_created = false;
      break;
    }
    VkImageViewCreateInfo view_create_info = {};
    view_create_info.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    view_create_info.image = paint_context_.ui_overlay_images[i];
    view_create_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
    view_create_info.format = kHdrUiLayerFormat;
    view_create_info.subresourceRange = util::InitializeSubresourceRange();
    if (dfn.vkCreateImageView(device, &view_create_info, nullptr,
                              &paint_context_.ui_overlay_views[i]) != VK_SUCCESS) {
      overlay_created = false;
      break;
    }
    VkFramebufferCreateInfo framebuffer_create_info = {};
    framebuffer_create_info.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    framebuffer_create_info.renderPass = hdr_ui_layer_render_pass_;
    framebuffer_create_info.attachmentCount = 1;
    framebuffer_create_info.pAttachments = &paint_context_.ui_overlay_views[i];
    framebuffer_create_info.width = extent.width;
    framebuffer_create_info.height = extent.height;
    framebuffer_create_info.layers = 1;
    if (dfn.vkCreateFramebuffer(device, &framebuffer_create_info, nullptr,
                                &paint_context_.ui_overlay_framebuffers[i]) != VK_SUCCESS) {
      overlay_created = false;
      break;
    }
    // No paint binds these before a layer is published, and the paints that
    // used the previous layers were awaited when those were destroyed.
    VkDescriptorImageInfo image_info = {VK_NULL_HANDLE, paint_context_.ui_overlay_views[i],
                                        VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
    VkWriteDescriptorSet write = {};
    write.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    write.dstSet = paint_context_.guest_output_descriptor_sets
                       [PaintContext::kGuestOutputDescriptorSetUiOverlay0Sampled + i];
    write.descriptorCount = 1;
    write.descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
    write.pImageInfo = &image_info;
    dfn.vkUpdateDescriptorSets(device, 1, &write, 0, nullptr);
  }
  if (!overlay_created) {
    REXLOG_ERROR("VulkanPresenter: Failed to create the UI overlay layers");
    ui_overlay_creation_failed_ = true;
  }
  ui_overlay_next_layer_ = 0;
}

void VulkanPresenter::DestroyUIOverlayFromUIThread() {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  // The guest output thread's paints (which read the overlay) and the UI
  // thread's overlay drawing are over.
  paint_context_.submission_tracker.AwaitAllSubmissionsCompletion();
  ui_submission_tracker_.AwaitAllSubmissionsCompletion();
  ui_overlay_published_.store(UINT32_MAX, std::memory_order_release);
  ui_overlay_creation_failed_ = false;
  for (uint32_t i = 0; i < 2; ++i) {
    util::DestroyAndNullHandle(dfn.vkDestroyFramebuffer, device,
                               paint_context_.ui_overlay_framebuffers[i]);
    util::DestroyAndNullHandle(dfn.vkDestroyImageView, device, paint_context_.ui_overlay_views[i]);
    util::DestroyAndNullHandle(dfn.vkDestroyImage, device, paint_context_.ui_overlay_images[i]);
    util::DestroyAndNullHandle(dfn.vkFreeMemory, device, paint_context_.ui_overlay_memory[i]);
  }
}

void VulkanPresenter::ShutdownUIOverlay() {
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  DestroyUIOverlayFromUIThread();
  for (uint32_t i = 0; i < 2; ++i) {
    ui_overlay_command_buffers_[i] = VK_NULL_HANDLE;
    util::DestroyAndNullHandle(dfn.vkDestroyCommandPool, device, ui_overlay_command_pools_[i]);
  }
  util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, ui_overlay_composite_pipeline_);
  util::DestroyAndNullHandle(dfn.vkDestroyShaderModule, device, ui_overlay_composite_fs_);
}

bool VulkanPresenter::RenderUIOverlayFromUIThread() {
  // Made for the first drawer shown. No paint uses their descriptor sets
  // before a layer is published, and the paints of the previous connection's
  // layers were awaited when those were destroyed.
  if (paint_context_.ui_overlay_framebuffers[0] == VK_NULL_HANDLE && !ui_overlay_creation_failed_) {
    CreateUIOverlayFromUIThread();
  }
  if (paint_context_.ui_overlay_framebuffers[0] == VK_NULL_HANDLE ||
      paint_context_.ui_overlay_framebuffers[1] == VK_NULL_HANDLE) {
    return false;
  }
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  const uint32_t layer = ui_overlay_next_layer_;
  if (ui_overlay_command_pools_[layer] == VK_NULL_HANDLE) {
    VkCommandPoolCreateInfo pool_create_info = {};
    pool_create_info.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    pool_create_info.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT;
    pool_create_info.queueFamilyIndex = vulkan_device_->queue_family_graphics_compute();
    if (dfn.vkCreateCommandPool(device, &pool_create_info, nullptr,
                                &ui_overlay_command_pools_[layer]) != VK_SUCCESS) {
      return false;
    }
    VkCommandBufferAllocateInfo allocate_info = {};
    allocate_info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    allocate_info.commandPool = ui_overlay_command_pools_[layer];
    allocate_info.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocate_info.commandBufferCount = 1;
    if (dfn.vkAllocateCommandBuffers(device, &allocate_info,
                                     &ui_overlay_command_buffers_[layer]) != VK_SUCCESS) {
      util::DestroyAndNullHandle(dfn.vkDestroyCommandPool, device,
                                 ui_overlay_command_pools_[layer]);
      return false;
    }
  }
  // The command buffer's previous use; the guest output thread's reads of the
  // layer are ordered against this drawing by the layer render pass's
  // dependencies (both on the graphics queue).
  ui_submission_tracker_.AwaitSubmissionCompletion(ui_overlay_submissions_[layer]);
  VkCommandBuffer command_buffer = ui_overlay_command_buffers_[layer];
  dfn.vkResetCommandPool(device, ui_overlay_command_pools_[layer], 0);
  VkCommandBufferBeginInfo begin_info = {};
  begin_info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
  begin_info.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
  dfn.vkBeginCommandBuffer(command_buffer, &begin_info);
  VkClearValue clear_value = {};
  VkRenderPassBeginInfo pass_begin_info = {};
  pass_begin_info.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
  pass_begin_info.renderPass = hdr_ui_layer_render_pass_;
  pass_begin_info.framebuffer = paint_context_.ui_overlay_framebuffers[layer];
  pass_begin_info.renderArea.extent = paint_context_.swapchain_extent;
  pass_begin_info.clearValueCount = 1;
  pass_begin_info.pClearValues = &clear_value;
  dfn.vkCmdBeginRenderPass(command_buffer, &pass_begin_info, VK_SUBPASS_CONTENTS_INLINE);
  const uint64_t submission = ui_submission_tracker_.GetCurrentSubmission();
  {
    VulkanUIDrawContext ui_draw_context(
        *this, paint_context_.swapchain_extent.width, paint_context_.swapchain_extent.height,
        command_buffer, submission, ui_submission_tracker_.UpdateAndGetCompletedSubmission(),
        hdr_ui_layer_render_pass_, kHdrUiLayerFormat);
    ExecuteUIDrawersFromUIThread(ui_draw_context);
  }
  dfn.vkCmdEndRenderPass(command_buffer);
  dfn.vkEndCommandBuffer(command_buffer);

  VkCommandBuffer command_buffers[2];
  uint32_t command_buffer_count = 0;
  const size_t setup_index = paint_context_.ui_setup_command_buffer_current_index;
  if (setup_index != SIZE_MAX) {
    PaintContext::UISetupCommandBuffer& setup = paint_context_.ui_setup_command_buffers[setup_index];
    dfn.vkEndCommandBuffer(setup.command_buffer);
    command_buffers[command_buffer_count++] = setup.command_buffer;
    paint_context_.ui_setup_command_buffer_current_index = SIZE_MAX;
  }
  command_buffers[command_buffer_count++] = command_buffer;
  VkSubmitInfo submit_info = {};
  submit_info.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
  submit_info.commandBufferCount = command_buffer_count;
  submit_info.pCommandBuffers = command_buffers;
  VkResult submit_result;
  {
    VulkanSubmissionTracker::FenceAcquisition fence_acquisition =
        ui_submission_tracker_.AcquireFenceToAdvanceSubmission();
    {
      const VulkanDevice::Queue::Acquisition queue_acquisition =
          vulkan_device_->AcquireQueue(vulkan_device_->queue_family_graphics_compute(), 0);
      submit_result = dfn.vkQueueSubmit(queue_acquisition.queue(), 1, &submit_info,
                                        fence_acquisition.fence());
    }
    if (submit_result != VK_SUCCESS) {
      fence_acquisition.SubmissionFailedOrDropped();
      if (setup_index != SIZE_MAX) {
        paint_context_.ui_setup_command_buffers[setup_index].last_usage_submission_index = 0;
      }
    }
  }
  if (submit_result != VK_SUCCESS) {
    return false;
  }
  ui_overlay_submissions_[layer] = submission;
  // A paint that reads it is submitted to the same queue after this.
  ui_overlay_published_.store(layer, std::memory_order_release);
  ui_overlay_next_layer_ = layer ^ 1;
  return true;
}

void VulkanPresenter::CompositeUIOverlay(VkCommandBuffer command_buffer) {
  const uint32_t layer = ui_overlay_published_.load(std::memory_order_acquire);
  if (layer >= 2 || paint_context_.ui_overlay_framebuffers[layer] == VK_NULL_HANDLE) {
    return;
  }
  const VulkanDevice::Functions& dfn = vulkan_device_->functions();
  const VkDevice device = vulkan_device_->device();
  const bool hdr = paint_context_.swapchain_hdr;
  VkPipeline& pipeline = hdr ? hdr_ui_composite_pipeline_ : ui_overlay_composite_pipeline_;
  VkFormat& pipeline_format =
      hdr ? hdr_ui_composite_pipeline_format_ : ui_overlay_composite_pipeline_format_;
  if (pipeline_format != paint_context_.swapchain_render_pass_format) {
    if (pipeline != VK_NULL_HANDLE) {
      paint_context_.submission_tracker.AwaitAllSubmissionsCompletion();
      util::DestroyAndNullHandle(dfn.vkDestroyPipeline, device, pipeline);
    }
    pipeline = CreateGuestOutputPaintPipeline(
        GuestOutputPaintEffect::kBilinear, paint_context_.swapchain_render_pass,
        hdr ? hdr_ui_composite_fs_ : ui_overlay_composite_fs_, true);
    pipeline_format = paint_context_.swapchain_render_pass_format;
  }
  if (pipeline == VK_NULL_HANDLE) {
    return;
  }
  VkPipelineLayout layout =
      guest_output_paint_pipeline_layouts_[kGuestOutputPaintPipelineLayoutIndexBilinear];
  dfn.vkCmdBindPipeline(command_buffer, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);
  dfn.vkCmdBindDescriptorSets(
      command_buffer, VK_PIPELINE_BIND_POINT_GRAPHICS, layout, 0, 1,
      &paint_context_.guest_output_descriptor_sets
           [PaintContext::kGuestOutputDescriptorSetUiOverlay0Sampled + layer],
      0, nullptr);
  VkViewport viewport = {0.0f, 0.0f, float(paint_context_.swapchain_extent.width),
                         float(paint_context_.swapchain_extent.height), 0.0f, 1.0f};
  dfn.vkCmdSetViewport(command_buffer, 0, 1, &viewport);
  VkRect2D scissor = {{0, 0}, paint_context_.swapchain_extent};
  dfn.vkCmdSetScissor(command_buffer, 0, 1, &scissor);
  GuestOutputPaintRectangleConstants whole_image;
  whole_image.x = -1.0f;
  whole_image.y = -1.0f;
  whole_image.width = 2.0f;
  whole_image.height = 2.0f;
  dfn.vkCmdPushConstants(command_buffer, layout, VK_SHADER_STAGE_VERTEX_BIT, 0,
                         sizeof(whole_image), &whole_image);
  if (hdr) {
    HdrOutputState hdr_state = GetHdrOutputState();
    const float ui_levels[] = {hdr_state.sdr_white_nits,
                               hdr_state.sdr_pure_gamma_2_2 ? 1.0f : 0.0f, 0.0f, 0.0f};
    dfn.vkCmdPushConstants(command_buffer, layout, VK_SHADER_STAGE_FRAGMENT_BIT,
                           sizeof(whole_image), sizeof(ui_levels), ui_levels);
  }
  dfn.vkCmdDraw(command_buffer, 4, 1, 0, 0);
}

}  // namespace vulkan
}  // namespace ui
}  // namespace rex
