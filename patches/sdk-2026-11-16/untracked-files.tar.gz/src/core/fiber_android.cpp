/**
 * @file        rex/core/fiber_android.cpp
 * @brief       AArch64 cooperative fiber switching for Android/Bionic
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#include <rex/platform.h>
#if REX_PLATFORM_ANDROID && REX_ARCH_ARM64

#include <rex/thread/fiber.h>

#include <cassert>
#include <exception>

namespace rex::thread {

thread_local Fiber* Fiber::tls_current_ = nullptr;

extern "C" __attribute__((naked)) void RexFiberSwitch(void*, const void*) {
  __asm__ volatile(
      "stp x19, x20, [x0, #0]\n"
      "stp x21, x22, [x0, #16]\n"
      "stp x23, x24, [x0, #32]\n"
      "stp x25, x26, [x0, #48]\n"
      "stp x27, x28, [x0, #64]\n"
      "stp x29, x30, [x0, #80]\n"
      "stp d8, d9, [x0, #96]\n"
      "stp d10, d11, [x0, #112]\n"
      "stp d12, d13, [x0, #128]\n"
      "stp d14, d15, [x0, #144]\n"
      "mov x2, sp\n"
      "str x2, [x0, #160]\n"
      "ldp x19, x20, [x1, #0]\n"
      "ldp x21, x22, [x1, #16]\n"
      "ldp x23, x24, [x1, #32]\n"
      "ldp x25, x26, [x1, #48]\n"
      "ldp x27, x28, [x1, #64]\n"
      "ldp x29, x30, [x1, #80]\n"
      "ldp d8, d9, [x1, #96]\n"
      "ldp d10, d11, [x1, #112]\n"
      "ldp d12, d13, [x1, #128]\n"
      "ldp d14, d15, [x1, #144]\n"
      "ldr x2, [x1, #160]\n"
      "mov sp, x2\n"
      "ret\n");
}

Fiber* Fiber::ConvertCurrentThread() {
  auto* fiber = new Fiber();
  fiber->is_thread_fiber_ = true;
  tls_current_ = fiber;
  return fiber;
}

Fiber* Fiber::Create(size_t stack_size, void (*entry)(void*), void* arg) {
  auto* fiber = new Fiber();
  fiber->entry_ = entry;
  fiber->arg_ = arg;
  fiber->stack_.resize(stack_size);
  uintptr_t stack_top = reinterpret_cast<uintptr_t>(fiber->stack_.data() + fiber->stack_.size());
  stack_top &= ~uintptr_t(15);
  fiber->context_.registers[11] = reinterpret_cast<uintptr_t>(&Fiber::Trampoline);  // x30
  fiber->context_.registers[20] = stack_top;  // SP
  return fiber;
}

void Fiber::Trampoline() {
  Fiber* fiber = tls_current_;
  assert(fiber && fiber->entry_);
  fiber->entry_(fiber->arg_);
  std::terminate();
}

void Fiber::SwitchTo(Fiber* target) {
  Fiber* from = tls_current_;
  assert(from && target);
  tls_current_ = target;
  RexFiberSwitch(from->context_.registers, target->context_.registers);
}

void Fiber::Destroy() {
  if (is_thread_fiber_) {
    tls_current_ = nullptr;
  } else {
    assert(this != tls_current_ && "Destroy called on the currently running fiber");
  }
  delete this;
}

}  // namespace rex::thread

#endif  // REX_PLATFORM_ANDROID && REX_ARCH_ARM64
