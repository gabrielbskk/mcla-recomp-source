/**
 * Android content URI helpers. The app imports game data into its private
 * filesystem, so direct mmap of a Storage Access Framework URI is not needed.
 */

#include <rex/filesystem.h>
#include <rex/platform.h>

#if REX_PLATFORM_ANDROID
namespace rex::filesystem {

bool IsAndroidContentUri(const std::string_view source) {
  return source.starts_with("content://");
}

int OpenAndroidContentFileDescriptor(const std::string_view, const char*) {
  return -1;
}

}  // namespace rex::filesystem
#endif  // REX_PLATFORM_ANDROID
