/**
 * @file        audio/audio_thread.cpp
 * @brief       Host scheduling of the audio threads (fork addition)
 *
 * Added by the mcla-recomp fork (patches/rexglue-xma-decoder-fixes.patch).
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

#include <algorithm>
#include <cstdint>
#include <string>

#include <rex/audio/audio_dump.h>
#include <rex/audio/audio_system.h>
#include <rex/audio/flags.h>
#include <rex/logging.h>

namespace rex::audio {

#if defined(_WIN32)
namespace {

enum class Mmcss { kJoined, kFailed, kNoAvrt };

// The calling thread joins the Windows multimedia scheduler (task "Pro Audio"). avrt.dll is loaded by hand so that
// nothing has to be linked for it. `value` is the task index when joined, else the error.
Mmcss JoinMmcss(uint32_t* value) {
  using SetCharacteristics = HANDLE(WINAPI*)(LPCWSTR, LPDWORD);
  static const SetCharacteristics set_characteristics = []() -> SetCharacteristics {
    HMODULE avrt = LoadLibraryW(L"avrt.dll");
    return avrt ? reinterpret_cast<SetCharacteristics>(
                      reinterpret_cast<void*>(GetProcAddress(avrt, "AvSetMmThreadCharacteristicsW")))
                : nullptr;
  }();
  if (!set_characteristics) {
    *value = 0;
    return Mmcss::kNoAvrt;
  }
  DWORD task_index = 0;
  HANDLE task = set_characteristics(L"Pro Audio", &task_index);
  if (task) {
    *value = static_cast<uint32_t>(task_index);
    return Mmcss::kJoined;
  }
  *value = static_cast<uint32_t>(GetLastError());
  return Mmcss::kFailed;
}

}  // namespace
#endif

void EnterAudioThreadMmcss([[maybe_unused]] const char* thread_name) {
#if defined(_WIN32)
  if (REXCVAR_GET(audio_thread_priority) < 3) {
    return;
  }
  uint32_t value = 0;
  switch (JoinMmcss(&value)) {
    case Mmcss::kNoAvrt:
      REXAPU_WARN("audio_thread_priority 3: avrt.dll is not available, {} stays outside MMCSS", thread_name);
      break;
    case Mmcss::kJoined:
      REXAPU_INFO("{} joined MMCSS (task \"Pro Audio\", index {})", thread_name, value);
      break;
    case Mmcss::kFailed:
      REXAPU_WARN("{} could not join MMCSS (error {})", thread_name, value);
      break;
  }
#endif
}

bool RaiseCallingAudioThread([[maybe_unused]] int32_t level, [[maybe_unused]] const char* thread_name) {
#if defined(_WIN32)
  if (level <= 0) {
    return false;
  }
  const bool highest = level >= 2;
  const bool set =
      SetThreadPriority(GetCurrentThread(), highest ? THREAD_PRIORITY_HIGHEST : THREAD_PRIORITY_ABOVE_NORMAL) != 0;
  const uint32_t priority_error = set ? 0 : static_cast<uint32_t>(GetLastError());
  std::string mmcss = "not asked (level below 3)";
  if (level >= 3) {
    uint32_t value = 0;
    switch (JoinMmcss(&value)) {
      case Mmcss::kJoined:
        mmcss = "joined (task \"Pro Audio\", index " + std::to_string(value) + ")";
        break;
      case Mmcss::kFailed:
        mmcss = "could not join (error " + std::to_string(value) + ")";
        break;
      case Mmcss::kNoAvrt:
        mmcss = "not available (avrt.dll)";
        break;
    }
  }
  if (set) {
    REXAPU_INFO("{}: host priority {}, MMCSS {} (level {})", thread_name, highest ? "highest" : "above normal", mmcss,
                level);
  } else {
    REXAPU_WARN("{}: host priority NOT raised (error {}), MMCSS {} (level {})", thread_name, priority_error, mmcss,
                level);
  }
  return set;
#else
  return false;
#endif
}

}  // namespace rex::audio

namespace rex::audio::dump {

#if defined(_WIN32)
namespace {
using QueryThreadCycleTimeFn = BOOL(WINAPI*)(HANDLE, PULONG64);
QueryThreadCycleTimeFn g_query_cycles = nullptr;
double g_cycles_per_ns = 0.0;  // 0: no clock
}  // namespace

// QueryThreadCycleTime is found by name so that no import library has to be linked for it (both toolchains).
// Its unit is the processor's time-stamp counter on current Windows (4.7 cycles per ns on a 4.7 GHz Ryzen, checked),
// but that is not promised, so the factor is measured: the thread spins for about 8 ms against the performance
// counter, three times, and the largest ratio is kept (a spell in which the thread was preempted only lowers it).
void InitThreadCpuClock() {
  if (g_cycles_per_ns > 0.0) {
    return;
  }
  HMODULE kernel = GetModuleHandleW(L"kernel32.dll");
  g_query_cycles = kernel ? reinterpret_cast<QueryThreadCycleTimeFn>(
                                reinterpret_cast<void*>(GetProcAddress(kernel, "QueryThreadCycleTime")))
                          : nullptr;
  if (!g_query_cycles) {
    REXAPU_WARN("audio stats: QueryThreadCycleTime is not available, the CPU times stay na");
    return;
  }
  LARGE_INTEGER freq{};
  QueryPerformanceFrequency(&freq);
  double best = 0.0;
  for (int i = 0; i < 3 && freq.QuadPart > 0; ++i) {
    ULONG64 c0 = 0, c1 = 0;
    LARGE_INTEGER t0{}, t1{};
    QueryPerformanceCounter(&t0);
    g_query_cycles(GetCurrentThread(), &c0);
    do {
      QueryPerformanceCounter(&t1);
    } while ((t1.QuadPart - t0.QuadPart) * 1000 < freq.QuadPart * 8);
    g_query_cycles(GetCurrentThread(), &c1);
    const double ns = static_cast<double>(t1.QuadPart - t0.QuadPart) * 1e9 / static_cast<double>(freq.QuadPart);
    best = std::max(best, static_cast<double>(c1 - c0) / ns);
  }
  if (best <= 0.0) {
    REXAPU_WARN("audio stats: the thread cycle counter did not move, the CPU times stay na");
    return;
  }
  g_cycles_per_ns = best;
  REXAPU_INFO("audio stats: thread CPU times from QueryThreadCycleTime ({:.0f} cycles per microsecond, measured now)",
              best * 1000.0);
}

uint64_t ThreadCpuNs() {
  ULONG64 cycles = 0;
  if (g_cycles_per_ns <= 0.0 || !g_query_cycles(GetCurrentThread(), &cycles)) {
    return 0;
  }
  return static_cast<uint64_t>(static_cast<double>(cycles) / g_cycles_per_ns);
}

bool ThreadCpuAvailable() {
  return g_cycles_per_ns > 0.0;
}
#else
void InitThreadCpuClock() {}
uint64_t ThreadCpuNs() {
  return 0;
}
bool ThreadCpuAvailable() {
  return false;
}
#endif

}  // namespace rex::audio::dump
