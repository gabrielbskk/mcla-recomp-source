/**
 * @file        audio/audio_dump.cpp
 * @brief       Counters and WAV dumps of the audio path (fork instrumentation)
 *
 * Added by the mcla-recomp fork (patches/rexglue-xma-decoder-fixes.patch).
 *
 * @license     BSD 3-Clause License
 *              See LICENSE file in the project root for full license text.
 */

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <rex/audio/audio_dump.h>
#include <rex/cvar.h>
#include <rex/logging.h>

REXCVAR_DEFINE_BOOL(audio_stats, false, "Audio",
                    "Dev tool: log counters of the audio path every audio_stats_interval seconds (an "
                    "'interval' line, and a cumulative 'TOTAL' line: the last one is the result) and at exit "
                    "(XMA decoding and what the game wrote into a context meanwhile, the audio worker's pumps, "
                    "the SDL output's underruns)");
REXCVAR_DEFINE_INT32(audio_stats_interval, 10, "Audio", "Dev tool: seconds between audio_stats lines")
    .range(1, 600);
REXCVAR_DEFINE_STRING(audio_dump_dir, "", "Audio",
                      "Dev tool: write the audio path to files in this folder: what every XMA context decodes "
                      "(xma_ctx<N>_s<M>.wav, with its input in .xma and a .json), and the final mix (mix.wav, "
                      "32-bit float, as the output device gets it). Empty = off");
REXCVAR_DEFINE_INT32(audio_dump_max_mb, 2048, "Audio",
                     "Dev tool: stop writing dump files after this many megabytes in all")
    .range(1, 65536);

namespace rex::audio::dump {

namespace {

std::atomic<bool> g_stats{false};
std::atomic<bool> g_dump{false};
std::string g_dir;
std::chrono::steady_clock::time_point g_start = std::chrono::steady_clock::now();
std::atomic<uint64_t> g_budget{0};
std::atomic<uint32_t> g_session{0};
thread_local bool tls_xma_worker = false;
Counters g_counters;

// The reporter thread and its flags live on the heap and are never destroyed while the thread may
// still run: a global std::thread that is still joinable when the static destructors run ends in
// std::terminate (the game leaves through std::_Exit, which kills every thread and then runs the
// DLLs' static destructors). The thread polls its flags (no lock, nothing a killed thread could
// leave locked).
struct Reporter {
  std::thread thread;
  std::atomic<bool> stop{false};
  std::atomic<bool> finished{false};
};
Reporter* g_reporter = nullptr;
bool g_initialized = false;
std::atomic<ExtraStatsFn> g_extra_stats{nullptr};
std::atomic<bool> g_total_written{false};

// Maxima and minima over the whole run, as of the last interval (the counters' own are reset at every one).
std::atomic<uint64_t> g_run_work_max{0};
std::atomic<uint64_t> g_run_pump_max{0};
std::atomic<uint64_t> g_run_gap_max{0};
std::atomic<uint64_t> g_run_queue_min{~0ull};

struct Snapshot {
  uint64_t xma_work_inline = 0, xma_work_worker = 0, xma_work_us = 0, xma_work_slow = 0, xma_kicks = 0,
           xma_frames = 0, xma_decode_errors = 0, xma_recheck_abort = 0, xma_stalled_loops = 0,
           xma_cas_retries = 0, wrote_rd = 0, wrote_valid = 0, wrote_other = 0, pump_count = 0,
           pump_us = 0, pump_late = 0, pump_over_4ms = 0, pump_over_8ms = 0, sdl_callbacks = 0, sdl_frames = 0,
           sdl_underruns = 0, sdl_underruns_steady = 0, sdl_queue_grown = 0, wake_lt1 = 0, wake_lt2 = 0, wake_lt4 = 0,
           wake_lt8 = 0, wake_lt16 = 0, wake_ge16 = 0;
};

Snapshot Take() {
  Counters& c = g_counters;
  const auto ld = [](const std::atomic<uint64_t>& a) { return a.load(std::memory_order_relaxed); };
  Snapshot s;
  s.xma_work_inline = ld(c.xma_work_inline);
  s.xma_work_worker = ld(c.xma_work_worker);
  s.xma_work_us = ld(c.xma_work_us);
  s.xma_work_slow = ld(c.xma_work_slow);
  s.xma_kicks = ld(c.xma_kicks);
  s.xma_frames = ld(c.xma_frames);
  s.xma_decode_errors = ld(c.xma_decode_errors);
  s.xma_recheck_abort = ld(c.xma_recheck_abort);
  s.xma_stalled_loops = ld(c.xma_stalled_loops);
  s.xma_cas_retries = ld(c.xma_cas_retries);
  s.wrote_rd = ld(c.xma_game_wrote_read_offset);
  s.wrote_valid = ld(c.xma_game_wrote_valid);
  s.wrote_other = ld(c.xma_game_wrote_other);
  s.pump_count = ld(c.pump_count);
  s.pump_us = ld(c.pump_us);
  s.pump_late = ld(c.pump_late);
  s.pump_over_4ms = ld(c.pump_over_4ms);
  s.pump_over_8ms = ld(c.pump_over_8ms);
  s.sdl_callbacks = ld(c.sdl_callbacks);
  s.sdl_frames = ld(c.sdl_frames);
  s.sdl_underruns = ld(c.sdl_underruns);
  s.sdl_underruns_steady = ld(c.sdl_underruns_steady);
  s.sdl_queue_grown = ld(c.sdl_queue_grown);
  s.wake_lt1 = ld(c.wake_lt1);
  s.wake_lt2 = ld(c.wake_lt2);
  s.wake_lt4 = ld(c.wake_lt4);
  s.wake_lt8 = ld(c.wake_lt8);
  s.wake_lt16 = ld(c.wake_lt16);
  s.wake_ge16 = ld(c.wake_ge16);
  return s;
}

uint64_t Div(uint64_t a, uint64_t b) {
  return b ? a / b : 0;
}

// What the host code adds to the end of a line (SetExtraStats).
std::string Extra(bool total) {
  const ExtraStatsFn fn = g_extra_stats.load(std::memory_order_acquire);
  return fn ? fn(total) : std::string();
}

unsigned long long U(uint64_t v) {
  return static_cast<unsigned long long>(v);
}

// One statistics line. `prev` is the snapshot of the last line (zeros for the totals).
std::string Format(const char* label, const Snapshot& now, const Snapshot& prev, uint64_t work_max,
                   uint64_t pump_max, uint64_t gap_max, uint64_t queue_min) {
  const uint64_t works = (now.xma_work_inline - prev.xma_work_inline) +
                         (now.xma_work_worker - prev.xma_work_worker);
  char buf[2048];
  std::snprintf(
      buf, sizeof(buf),
      "audio stats %s t=%.1fs | xma: kicks=%llu work inline=%llu worker=%llu avg_us=%llu max_us=%llu "
      "slow(>2ms)=%llu frames=%llu errors=%llu recheck_abort=%llu stalled=%llu cas_retry=%llu | game wrote "
      "during a decode: read_offset=%llu valid=%llu other=%llu | pump: n=%llu avg_us=%llu max_us=%llu "
      "gap_max_us=%llu late(>8ms)=%llu over4ms=%llu over8ms=%llu | sdl: callbacks=%llu frames=%llu "
      "underruns=%llu queue_min=%llu underruns_steady=%llu silence_max=%llu queue_grown=%llu | wake: lt1ms=%llu "
      "lt2ms=%llu lt4ms=%llu lt8ms=%llu lt16ms=%llu ge16ms=%llu max_us=%llu",
      label, static_cast<double>(NowUs()) / 1e6, U(now.xma_kicks - prev.xma_kicks),
      U(now.xma_work_inline - prev.xma_work_inline), U(now.xma_work_worker - prev.xma_work_worker),
      U(Div(now.xma_work_us - prev.xma_work_us, works)), U(work_max),
      U(now.xma_work_slow - prev.xma_work_slow), U(now.xma_frames - prev.xma_frames),
      U(now.xma_decode_errors - prev.xma_decode_errors), U(now.xma_recheck_abort - prev.xma_recheck_abort),
      U(now.xma_stalled_loops - prev.xma_stalled_loops), U(now.xma_cas_retries - prev.xma_cas_retries),
      U(now.wrote_rd - prev.wrote_rd), U(now.wrote_valid - prev.wrote_valid),
      U(now.wrote_other - prev.wrote_other), U(now.pump_count - prev.pump_count),
      U(Div(now.pump_us - prev.pump_us, now.pump_count - prev.pump_count)), U(pump_max), U(gap_max),
      U(now.pump_late - prev.pump_late), U(now.pump_over_4ms - prev.pump_over_4ms),
      U(now.pump_over_8ms - prev.pump_over_8ms), U(now.sdl_callbacks - prev.sdl_callbacks),
      U(now.sdl_frames - prev.sdl_frames), U(now.sdl_underruns - prev.sdl_underruns),
      U(queue_min == ~0ull ? 0 : queue_min), U(now.sdl_underruns_steady - prev.sdl_underruns_steady),
      U(g_counters.sdl_silence_max.load(std::memory_order_relaxed)), U(now.sdl_queue_grown - prev.sdl_queue_grown),
      U(now.wake_lt1 - prev.wake_lt1), U(now.wake_lt2 - prev.wake_lt2), U(now.wake_lt4 - prev.wake_lt4),
      U(now.wake_lt8 - prev.wake_lt8), U(now.wake_lt16 - prev.wake_lt16), U(now.wake_ge16 - prev.wake_ge16),
      U(g_counters.wake_us_max.load(std::memory_order_relaxed)));
  return buf;
}

// The cumulative line: everything since the start, maxima and minima of the whole run.
std::string TotalLine() {
  Counters& c = g_counters;
  return Format("TOTAL", Take(), Snapshot{},
                std::max(g_run_work_max.load(), c.xma_work_us_max.load()),
                std::max(g_run_pump_max.load(), c.pump_us_max.load()),
                std::max(g_run_gap_max.load(), c.pump_gap_max_us.load()),
                std::min(g_run_queue_min.load(), c.sdl_queue_min.load())) +
         Extra(true);
}

// Writes the final totals next to the dumps (once). The file exists even when the process left
// through std::_Exit and the log's last lines are the periodic ones.
void WriteTotalFile(const std::string& line) {
  if (g_dir.empty() || g_total_written.exchange(true)) {
    return;
  }
  if (std::FILE* f = std::fopen((g_dir + "audio_stats_total.txt").c_str(), "wb")) {
    std::fwrite(line.data(), 1, line.size(), f);
    std::fputc('\n', f);
    std::fclose(f);
  }
}

void ReporterMain(Reporter* self, int interval_s) {
  Snapshot prev;
  const auto interval = std::chrono::seconds(interval_s);
  auto due = std::chrono::steady_clock::now() + interval;
  while (!self->stop.load(std::memory_order_acquire)) {
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    if (self->stop.load(std::memory_order_acquire)) {
      break;
    }
    if (std::chrono::steady_clock::now() < due) {
      continue;
    }
    due += interval;
    Counters& c = g_counters;
    const uint64_t work_max = c.xma_work_us_max.exchange(0);
    const uint64_t pump_max = c.pump_us_max.exchange(0);
    const uint64_t gap_max = c.pump_gap_max_us.exchange(0);
    const uint64_t queue_min = c.sdl_queue_min.exchange(~0ull);
    Max(g_run_work_max, work_max);
    Max(g_run_pump_max, pump_max);
    Max(g_run_gap_max, gap_max);
    Min(g_run_queue_min, queue_min);
    const Snapshot now = Take();
    REXAPU_INFO("{}", Format("interval", now, prev, work_max, pump_max, gap_max, queue_min) + Extra(false));
    // The cumulative line too, every time: the process may leave without a chance to print the last one.
    REXAPU_INFO("{}", TotalLine());
    prev = now;
  }
  const std::string total = TotalLine();
  REXAPU_INFO("{}", total);
  WriteTotalFile(total);
  self->finished.store(true, std::memory_order_release);
}

void FlushAllForExit();

// Runs when the process ends: from exit(), or from the DLL's detach after std::_Exit/ExitProcess
// (the other threads are gone by then and may have been killed inside a lock, so nothing here
// waits on a lock: try_lock or skip). Never throws.
void OnProcessExit() {
  if (!g_stats.load() && !g_dump.load()) {
    return;
  }
  FlushAllForExit();
  Reporter* r = g_reporter;
  if (r) {
    // Alive (exit() from a thread of the process): it prints the totals when told to stop.
    // Killed (ExitProcess): it never answers; the totals are written here.
    r->stop.store(true, std::memory_order_release);
    for (int i = 0; i < 40 && !r->finished.load(std::memory_order_acquire); ++i) {
      std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    if (!r->finished.load(std::memory_order_acquire)) {
      WriteTotalFile(TotalLine());
    }
  }
}

struct ExitGuard {
  ~ExitGuard() {
    try {
      OnProcessExit();
    } catch (...) {
    }
  }
};

// The dump files that are open (leaked: it is usable until the process is gone).
struct Registry {
  std::mutex mutex;
  std::vector<ExitFlushable*> items;
};

Registry& Reg() {
  static Registry* registry = new Registry;
  return *registry;
}

void FlushAllForExit() {
  if (!g_dump.load()) {
    return;
  }
  Registry& r = Reg();
  if (!r.mutex.try_lock()) {
    return;
  }
  std::lock_guard<std::mutex> lock(r.mutex, std::adopt_lock);
  for (ExitFlushable* item : r.items) {
    item->FlushForExit();
  }
}

}  // namespace

void ExitFlushable::RegisterForExit() {
  Registry& r = Reg();
  std::lock_guard<std::mutex> lock(r.mutex);
  r.items.push_back(this);
}

void ExitFlushable::UnregisterForExit() {
  Registry& r = Reg();
  std::lock_guard<std::mutex> lock(r.mutex);
  r.items.erase(std::remove(r.items.begin(), r.items.end(), this), r.items.end());
}

Counters& C() {
  return g_counters;
}

uint64_t SteadyUnderruns() {
  return g_counters.sdl_underruns_steady.load(std::memory_order_relaxed);
}

bool StatsEnabled() {
  return g_stats.load(std::memory_order_relaxed);
}

bool DumpEnabled() {
  return g_dump.load(std::memory_order_relaxed);
}

void SetExtraStats(ExtraStatsFn fn) {
  g_extra_stats.store(fn, std::memory_order_release);
}

uint64_t NowUs() {
  return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(
                                   std::chrono::steady_clock::now() - g_start)
                                   .count());
}

const std::string& Dir() {
  return g_dir;
}

void MarkXmaWorkerThread() {
  tls_xma_worker = true;
}

bool IsXmaWorkerThread() {
  return tls_xma_worker;
}

uint32_t NextSession() {
  return g_session.fetch_add(1, std::memory_order_relaxed);
}

bool TakeBudget(uint64_t bytes) {
  uint64_t cur = g_budget.load(std::memory_order_relaxed);
  while (true) {
    if (cur < bytes) {
      return false;
    }
    if (g_budget.compare_exchange_weak(cur, cur - bytes, std::memory_order_relaxed)) {
      return true;
    }
  }
}

void Init() {
  if (g_initialized) {
    return;
  }
  g_initialized = true;
  g_start = std::chrono::steady_clock::now();
  g_stats.store(REXCVAR_GET(audio_stats), std::memory_order_relaxed);
  const std::string dir = REXCVAR_GET(audio_dump_dir);
  if (!dir.empty()) {
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    if (ec) {
      REXAPU_ERROR("audio dump: cannot create '{}': {}", dir, ec.message());
    } else {
      g_dir = dir;
      if (g_dir.back() != '/' && g_dir.back() != '\\') {
        g_dir += '/';
      }
      g_budget.store(static_cast<uint64_t>(REXCVAR_GET(audio_dump_max_mb)) << 20, std::memory_order_relaxed);
      g_dump.store(true, std::memory_order_relaxed);
      REXAPU_INFO("audio dump: writing to {} (at most {} MB)", g_dir, REXCVAR_GET(audio_dump_max_mb));
    }
  }
  if (StatsEnabled()) {
    InitThreadCpuClock();
    g_total_written.store(false);
    g_run_work_max.store(0);
    g_run_pump_max.store(0);
    g_run_gap_max.store(0);
    g_run_queue_min.store(~0ull);
    g_reporter = new Reporter;
    g_reporter->thread = std::thread(ReporterMain, g_reporter, REXCVAR_GET(audio_stats_interval));
  }
  // Armed here, not at load time: a function-local static is destroyed before the objects that
  // were constructed earlier (the logging, the cvars), which the exit path still uses.
  static ExitGuard guard;
  (void)guard;
}

void Shutdown() {
  if (!g_initialized) {
    return;
  }
  g_initialized = false;
  Reporter* r = g_reporter;
  g_reporter = nullptr;
  if (r) {
    r->stop.store(true, std::memory_order_release);
    if (r->thread.joinable()) {
      r->thread.join();  // it prints the totals and ends within ~50 ms
    }
    delete r;
  }
}

// ---------------------------------------------------------------------------------------------

namespace {

void Put16(uint8_t* p, uint16_t v) {
  p[0] = static_cast<uint8_t>(v);
  p[1] = static_cast<uint8_t>(v >> 8);
}

void Put32(uint8_t* p, uint32_t v) {
  p[0] = static_cast<uint8_t>(v);
  p[1] = static_cast<uint8_t>(v >> 8);
  p[2] = static_cast<uint8_t>(v >> 16);
  p[3] = static_cast<uint8_t>(v >> 24);
}

}  // namespace

bool WavWriter::Open(const std::string& path, uint16_t format_tag, uint16_t channels, uint32_t rate,
                     uint16_t bits) {
  Close();
  {
    std::lock_guard<std::mutex> lock(mutex_);
    file_ = std::fopen(path.c_str(), "wb");
    if (!file_) {
      return false;
    }
    uint8_t header[44] = {};
    std::memcpy(header, "RIFF", 4);
    Put32(header + 4, 36);
    std::memcpy(header + 8, "WAVEfmt ", 8);
    Put32(header + 16, 16);
    Put16(header + 20, format_tag);
    Put16(header + 22, channels);
    Put32(header + 24, rate);
    Put32(header + 28, rate * channels * (bits / 8));
    Put16(header + 32, static_cast<uint16_t>(channels * (bits / 8)));
    Put16(header + 34, bits);
    std::memcpy(header + 36, "data", 4);
    std::fwrite(header, 1, sizeof(header), file_);
    std::fflush(file_);
    data_bytes_ = 0;
    flushes_ = 0;
    buffer_.clear();
  }
  RegisterForExit();
  return true;
}

void WavWriter::Write(const void* data, size_t bytes) {
  if (!file_ || !bytes) {
    return;
  }
  std::lock_guard<std::mutex> lock(mutex_);
  if (!file_ || !TakeBudget(bytes)) {
    return;
  }
  const uint8_t* p = static_cast<const uint8_t*>(data);
  buffer_.insert(buffer_.end(), p, p + bytes);
  data_bytes_ += bytes;
  if (buffer_.size() >= (256u << 10)) {
    FlushLocked();
  }
}

// Writes the buffered data and brings the header's two sizes up to date, so the file is a
// complete WAV after every call.
void WavWriter::FlushLocked() {
  if (!file_) {
    return;
  }
  if (!buffer_.empty()) {
    std::fwrite(buffer_.data(), 1, buffer_.size(), file_);
    buffer_.clear();
  }
  uint8_t field[4];
  Put32(field, static_cast<uint32_t>(std::min<uint64_t>(36 + data_bytes_, 0xFFFFFFFFull)));
  std::fseek(file_, 4, SEEK_SET);
  std::fwrite(field, 1, 4, file_);
  Put32(field, static_cast<uint32_t>(std::min<uint64_t>(data_bytes_, 0xFFFFFFFFull)));
  std::fseek(file_, 40, SEEK_SET);
  std::fwrite(field, 1, 4, file_);
  std::fseek(file_, 0, SEEK_END);
  std::fflush(file_);
  ++flushes_;
}

void WavWriter::FlushForExit() {
  if (!mutex_.try_lock()) {
    return;
  }
  std::lock_guard<std::mutex> lock(mutex_, std::adopt_lock);
  FlushLocked();
}

void WavWriter::Close() {
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!file_) {
      return;
    }
    FlushLocked();
    std::fclose(file_);
    file_ = nullptr;
  }
  UnregisterForExit();
}

bool RawWriter::Open(const std::string& path) {
  Close();
  {
    std::lock_guard<std::mutex> lock(mutex_);
    file_ = std::fopen(path.c_str(), "wb");
    bytes_ = 0;
    if (!file_) {
      return false;
    }
  }
  RegisterForExit();
  return true;
}

void RawWriter::Write(const void* data, size_t bytes) {
  if (!file_ || !bytes) {
    return;
  }
  std::lock_guard<std::mutex> lock(mutex_);
  if (!file_ || !TakeBudget(bytes)) {
    return;
  }
  std::fwrite(data, 1, bytes, file_);
  bytes_ += bytes;
}

void RawWriter::FlushForExit() {
  if (!mutex_.try_lock()) {
    return;
  }
  std::lock_guard<std::mutex> lock(mutex_, std::adopt_lock);
  if (file_) {
    std::fflush(file_);
  }
}

void RawWriter::Close() {
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!file_) {
      return;
    }
    std::fclose(file_);
    file_ = nullptr;
  }
  UnregisterForExit();
}

}  // namespace rex::audio::dump
