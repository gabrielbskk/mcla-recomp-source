# FidelityFX's find_package(Vulkan) when the SDK gives it Vulkan headers
# (cmake/fidelityfx/CMakeLists.txt, REXGLUE_FSR_VULKAN_HEADERS): the SDK's own,
# and REXGLUE_FSR_VULKAN_LIBRARY to link if set (Linux: the system's loader;
# none for the PS5's static libraries, which link nothing).
set(Vulkan_INCLUDE_DIR "${REXGLUE_FSR_VULKAN_HEADERS}")
set(Vulkan_INCLUDE_DIRS "${REXGLUE_FSR_VULKAN_HEADERS}")
# The headers' version, for FidelityFX's minimum (CheckVulkanSDKVersion).
file(STRINGS "${REXGLUE_FSR_VULKAN_HEADERS}/vulkan/vulkan_core.h" _vulkan_version_lines
     REGEX "^#define VK_HEADER_VERSION(_COMPLETE)? ")
string(REGEX MATCH "VK_HEADER_VERSION ([0-9]+)" _ "${_vulkan_version_lines}")
set(_vulkan_patch "${CMAKE_MATCH_1}")
string(REGEX MATCH "VK_MAKE_API_VERSION[(]0, ([0-9]+), ([0-9]+)," _ "${_vulkan_version_lines}")
set(Vulkan_VERSION "${CMAKE_MATCH_1}.${CMAKE_MATCH_2}.${_vulkan_patch}")
set(Vulkan_FOUND TRUE)
if(NOT TARGET Vulkan::Headers)
    add_library(Vulkan::Headers INTERFACE IMPORTED)
    set_target_properties(Vulkan::Headers PROPERTIES INTERFACE_INCLUDE_DIRECTORIES "${REXGLUE_FSR_VULKAN_HEADERS}")
endif()
if(NOT TARGET Vulkan::Vulkan)
    add_library(Vulkan::Vulkan INTERFACE IMPORTED)
    set_target_properties(Vulkan::Vulkan PROPERTIES INTERFACE_INCLUDE_DIRECTORIES "${REXGLUE_FSR_VULKAN_HEADERS}")
    if(REXGLUE_FSR_VULKAN_LIBRARY)
        set(Vulkan_LIBRARY "${REXGLUE_FSR_VULKAN_LIBRARY}")
        set(Vulkan_LIBRARIES "${REXGLUE_FSR_VULKAN_LIBRARY}")
        set_target_properties(Vulkan::Vulkan PROPERTIES INTERFACE_LINK_LIBRARIES "${REXGLUE_FSR_VULKAN_LIBRARY}")
    endif()
endif()
