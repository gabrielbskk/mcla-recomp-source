# The static ffx-api (cmake/fidelityfx/CMakeLists.txt, REXGLUE_FSR_STATIC) must
# refer to its backend's interface: built without the backend's definition it
# still links, but creating FSR always fails.
#   cmake -DNM=<llvm-nm> -DARCHIVE=<libamd_fidelityfx_vk.a> -DSYMBOL=ffxGetInterfaceVK -P check_static.cmake
execute_process(COMMAND "${NM}" -u "${ARCHIVE}" RESULT_VARIABLE result OUTPUT_VARIABLE undefined
                ERROR_VARIABLE error)
if(NOT result EQUAL 0)
    message(FATAL_ERROR "FSR: ${NM} -u ${ARCHIVE} failed: ${error}")
endif()
string(FIND "${undefined}" "${SYMBOL}" found)
if(found EQUAL -1)
    message(FATAL_ERROR "FSR: ${ARCHIVE} doesn't refer to ${SYMBOL}: ffx-api was built without its backend")
endif()
message(STATUS "FSR: ${ARCHIVE} refers to ${SYMBOL}")
