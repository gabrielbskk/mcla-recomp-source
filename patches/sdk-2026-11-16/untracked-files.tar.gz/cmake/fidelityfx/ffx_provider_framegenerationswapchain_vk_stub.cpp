// Stands in for ffx-api's src/vk/ffx_provider_framegenerationswapchain_vk.cpp
// (cmake/fidelityfx/CMakeLists.txt): rexglue's Vulkan frame generation is
// "manual" (FFX_FRAMEGENERATION_FLAG_NO_SWAPCHAIN_CONTEXT_NOTIFY, it presents the
// frames itself), so AMD's Vulkan frame-interpolation swapchain, Win32-only and
// not Clang-clean at the pinned commit, isn't built. ffx_provider.cpp's table
// still names this provider; it provides nothing.
#include "ffx_provider_framegenerationswapchain_vk.h"

bool ffxProvider_FrameGenerationSwapChain_VK::CanProvide(uint64_t) const { return false; }

uint64_t ffxProvider_FrameGenerationSwapChain_VK::GetId() const { return 0xF600'0001ULL << 32u; }

const char* ffxProvider_FrameGenerationSwapChain_VK::GetVersionName() const { return "unavailable"; }

ffxReturnCode_t ffxProvider_FrameGenerationSwapChain_VK::CreateContext(ffxContext*, ffxCreateContextDescHeader*,
                                                                       Allocator&) const {
  return FFX_API_RETURN_ERROR_UNKNOWN_DESCTYPE;
}

ffxReturnCode_t ffxProvider_FrameGenerationSwapChain_VK::DestroyContext(ffxContext*, Allocator&) const {
  return FFX_API_RETURN_ERROR_PARAMETER;
}

ffxReturnCode_t ffxProvider_FrameGenerationSwapChain_VK::Configure(ffxContext*, const ffxConfigureDescHeader*) const {
  return FFX_API_RETURN_ERROR_UNKNOWN_DESCTYPE;
}

ffxReturnCode_t ffxProvider_FrameGenerationSwapChain_VK::Query(ffxContext*, ffxQueryDescHeader*) const {
  return FFX_API_RETURN_ERROR_UNKNOWN_DESCTYPE;
}

ffxReturnCode_t ffxProvider_FrameGenerationSwapChain_VK::Dispatch(ffxContext*, const ffxDispatchDescHeader*) const {
  return FFX_API_RETURN_ERROR_UNKNOWN_DESCTYPE;
}

ffxProvider_FrameGenerationSwapChain_VK ffxProvider_FrameGenerationSwapChain_VK::Instance;
