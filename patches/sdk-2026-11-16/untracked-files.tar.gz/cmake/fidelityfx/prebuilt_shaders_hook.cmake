# Included by FidelityFX's sdk/CMakeLists.txt right after its project() for the
# Vulkan backend (CMAKE_PROJECT_<name>_INCLUDE, set by cmake/fidelityfx/CMakeLists.txt
# when REXGLUE_FSR_SHADERS_DIR is given), after it has chosen its shader compiler:
# instead of FidelityFX_SC.exe (a Windows program), prebuilt_shaders.cmake puts
# the prebuilt headers where the compiler's output would go.
set(FFX_SC_EXECUTABLE "${CMAKE_COMMAND}" "-DREXGLUE_FSR_SHADERS_DIR=${REXGLUE_FSR_SHADERS_DIR}"
    -P "${REXGLUE_FSR_WRAPPER_DIR}/prebuilt_shaders.cmake" --)
message(STATUS "FSR: FidelityFX's Vulkan shaders come from ${REXGLUE_FSR_SHADERS_DIR}, not its shader compiler (no Wine needed)")
# The wrapper checks that this ran (a renamed project would skip it silently).
set_property(GLOBAL PROPERTY REXGLUE_FSR_PREBUILT_HOOK_RAN TRUE)
