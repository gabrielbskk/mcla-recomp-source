# Builds one ffx-api backend (FFX_API_BACKEND = DX12_X64 or VK_X64) of the FidelityFX
# SDK at FFX_ROOT as a shared library, for cmake/rexglue_fsr.cmake (an ExternalProject,
# so the two backends, which can't share a configure, each get their own).
#   REXGLUE_FSR_SHADERS_DIR     the prebuilt shaders (thirdparty/fidelityfx-shaders-vk)
#                               instead of FidelityFX_SC (Vulkan; prebuilt_shaders*.cmake)
#   REXGLUE_FSR_SHADERS_HASH    their hash (only to make a new set rebuild the runtime)
#   REXGLUE_FSR_VULKAN_HEADERS  Vulkan headers to build against instead of
#                               find_package(Vulkan)'s, and REXGLUE_FSR_VULKAN_LIBRARY
#                               the library to link (none for static libraries)
#   REXGLUE_FSR_STATIC          static libraries instead, checked and copied to
#                               REXGLUE_FSR_ARCHIVE_DIR by the target rexglue_fsr_static
#                               (the PS5)
#   REXGLUE_FSR_WRAPPER_HASH    this folder's files' hash (only to make a changed wrapper
#                               configure and build the runtime again)
#   REXGLUE_FSR_FRAMEGEN        frame generation's components too (ON; OFF: upscaling only)
cmake_minimum_required(VERSION 3.23)
project(rexglue_fidelityfx C CXX)
if(NOT FFX_ROOT OR NOT FFX_API_BACKEND)
    message(FATAL_ERROR "FFX_ROOT and FFX_API_BACKEND are required")
endif()
set(_wrapper_hash "${REXGLUE_FSR_WRAPPER_HASH}")
# Upscaling, and frame generation (rexglue-frame-generation.patch): the frame
# generation provider and its optical flow and frame interpolation components,
# on Vulkan without AMD's frame-interpolation swapchain (below), on every
# platform (Linux and the PS5 too, untested there: rexglue-frame-generation-
# nonwindows.patch). REXGLUE_FSR_FRAMEGEN=OFF leaves them out (upscaling only,
# so that FSR anti-aliasing can't be lost to code that fails to build somewhere).
# (Not defined when this file is used on its own: scripts/ci/build-fidelityfx.ps1 builds the
# release DLLs so. The default has to stay ON, or those lose frame generation.)
if(NOT DEFINED REXGLUE_FSR_FRAMEGEN)
    set(REXGLUE_FSR_FRAMEGEN ON)
endif()
if(REXGLUE_FSR_FRAMEGEN)
    set(FFX_API_ENABLE_FRAMEGEN_PROVIDER ON CACHE BOOL "" FORCE)
else()
    set(FFX_API_ENABLE_FRAMEGEN_PROVIDER OFF CACHE BOOL "" FORCE)
endif()
if(REXGLUE_FSR_SHADERS_DIR)
    # FidelityFX_SC isn't run: right after the SDK's project() for the Vulkan
    # backend (after it has picked its compiler), the hook puts
    # prebuilt_shaders.cmake in its place, which copies the prebuilt headers to
    # where the compiler's output would go.
    set(FFX_API_AUTO_COMPILE_SHADERS OFF CACHE BOOL "" FORCE)
    set(REXGLUE_FSR_WRAPPER_DIR "${CMAKE_CURRENT_LIST_DIR}")
    set(CMAKE_PROJECT_FidelityFX-SDK_VK_x64_INCLUDE "${CMAKE_CURRENT_LIST_DIR}/prebuilt_shaders_hook.cmake")
else()
    set(FFX_API_AUTO_COMPILE_SHADERS ON CACHE BOOL "" FORCE)
endif()
if(REXGLUE_FSR_VULKAN_HEADERS)
    # FidelityFX's find_package(Vulkan REQUIRED) gets these headers.
    list(PREPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}/vulkan-headers-only")
endif()
if(REXGLUE_FSR_STATIC)
    # Here, so that the static library below sees Vulkan's targets too (imported
    # targets belong to the folder that finds them).
    find_package(Vulkan REQUIRED)
endif()
add_subdirectory("${FFX_ROOT}/ffx-api" "${CMAKE_BINARY_DIR}/ffx-api")
if(REXGLUE_FSR_SHADERS_DIR)
    get_property(_hook_ran GLOBAL PROPERTY REXGLUE_FSR_PREBUILT_HOOK_RAN)
    if(NOT _hook_ran)
        message(FATAL_ERROR "FSR: FidelityFX's Vulkan project isn't FidelityFX-SDK_VK_x64 any more, so "
                            "the prebuilt shaders' hook didn't run (prebuilt_shaders_hook.cmake)")
    endif()
endif()
# FidelityFX's toolchain.cmake sets a Visual Studio platform, which Ninja rejects.
unset(CMAKE_GENERATOR_PLATFORM CACHE)
string(TOLOWER "${FFX_API_BACKEND}" _backend)
string(REGEX REPLACE "_x64$" "" _backend "${_backend}")
set(_target amd_fidelityfx_${_backend})
if(_backend STREQUAL "vk" AND FFX_API_ENABLE_FRAMEGEN_PROVIDER)
    # Vulkan frame generation is "manual" (FFX_FRAMEGENERATION_FLAG_NO_SWAPCHAIN_CONTEXT_NOTIFY):
    # rexglue presents the frames itself. AMD's Vulkan frame-interpolation
    # swapchain is Win32-only and doesn't compile with Clang at this commit, so
    # its sources are left out and its ffx-api provider is a stub that provides
    # nothing (ffx_provider.cpp's table still names it).
    set(_vk_backend_target ffx_backend_vk_x64)
    if(NOT TARGET ${_vk_backend_target})
        message(FATAL_ERROR "FSR: FidelityFX's Vulkan backend isn't ${_vk_backend_target} any more")
    endif()
    get_target_property(_sources ${_vk_backend_target} SOURCES)
    list(FILTER _sources EXCLUDE REGEX "FrameInterpolationSwapchain/")
    set_property(TARGET ${_vk_backend_target} PROPERTY SOURCES ${_sources})
    # The backend's swapchain hook refers to that swapchain only when it is
    # compiled with FFX_API_ENABLE_FRAMEGEN_PROVIDER (ffx_vk.cpp), which ffx-api
    # gives to its own library alone; with it, Linux and the PS5 couldn't link.
    get_target_property(_definitions ${_vk_backend_target} COMPILE_DEFINITIONS)
    get_target_property(_backend_dir ${_vk_backend_target} SOURCE_DIR)
    get_directory_property(_dir_definitions DIRECTORY "${_backend_dir}" COMPILE_DEFINITIONS)
    if("${_definitions};${_dir_definitions}" MATCHES "FFX_API_ENABLE_FRAMEGEN_PROVIDER")
        message(FATAL_ERROR "FSR: FidelityFX's Vulkan backend is compiled with "
                            "FFX_API_ENABLE_FRAMEGEN_PROVIDER, so it needs the frame-interpolation "
                            "swapchain left out of the build")
    endif()
    get_target_property(_sources ${_target} SOURCES)
    list(LENGTH _sources _count_before)
    list(FILTER _sources EXCLUDE REGEX "ffx_provider_framegenerationswapchain_vk\\.cpp$")
    list(LENGTH _sources _count_after)
    if(_count_before EQUAL _count_after)
        message(FATAL_ERROR "FSR: no ffx_provider_framegenerationswapchain_vk.cpp in ${_target} to replace")
    endif()
    list(APPEND _sources "${CMAKE_CURRENT_LIST_DIR}/ffx_provider_framegenerationswapchain_vk_stub.cpp")
    set_property(TARGET ${_target} PROPERTY SOURCES ${_sources})
    target_include_directories(${_target} PRIVATE "${FFX_ROOT}/ffx-api/src/vk")
endif()
# Outputs into this build tree (ffx-api's CMake would put them next to this file).
foreach(_config "" _DEBUG _RELEASE _RELWITHDEBINFO)
    set_target_properties(${_target} PROPERTIES
        RUNTIME_OUTPUT_DIRECTORY${_config} "${CMAKE_BINARY_DIR}/bin"
        LIBRARY_OUTPUT_DIRECTORY${_config} "${CMAKE_BINARY_DIR}/bin"
        ARCHIVE_OUTPUT_DIRECTORY${_config} "${CMAKE_BINARY_DIR}/lib")
endforeach()
# The DLL's version resource is UTF-16, which Clang's resource compiler rejects;
# the library doesn't need it.
set_source_files_properties("${FFX_ROOT}/ffx-api/src/resource/ffx_api_dll.rc"
    TARGET_DIRECTORY ${_target} PROPERTIES HEADER_FILE_ONLY ON)

if(REXGLUE_FSR_STATIC)
    # ffx-api's own library is SHARED; the same sources and settings as a static
    # library, under the same name, next to the static libraries it uses: its
    # target's properties, its folder's compile definitions and options (where
    # ffx-api selects its backend: FFX_BACKEND_VK), and its link libraries' usage
    # requirements (the backend's, the components', the Vulkan headers).
    get_target_property(_sources ${_target} SOURCES)
    get_target_property(_source_dir ${_target} SOURCE_DIR)
    set(_static_sources)
    foreach(_source IN LISTS _sources)
        if(_source MATCHES "\\.rc$")
            continue()
        elseif(_source MATCHES "^\\$<" OR IS_ABSOLUTE "${_source}")
            list(APPEND _static_sources "${_source}")
        else()
            list(APPEND _static_sources "${_source_dir}/${_source}")
        endif()
    endforeach()
    add_library(${_target}_static STATIC ${_static_sources})
    foreach(_property INCLUDE_DIRECTORIES COMPILE_DEFINITIONS COMPILE_OPTIONS COMPILE_FEATURES
                      CXX_STANDARD C_STANDARD)
        get_target_property(_value ${_target} ${_property})
        if(_value)
            set_property(TARGET ${_target}_static PROPERTY ${_property} "${_value}")
        endif()
    endforeach()
    get_directory_property(_definitions DIRECTORY "${_source_dir}" COMPILE_DEFINITIONS)
    target_compile_definitions(${_target}_static PRIVATE ${_definitions})
    get_target_property(_links ${_target} LINK_LIBRARIES)
    target_link_libraries(${_target}_static PRIVATE ${_links})
    # Every static library it needs, through their own links.
    set(_archives)
    set(_pending ${_links})
    set(_seen)
    while(_pending)
        list(POP_FRONT _pending _link)
        if(NOT TARGET ${_link} OR _link IN_LIST _seen)
            continue()
        endif()
        list(APPEND _seen ${_link})
        get_target_property(_type ${_link} TYPE)
        if(_type STREQUAL "STATIC_LIBRARY")
            list(APPEND _archives "$<TARGET_FILE:${_link}>")
            get_target_property(_more ${_link} LINK_LIBRARIES)
            if(_more)
                list(APPEND _pending ${_more})
            endif()
        endif()
    endwhile()
    # Its own folder: on Windows the shared library's import library has the name.
    set_target_properties(${_target}_static PROPERTIES OUTPUT_NAME ${_target}
        ARCHIVE_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/static")
    set_target_properties(${_target} PROPERTIES EXCLUDE_FROM_ALL ON)
    # The archive must have the backend in it (an ffx-api built without its
    # backend's definition still links, but can't create anything).
    if(CMAKE_NM)
        set(_nm "${CMAKE_NM}")
    else()
        get_filename_component(_compiler_dir "${CMAKE_CXX_COMPILER}" DIRECTORY)
        find_program(_nm NAMES llvm-nm nm HINTS "${_compiler_dir}" REQUIRED)
    endif()
    string(TOUPPER "${_backend}" _backend_upper)
    if(_backend_upper STREQUAL "VK")
        set(_interface ffxGetInterfaceVK)
    else()
        set(_interface ffxGetInterfaceDX12)
    endif()
    add_custom_target(rexglue_fsr_static
        COMMAND "${CMAKE_COMMAND}" "-DNM=${_nm}" "-DARCHIVE=$<TARGET_FILE:${_target}_static>"
                "-DSYMBOL=${_interface}" -P "${CMAKE_CURRENT_LIST_DIR}/check_static.cmake"
        COMMAND "${CMAKE_COMMAND}" -E make_directory "${REXGLUE_FSR_ARCHIVE_DIR}"
        COMMAND "${CMAKE_COMMAND}" -E copy "$<TARGET_FILE:${_target}_static>" ${_archives}
                "${REXGLUE_FSR_ARCHIVE_DIR}"
        DEPENDS ${_target}_static
        VERBATIM)
endif()
