# A configure or build step of a FidelityFX runtime (cmake/rexglue_fsr.cmake)
# that may fail without failing the SDK's build:
#   cmake -DSTEP_SKIP=<marker> [-DSTEP_FIRST=1] -P soft_step.cmake -- <command>...
# On failure the marker is written, a warning says the runtime is left out, and
# the step succeeds; the steps after it are skipped while the marker exists.
# The first step (the configure) starts afresh.
set(command)
set(after_separator FALSE)
math(EXPR last "${CMAKE_ARGC} - 1")
foreach(i RANGE 1 ${last})
    if(after_separator)
        list(APPEND command "${CMAKE_ARGV${i}}")
    elseif(CMAKE_ARGV${i} STREQUAL "--")
        set(after_separator TRUE)
    endif()
endforeach()
if(STEP_FIRST)
    file(REMOVE "${STEP_SKIP}")
elseif(EXISTS "${STEP_SKIP}")
    return()
endif()
execute_process(COMMAND ${command} RESULT_VARIABLE result)
if(NOT result EQUAL 0)
    file(WRITE "${STEP_SKIP}" "${result}\n")
    message(WARNING "FSR: a FidelityFX runtime failed to build (${result}); it is left out, and FSR is unavailable for its graphics API. ${STEP_HINT}")
endif()
