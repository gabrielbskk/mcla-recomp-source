# Stands in for FidelityFX_SC.exe (prebuilt_shaders_hook.cmake), called as it
# would be:
#   cmake -DREXGLUE_FSR_SHADERS_DIR=<dir> -P prebuilt_shaders.cmake -- <FidelityFX_SC's arguments>
# Of those it reads -name=<name> and -output=<folder>, and the shader (the last
# argument); it copies <name>_permutations.h and the blob headers it includes
# from the prebuilt set into the folder, and writes the dependency file
# FidelityFX's build expects. A permutation set that isn't prebuilt stops the
# build (the runtime is then left out, soft_step.cmake).
set(args)
set(after_separator FALSE)
math(EXPR last "${CMAKE_ARGC} - 1")
foreach(i RANGE 1 ${last})
    if(after_separator)
        list(APPEND args "${CMAKE_ARGV${i}}")
    elseif(CMAKE_ARGV${i} STREQUAL "--")
        set(after_separator TRUE)
    endif()
endforeach()
set(name "")
set(output "")
foreach(arg IN LISTS args)
    if(arg MATCHES "^-name=(.+)$")
        set(name "${CMAKE_MATCH_1}")
    elseif(arg MATCHES "^-output=(.+)$")
        set(output "${CMAKE_MATCH_1}")
    endif()
endforeach()
list(GET args -1 shader)
if(NOT name OR NOT output)
    message(FATAL_ERROR "FSR prebuilt shaders: no -name= or -output= in: ${args}")
endif()
set(table "${REXGLUE_FSR_SHADERS_DIR}/${name}_permutations.h")
if(NOT EXISTS "${table}")
    message(FATAL_ERROR "FSR prebuilt shaders: ${name} isn't in ${REXGLUE_FSR_SHADERS_DIR} "
                        "(launcher/dev/fsr/fsr_vk_shaders.py makes the set)")
endif()
file(MAKE_DIRECTORY "${output}")
file(STRINGS "${table}" includes REGEX "^#include \"[^\"]+\"")
set(files "${name}_permutations.h")
foreach(line IN LISTS includes)
    string(REGEX REPLACE "^#include \"([^\"]+)\".*$" "\\1" blob "${line}")
    list(APPEND files "${blob}")
endforeach()
foreach(file IN LISTS files)
    file(COPY_FILE "${REXGLUE_FSR_SHADERS_DIR}/${file}" "${output}/${file}" ONLY_IF_DIFFERENT)
endforeach()
# FidelityFX_SC's output is newer than its input; so is this.
file(TOUCH "${output}/${name}_permutations.h")
# Make's syntax, spaces in paths escaped: the shader and the prebuilt files, so
# that a new set is copied again.
set(dependencies "${shader}")
foreach(file IN LISTS files)
    list(APPEND dependencies "${REXGLUE_FSR_SHADERS_DIR}/${file}")
endforeach()
string(REPLACE " " "\\ " depfile "${output}/${name}_permutations.h")
string(APPEND depfile ":")
foreach(dependency IN LISTS dependencies)
    string(REPLACE " " "\\ " dependency "${dependency}")
    string(APPEND depfile " ${dependency}")
endforeach()
file(WRITE "${output}/${name}_permutations.h.d" "${depfile}\n")
