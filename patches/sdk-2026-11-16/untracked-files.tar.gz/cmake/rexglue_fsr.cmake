# rexglue_fsr.cmake - AMD FSR 3.1 for temporal anti-aliasing (rexglue-temporal-aa.patch)
#
# Builds ffx-api of the AMD FidelityFX SDK 1.1.4 (MIT) from source, as
# amd_fidelityfx_dx12 and amd_fidelityfx_vk shared libraries that the GPU plugin
# loads at run time from the executable's folder. The plugin compiles against
# the headers in thirdparty/fidelityfx-api; this file only builds the runtime.
#
# The source is fetched at a pinned commit of the ReXGlue fork (AMD's v1.1.4,
# c6efa6b, plus portability fixes) into the build tree, and checked against
# pinned git tree hashes of the two directories that are built, so what is
# compiled is exactly what was reviewed. REXGLUE_FSR_SOURCE_DIR may point at an
# existing checkout of that commit instead (checked the same way).
#
# FSR is optional: if the source can't be fetched or verified (no network, no
# Git), or a runtime fails to configure or build, the SDK builds without it and
# the GPU plugin reports FSR as unavailable. A fetch goes to a temporary folder
# that is renamed only once verified, so a failed or partial fetch never stays
# behind; a checkout that no longer verifies is fetched again once.
#
# FidelityFX compiles its shaders at build time with its own FidelityFX_SC tool
# (from the same commit), a Windows program. Elsewhere the Vulkan library is
# built from the prebuilt shaders of the permutations rexglue uses
# (REXGLUE_FSR_PREBUILT_SHADERS). On Windows the Vulkan library needs the Vulkan
# SDK (without it only the D3D12 one is built); elsewhere it is built against
# the SDK's own Vulkan headers, and on Linux links the system's Vulkan loader.
# On the PS5 it is static libraries (no modules).

if(NOT REXGLUE_ENABLE_FSR)
    return()
endif()

# What src/graphics/CMakeLists.txt and the summary read.
option(REXGLUE_FSR_FRAMEGEN "Build FSR's frame generation (the Vulkan provider, optical flow and frame interpolation) with the runtime" ON)
set(REXGLUE_FSR_STATIC OFF)
if(PS5 OR PROSPERO)
    set(REXGLUE_FSR_STATIC ON)
endif()
set(REXGLUE_FSR_VK_PREBUILT OFF)
set(REXGLUE_FSR_STATUS "ON, but FidelityFX's source is unavailable (see the warning above): built without it")

set(REXGLUE_FSR_REPOSITORY "https://github.com/rexglue/FidelityFX-SDK.git" CACHE STRING
    "Where the FidelityFX SDK is fetched from (the pinned commit must exist there)")
set(REXGLUE_FSR_SOURCE_DIR "" CACHE PATH
    "An existing checkout of the pinned FidelityFX SDK commit (fetched into the build tree otherwise)")
set(_rexglue_fsr_commit "eee08db1688ac3d1275a70b728f4a8ba22914213")
set(_rexglue_fsr_tree_ffx_api "cdcd115d3ea4f855251049dc3d5517b3ae448a46")
set(_rexglue_fsr_tree_sdk "47c22f65b682061792531316670251a5c8ae81e7")

find_package(Git QUIET)
if(NOT GIT_FOUND)
    message(WARNING "FSR: Git was not found; building without FSR")
    return()
endif()

# Runs git in `dir`; `ok_var` is set to whether it succeeded, the output (or the
# error) goes to _rexglue_fsr_git_output.
function(_rexglue_fsr_git ok_var dir)
    execute_process(COMMAND "${GIT_EXECUTABLE}" -C "${dir}" ${ARGN}
                    RESULT_VARIABLE result OUTPUT_VARIABLE output ERROR_VARIABLE error
                    OUTPUT_STRIP_TRAILING_WHITESPACE ERROR_STRIP_TRAILING_WHITESPACE)
    if(result EQUAL 0)
        set(${ok_var} TRUE PARENT_SCOPE)
        set(_rexglue_fsr_git_output "${output}" PARENT_SCOPE)
    else()
        set(${ok_var} FALSE PARENT_SCOPE)
        set(_rexglue_fsr_git_output "git ${ARGN}: ${error}" PARENT_SCOPE)
    endif()
endfunction()

# Whether `dir` is the pinned commit's ffx-api and sdk, unmodified.
function(_rexglue_fsr_verify ok_var dir)
    set(${ok_var} FALSE PARENT_SCOPE)
    if(NOT EXISTS "${dir}/.git")
        set(_rexglue_fsr_why "no checkout" PARENT_SCOPE)
        return()
    endif()
    _rexglue_fsr_git(ok "${dir}" rev-parse HEAD)
    if(NOT ok OR NOT _rexglue_fsr_git_output STREQUAL _rexglue_fsr_commit)
        set(_rexglue_fsr_why "not at ${_rexglue_fsr_commit} (${_rexglue_fsr_git_output})" PARENT_SCOPE)
        return()
    endif()
    _rexglue_fsr_git(ok "${dir}" rev-parse HEAD:ffx-api HEAD:sdk)
    string(REPLACE "\n" ";" trees "${_rexglue_fsr_git_output}")
    if(NOT ok OR NOT trees STREQUAL "${_rexglue_fsr_tree_ffx_api};${_rexglue_fsr_tree_sdk}")
        set(_rexglue_fsr_why "unexpected tree hashes (${trees})" PARENT_SCOPE)
        return()
    endif()
    _rexglue_fsr_git(ok "${dir}" diff --quiet HEAD -- ffx-api sdk LICENSE.txt)
    if(NOT ok)
        set(_rexglue_fsr_why "modified files" PARENT_SCOPE)
        return()
    endif()
    set(${ok_var} TRUE PARENT_SCOPE)
endfunction()

# Fetches the pinned commit (ffx-api, sdk and the licence only) into `dir`
# through a temporary folder.
function(_rexglue_fsr_fetch ok_var dir)
    set(${ok_var} FALSE PARENT_SCOPE)
    set(tmp "${dir}.tmp")
    file(REMOVE_RECURSE "${tmp}")
    file(MAKE_DIRECTORY "${tmp}")
    foreach(step IN ITEMS "init;-q" "config;core.longpaths;true" "config;core.autocrlf;false"
                          "remote;add;origin;${REXGLUE_FSR_REPOSITORY}"
                          "sparse-checkout;set;--no-cone;/ffx-api/;/sdk/;/LICENSE.txt"
                          "fetch;-q;--depth;1;--filter=blob:none;origin;${_rexglue_fsr_commit}"
                          "checkout;-q;FETCH_HEAD")
        _rexglue_fsr_git(ok "${tmp}" ${step})
        if(NOT ok)
            set(_rexglue_fsr_why "${_rexglue_fsr_git_output}" PARENT_SCOPE)
            file(REMOVE_RECURSE "${tmp}")
            return()
        endif()
    endforeach()
    _rexglue_fsr_verify(ok "${tmp}")
    if(NOT ok)
        set(_rexglue_fsr_why "the fetched source: ${_rexglue_fsr_why}" PARENT_SCOPE)
        file(REMOVE_RECURSE "${tmp}")
        return()
    endif()
    file(REMOVE_RECURSE "${dir}")
    file(RENAME "${tmp}" "${dir}")
    set(${ok_var} TRUE PARENT_SCOPE)
endfunction()

if(REXGLUE_FSR_SOURCE_DIR)
    set(_rexglue_fsr_src "${REXGLUE_FSR_SOURCE_DIR}")
    _rexglue_fsr_verify(_rexglue_fsr_ok "${_rexglue_fsr_src}")
else()
    set(_rexglue_fsr_src "${CMAKE_BINARY_DIR}/_deps/ffx")
    _rexglue_fsr_verify(_rexglue_fsr_ok "${_rexglue_fsr_src}")
    if(NOT _rexglue_fsr_ok)
        if(EXISTS "${_rexglue_fsr_src}")
            message(STATUS "FSR: ${_rexglue_fsr_src}: ${_rexglue_fsr_why}; fetching it again")
        endif()
        message(STATUS "FSR: fetching FidelityFX SDK ${_rexglue_fsr_commit} from ${REXGLUE_FSR_REPOSITORY}")
        _rexglue_fsr_fetch(_rexglue_fsr_ok "${_rexglue_fsr_src}")
    endif()
endif()
if(NOT _rexglue_fsr_ok)
    message(WARNING "FSR: the FidelityFX SDK source is unavailable (${_rexglue_fsr_why}); building without FSR")
    return()
endif()
message(STATUS "FSR: FidelityFX SDK ${_rexglue_fsr_commit} verified (ffx-api ${_rexglue_fsr_tree_ffx_api}, sdk ${_rexglue_fsr_tree_sdk})")

set(_rexglue_fsr_apis)
if(REXGLUE_USE_D3D12)
    list(APPEND _rexglue_fsr_apis dx12)
endif()
# The Vulkan runtime's headers and library: on Windows the Vulkan SDK's; off it
# the SDK's own headers (thirdparty/vulkan-headers, so no development package
# or minimum version is needed), with the system's loader on Linux and no
# library for the PS5's static libraries.
set(_rexglue_fsr_vulkan_headers "")
set(_rexglue_fsr_vulkan_library "")
if(REXGLUE_USE_VULKAN)
    if(WIN32)
        find_package(Vulkan QUIET)
        if(Vulkan_FOUND)
            list(APPEND _rexglue_fsr_apis vk)
        else()
            message(WARNING "FSR: the Vulkan SDK was not found; FSR is built for Direct3D 12 only (set VULKAN_SDK, or install it, for Vulkan)")
        endif()
    else()
        set(_rexglue_fsr_vulkan_headers "${REXGLUE_ROOT}/thirdparty/vulkan-headers/include")
        if(PS5 OR PROSPERO)
            list(APPEND _rexglue_fsr_apis vk)
        else()
            find_library(REXGLUE_FSR_VULKAN_LIBRARY NAMES vulkan libvulkan.so.1
                         DOC "The Vulkan loader FSR's Vulkan runtime links (Linux)")
            if(REXGLUE_FSR_VULKAN_LIBRARY)
                set(_rexglue_fsr_vulkan_library "${REXGLUE_FSR_VULKAN_LIBRARY}")
                list(APPEND _rexglue_fsr_apis vk)
            else()
                message(WARNING "FSR: the Vulkan loader (libvulkan.so.1) was not found; building without FSR")
            endif()
        endif()
    endif()
endif()

# FidelityFX compiles its shaders at build time with FidelityFX_SC.exe, a Windows
# program. Elsewhere the Vulkan runtime is built from the prebuilt SPIR-V of the
# permutations rexglue uses (thirdparty/fidelityfx-shaders-vk, from
# rexglue-temporal-aa-shaders-vk.patch); on Windows it can be too, to check them.
if(WIN32)
    set(_rexglue_fsr_prebuilt_default OFF)
else()
    set(_rexglue_fsr_prebuilt_default ON)
endif()
option(REXGLUE_FSR_PREBUILT_SHADERS
    "Build FSR's Vulkan runtime from the prebuilt shaders in thirdparty/fidelityfx-shaders-vk (needed off Windows)"
    ${_rexglue_fsr_prebuilt_default})
set(REXGLUE_FSR_SHADERS_DIR "${REXGLUE_ROOT}/thirdparty/fidelityfx-shaders-vk")
set(_rexglue_fsr_shaders_hash "")
if("vk" IN_LIST _rexglue_fsr_apis)
    if(REXGLUE_FSR_PREBUILT_SHADERS)
        if(EXISTS "${REXGLUE_FSR_SHADERS_DIR}/rexglue_fsr_shaders_vk.h")
            set(REXGLUE_FSR_VK_PREBUILT ON)
            # Their hash, in the runtime's configure command: a new set
            # configures and builds it again (and this configure runs again when
            # a file of the set changes).
            file(GLOB _rexglue_fsr_shaders LIST_DIRECTORIES false "${REXGLUE_FSR_SHADERS_DIR}/*")
            list(SORT _rexglue_fsr_shaders)
            set(_rexglue_fsr_hashes "")
            foreach(file IN LISTS _rexglue_fsr_shaders)
                file(SHA256 "${file}" hash)
                get_filename_component(name "${file}" NAME)
                string(APPEND _rexglue_fsr_hashes "${name} ${hash}\n")
            endforeach()
            string(SHA256 _rexglue_fsr_shaders_hash "${_rexglue_fsr_hashes}")
            set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${_rexglue_fsr_shaders})
        else()
            message(WARNING "FSR: the prebuilt Vulkan shaders (thirdparty/fidelityfx-shaders-vk, rexglue-temporal-aa-shaders-vk.patch) are missing; building without FSR for Vulkan")
            list(REMOVE_ITEM _rexglue_fsr_apis vk)
        endif()
    elseif(NOT WIN32)
        message(WARNING "FSR: off Windows, FidelityFX's shader compiler can't run; REXGLUE_FSR_PREBUILT_SHADERS is needed for Vulkan")
        list(REMOVE_ITEM _rexglue_fsr_apis vk)
    endif()
endif()

# The PS5 can't load modules (REXGLUE_FSR_STATIC): its runtime is static
# libraries, copied next to the SDK's own (which the game links all of), and
# the GPU plugin calls it directly.
if(WIN32)
    set(_rexglue_fsr_library_prefix "")
    set(_rexglue_fsr_library_suffix ".dll")
    set(_rexglue_fsr_install_dir "${CMAKE_INSTALL_BINDIR}")
elseif(REXGLUE_FSR_STATIC)
    set(_rexglue_fsr_library_prefix "lib")
    set(_rexglue_fsr_library_suffix ".a")
    set(_rexglue_fsr_install_dir "")
else()
    # Linux (untested): the library goes with the SDK's own.
    set(_rexglue_fsr_library_prefix "lib")
    set(_rexglue_fsr_library_suffix ".so")
    set(_rexglue_fsr_install_dir "${CMAKE_INSTALL_LIBDIR}")
endif()

include(ExternalProject)
add_custom_target(rexglue_fsr_runtime)
# The wrapper's files, copied into each runtime's build tree; their hash is
# passed to its configure, so that a changed wrapper configures and builds the
# runtime again in an existing build tree (the copies alone don't: the build
# step only follows its configure step).
set(_rexglue_fsr_wrapper_files CMakeLists.txt soft_step.cmake check_static.cmake
    prebuilt_shaders_hook.cmake prebuilt_shaders.cmake vulkan-headers-only/FindVulkan.cmake
    ffx_provider_framegenerationswapchain_vk_stub.cpp)
set(_rexglue_fsr_wrapper_hashes "")
foreach(file IN LISTS _rexglue_fsr_wrapper_files)
    file(SHA256 "${REXGLUE_ROOT}/cmake/fidelityfx/${file}" hash)
    string(APPEND _rexglue_fsr_wrapper_hashes "${hash}")
endforeach()
string(SHA256 _rexglue_fsr_wrapper_hash "${_rexglue_fsr_wrapper_hashes}")
foreach(api IN LISTS _rexglue_fsr_apis)
    string(TOUPPER "${api}" api_upper)
    set(binary_dir "${CMAKE_BINARY_DIR}/_deps/ffx-${api}")
    # Each runtime's project from its own copy of the wrapper in the build
    # tree: FidelityFX writes its static libraries under the top project's
    # source folder (CMAKE_HOME_DIRECTORY/bin), which would otherwise be the
    # SDK's own and shared by the two builds.
    set(wrapper_dir "${CMAKE_BINARY_DIR}/_deps/ffx-${api}-p")
    foreach(file IN LISTS _rexglue_fsr_wrapper_files)
        configure_file("${REXGLUE_ROOT}/cmake/fidelityfx/${file}" "${wrapper_dir}/${file}" COPYONLY)
    endforeach()
    # Every switch of the wrapper given, empty or off when not used, so that its
    # cache keeps none from an earlier configure.
    set(args "-DFFX_ROOT=${_rexglue_fsr_src}" -DFFX_API_BACKEND=${api_upper}_X64
             "-DREXGLUE_FSR_WRAPPER_HASH=${_rexglue_fsr_wrapper_hash}"
             "-DREXGLUE_FSR_FRAMEGEN=${REXGLUE_FSR_FRAMEGEN}")
    if(api STREQUAL "vk" AND REXGLUE_FSR_VK_PREBUILT)
        list(APPEND args "-DREXGLUE_FSR_SHADERS_DIR=${REXGLUE_FSR_SHADERS_DIR}"
             "-DREXGLUE_FSR_SHADERS_HASH=${_rexglue_fsr_shaders_hash}")
    else()
        list(APPEND args "-DREXGLUE_FSR_SHADERS_DIR=" "-DREXGLUE_FSR_SHADERS_HASH=")
    endif()
    if(api STREQUAL "vk")
        list(APPEND args "-DREXGLUE_FSR_VULKAN_HEADERS=${_rexglue_fsr_vulkan_headers}"
             "-DREXGLUE_FSR_VULKAN_LIBRARY=${_rexglue_fsr_vulkan_library}")
    else()
        list(APPEND args "-DREXGLUE_FSR_VULKAN_HEADERS=" "-DREXGLUE_FSR_VULKAN_LIBRARY=")
    endif()
    if(NOT WIN32)
        # The Linux library is a shared object; the PS5's title is position-independent.
        list(APPEND args -DCMAKE_POSITION_INDEPENDENT_CODE=ON)
    endif()
    if(WIN32)
        # The C runtime linked into the library, so that a player's PC needs no Visual C++
        # Redistributable for it (the DLL imports kernel32 and the system's own DLLs only). The
        # policy is given too: FidelityFX's projects set an older one for themselves. A MinGW
        # target ignores both.
        list(APPEND args -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded -DCMAKE_POLICY_DEFAULT_CMP0091=NEW)
    endif()
    if(REXGLUE_FSR_STATIC)
        # Linked into the title with the SDK's own code, with link-time
        # optimisation: the same code model as the SDK (an LTO link refuses
        # modules with different ones).
        set(flags_c "${CMAKE_C_FLAGS}")
        set(flags_cxx "${CMAKE_CXX_FLAGS}")
        if(CMAKE_SYSTEM_PROCESSOR MATCHES "AMD64|x86_64" AND NOT APPLE)
            string(APPEND flags_c " -mcmodel=large")
            string(APPEND flags_cxx " -mcmodel=large")
        endif()
        set(library "${CMAKE_ARCHIVE_OUTPUT_DIRECTORY}/libamd_fidelityfx_${api}.a")
        list(APPEND args -DREXGLUE_FSR_STATIC=ON "-DREXGLUE_FSR_ARCHIVE_DIR=${CMAKE_ARCHIVE_OUTPUT_DIRECTORY}"
             "-DCMAKE_TOOLCHAIN_FILE=${CMAKE_TOOLCHAIN_FILE}"
             "-DCMAKE_C_FLAGS=${flags_c}" "-DCMAKE_CXX_FLAGS=${flags_cxx}")
        set(target rexglue_fsr_static)
    else()
        list(APPEND args -DREXGLUE_FSR_STATIC=OFF "-DREXGLUE_FSR_ARCHIVE_DIR=")
        set(library "${binary_dir}/bin/${_rexglue_fsr_library_prefix}amd_fidelityfx_${api}${_rexglue_fsr_library_suffix}")
        set(target amd_fidelityfx_${api})
    endif()
    # A runtime that fails to configure or build is left out with a warning
    # (soft_step.cmake), and the SDK builds on without it.
    set(step_hint "")
    if(REXGLUE_FSR_FRAMEGEN)
        set(step_hint "If the errors are in frame generation's code (ffx_frameinterpolation, ffx_opticalflow, the provider), configure again with -DREXGLUE_FSR_FRAMEGEN=OFF to keep FSR anti-aliasing.")
    endif()
    set(soft "${CMAKE_COMMAND}" "-DSTEP_SKIP=${wrapper_dir}/failed" "-DSTEP_HINT=${step_hint}" -P "${wrapper_dir}/soft_step.cmake")
    # Built again when its library isn't there (an earlier attempt failed).
    set(stamp_dir "${binary_dir}-stamp")
    if(NOT EXISTS "${library}")
        file(REMOVE_RECURSE "${stamp_dir}")
    endif()
    ExternalProject_Add(rexglue_fsr_${api}
        SOURCE_DIR "${wrapper_dir}"
        BINARY_DIR "${binary_dir}"
        STAMP_DIR "${stamp_dir}"
        TMP_DIR "${binary_dir}-tmp"
        CONFIGURE_COMMAND "${CMAKE_COMMAND}" "-DSTEP_SKIP=${wrapper_dir}/failed" "-DSTEP_HINT=${step_hint}"
            -DSTEP_FIRST=1 -P "${wrapper_dir}/soft_step.cmake" --
            "${CMAKE_COMMAND}" -S "${wrapper_dir}" -B "${binary_dir}" -G Ninja
            -DCMAKE_BUILD_TYPE=Release
            "-DCMAKE_C_COMPILER=${CMAKE_C_COMPILER}"
            "-DCMAKE_CXX_COMPILER=${CMAKE_CXX_COMPILER}"
            "-DCMAKE_MAKE_PROGRAM=${CMAKE_MAKE_PROGRAM}"
            ${args}
        BUILD_COMMAND ${soft} -- "${CMAKE_COMMAND}" --build "${binary_dir}" --target ${target}
        INSTALL_COMMAND ""
        BUILD_BYPRODUCTS "${library}"
        BUILD_ALWAYS OFF)
    if(WIN32 AND NOT MINGW AND NOT REXGLUE_FSR_STATIC)
        # The library links the C runtime in (above): one that doesn't any more is a warning.
        ExternalProject_Add_Step(rexglue_fsr_${api} check_crt
            COMMAND "${CMAKE_COMMAND}" "-DDLL=${library}"
                -P "${REXGLUE_ROOT}/cmake/rexglue_fsr_check_crt.cmake"
            DEPENDEES build DEPENDERS install)
    endif()
    add_dependencies(rexglue_fsr_runtime rexglue_fsr_${api})
    if(_rexglue_fsr_install_dir)
        install(FILES "${library}" DESTINATION "${_rexglue_fsr_install_dir}" OPTIONAL)
    endif()
endforeach()
if(_rexglue_fsr_apis)
    string(REPLACE ";" ", " _rexglue_fsr_list "${_rexglue_fsr_apis}")
    set(REXGLUE_FSR_STATUS "ON (${_rexglue_fsr_list}")
    if(REXGLUE_FSR_VK_PREBUILT)
        string(APPEND REXGLUE_FSR_STATUS "; Vulkan shaders prebuilt")
    endif()
    if(REXGLUE_FSR_STATIC)
        string(APPEND REXGLUE_FSR_STATUS "; static")
    endif()
    string(APPEND REXGLUE_FSR_STATUS "), built with the SDK; one that fails to build is left out with a warning")
else()
    set(REXGLUE_FSR_STATUS "ON, but no runtime can be built here (see the warnings above)")
endif()
