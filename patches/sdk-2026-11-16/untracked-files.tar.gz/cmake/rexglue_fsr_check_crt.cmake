# Warns when a FidelityFX runtime that cmake/rexglue_fsr.cmake built imports the Visual C++
# runtime or the universal C runtime: the runtimes are built with the C runtime linked in
# (CMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded, so that a PC needs no Redistributable for them), and
# a later FidelityFX pin that brings the dynamic one back should not do it silently.
#   cmake -DDLL=<the built library> -P rexglue_fsr_check_crt.cmake
# (The import table holds the DLLs' names as plain text.)
if(NOT DLL OR NOT EXISTS "${DLL}")
    return()
endif()
file(STRINGS "${DLL}" _imports REGEX "(VCRUNTIME[0-9]+|MSVCP[0-9]+|ucrtbase|api-ms-win-crt-[a-z0-9-]+)\\.dll" LIMIT_COUNT 1)
if(_imports)
    message(WARNING "FSR: ${DLL} imports the C runtime (${_imports}): a PC needs the Visual C++ Redistributable for it; the runtimes are meant to link it in (CMAKE_MSVC_RUNTIME_LIBRARY in cmake/rexglue_fsr.cmake)")
endif()
